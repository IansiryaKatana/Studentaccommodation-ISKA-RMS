-- Fix RLS policies for demo access
-- Drop existing policies that might be causing issues
DROP POLICY IF EXISTS "Users can view their own profile" ON users;
DROP POLICY IF EXISTS "Administrators can view all users" ON users;

-- Create a simple policy that allows all authenticated and anonymous users to read the users table
-- This is for demo purposes only - in production you would have proper authentication
CREATE POLICY "Allow read access for demo" ON users
    FOR SELECT USING (true);

-- Allow updates for demo purposes
CREATE POLICY "Allow update access for demo" ON users
    FOR UPDATE USING (true);

-- Allow inserts for demo purposes
CREATE POLICY "Allow insert access for demo" ON users
    FOR INSERT WITH CHECK (true);

-- Also fix policies for other tables that might be accessed
DROP POLICY IF EXISTS "Users can view their own profile" ON leads;
DROP POLICY IF EXISTS "Administrators can view all users" ON leads;

CREATE POLICY "Allow read access for demo" ON leads
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON leads
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON leads
    FOR INSERT WITH CHECK (true);

-- Fix reservations policies
DROP POLICY IF EXISTS "Users can view their own profile" ON reservations;
DROP POLICY IF EXISTS "Administrators can view all users" ON reservations;

CREATE POLICY "Allow read access for demo" ON reservations
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON reservations
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON reservations
    FOR INSERT WITH CHECK (true);

-- Fix payments policies
DROP POLICY IF EXISTS "Users can view their own profile" ON payments;
DROP POLICY IF EXISTS "Administrators can view all users" ON payments;

CREATE POLICY "Allow read access for demo" ON payments
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON payments
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON payments
    FOR INSERT WITH CHECK (true);

-- Fix invoices policies
DROP POLICY IF EXISTS "Users can view their own profile" ON invoices;
DROP POLICY IF EXISTS "Administrators can view all users" ON invoices;

CREATE POLICY "Allow read access for demo" ON invoices
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON invoices
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON invoices
    FOR INSERT WITH CHECK (true);

-- Fix cleaning_tasks policies
DROP POLICY IF EXISTS "Users can view their own profile" ON cleaning_tasks;
DROP POLICY IF EXISTS "Administrators can view all users" ON cleaning_tasks;

CREATE POLICY "Allow read access for demo" ON cleaning_tasks
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON cleaning_tasks
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON cleaning_tasks
    FOR INSERT WITH CHECK (true);

-- Fix maintenance_requests policies
DROP POLICY IF EXISTS "Users can view their own profile" ON maintenance_requests;
DROP POLICY IF EXISTS "Administrators can view all users" ON maintenance_requests;

CREATE POLICY "Allow read access for demo" ON maintenance_requests
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON maintenance_requests
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON maintenance_requests
    FOR INSERT WITH CHECK (true);

-- Fix notifications policies
DROP POLICY IF EXISTS "Users can view their own profile" ON notifications;
DROP POLICY IF EXISTS "Administrators can view all users" ON notifications;

CREATE POLICY "Allow read access for demo" ON notifications
    FOR SELECT USING (true);

CREATE POLICY "Allow update access for demo" ON notifications
    FOR UPDATE USING (true);

CREATE POLICY "Allow insert access for demo" ON notifications
    FOR INSERT WITH CHECK (true);
