# Stripe Payment Integration Setup Guide

## 🚀 Quick Start

### 1. Get Your Stripe Test Keys

1. **Sign up for Stripe** (if you haven't already):
   - Go to [stripe.com](https://stripe.com)
   - Create a free account
   - Complete your business profile

2. **Access Your Dashboard**:
   - Log into your Stripe Dashboard
   - Navigate to **Developers** → **API keys**

3. **Copy Your Test Keys**:
   - **Publishable key**: Starts with `pk_test_`
   - **Secret key**: Starts with `sk_test_`

### 2. Configure Environment Variables

Update your `.env` file with your actual Stripe keys:

```env
# Stripe Configuration
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_actual_publishable_key_here
VITE_STRIPE_SECRET_KEY=sk_test_your_actual_secret_key_here
VITE_STRIPE_API_BASE=https://api.stripe.com/v1
```

### 3. Test Payment Setup

The system includes a complete payment form component (`src/components/finance/PaymentForm.tsx`) that supports:

- ✅ **Credit/Debit Cards** (via Stripe)
- ✅ **Bank Transfer** (manual recording)
- ✅ **Cash** (manual recording)
- ✅ **Check** (manual recording)

## 🧪 Testing Payments

### Test Card Numbers

Use these test card numbers in Stripe test mode:

| Card Type | Number | Expiry | CVC |
|-----------|--------|--------|-----|
| **Visa** | `4242424242424242` | Any future date | Any 3 digits |
| **Visa (debit)** | `4000056655665556` | Any future date | Any 3 digits |
| **Mastercard** | `5555555555554444` | Any future date | Any 3 digits |
| **American Express** | `378282246310005` | Any future date | Any 4 digits |

### Test Scenarios

1. **Successful Payment**:
   - Use any of the test card numbers above
   - Any future expiry date
   - Any 3-4 digit CVC

2. **Failed Payment**:
   - Use `4000000000000002` (generic decline)
   - Use `4000000000009995` (insufficient funds)
   - Use `4000000000009987` (lost card)

3. **3D Secure Authentication**:
   - Use `4000002500003155` (requires authentication)
   - Use `4000008400001629` (authentication fails)

## 🔧 Implementation Details

### Payment Form Component

The `PaymentForm` component (`src/components/finance/PaymentForm.tsx`) provides:

```tsx
<PaymentForm
  invoiceId="invoice-uuid"
  amount={150.00}
  customerEmail="customer@example.com"
  onSuccess={() => console.log('Payment successful')}
  onCancel={() => console.log('Payment cancelled')}
/>
```

### Features

- ✅ **Multiple Payment Methods**: Card, bank transfer, cash, check
- ✅ **Stripe Elements**: Secure card input
- ✅ **Error Handling**: Comprehensive error messages
- ✅ **Loading States**: Processing indicators
- ✅ **Success Feedback**: Toast notifications
- ✅ **Mobile Responsive**: Works on all devices

### Integration Points

1. **Invoice System**: Automatically creates payment records
2. **Database**: Updates invoice status and payment tracking
3. **Notifications**: Sends success/failure notifications
4. **Audit Trail**: Logs all payment attempts

## 🌐 Production Setup

### 1. Switch to Live Keys

When ready for production:

1. **Get Live Keys**:
   - In Stripe Dashboard, toggle to **Live mode**
   - Copy your live publishable and secret keys

2. **Update Environment**:
   ```env
   VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your_live_publishable_key
   VITE_STRIPE_SECRET_KEY=sk_live_your_live_secret_key
   ```

3. **Webhook Configuration**:
   - Set up webhooks for payment confirmations
   - Configure endpoint: `https://yourdomain.com/api/stripe-webhook`

### 2. Security Considerations

- ✅ **Never expose secret keys** in frontend code
- ✅ **Use environment variables** for all sensitive data
- ✅ **Implement webhook verification** for production
- ✅ **Enable RLS** for database security
- ✅ **Use HTTPS** for all payment communications

## 🔍 Troubleshooting

### Common Issues

1. **"Stripe is not loaded"**:
   - Check your publishable key is correct
   - Ensure the key starts with `pk_test_` or `pk_live_`
   - Verify the key is in your `.env` file

2. **"Payment failed"**:
   - Use correct test card numbers
   - Check card expiry date is in the future
   - Verify CVC is correct length

3. **"API call failed"**:
   - Check your secret key is correct
   - Ensure you're using test keys for testing
   - Verify your Stripe account is active

### Debug Mode

Enable debug logging by adding to your `.env`:

```env
VITE_STRIPE_DEBUG=true
```

This will log all Stripe API calls to the console.

## 📊 Payment Analytics

### Stripe Dashboard Features

1. **Payment Analytics**:
   - Success/failure rates
   - Payment method distribution
   - Revenue tracking
   - Customer insights

2. **Fraud Detection**:
   - Automatic fraud screening
   - Risk assessment
   - Chargeback protection

3. **Reporting**:
   - Daily/monthly reports
   - Tax reporting
   - Reconciliation tools

## 🚀 Advanced Features

### 1. Subscription Payments

For recurring payments (e.g., monthly rent):

```tsx
// Create subscription
const subscription = await stripe.subscriptions.create({
  customer: customerId,
  items: [{ price: 'price_monthly_rent' }],
  payment_behavior: 'default_incomplete',
  expand: ['latest_invoice.payment_intent'],
});
```

### 2. Installment Plans

The system supports installment plans:

- ✅ **Flexible schedules**: Monthly, quarterly, etc.
- ✅ **Late fee calculation**: Automatic late fee application
- ✅ **Payment tracking**: Individual installment status
- ✅ **Reminder system**: Due date notifications

### 3. Refund Processing

Handle refunds through Stripe:

```tsx
// Process refund
const refund = await stripe.refunds.create({
  payment_intent: paymentIntentId,
  amount: refundAmount, // in cents
  reason: 'requested_by_customer',
});
```

## 📱 Mobile Optimization

The payment form is fully mobile-responsive:

- ✅ **Touch-friendly**: Large buttons and inputs
- ✅ **Keyboard optimization**: Proper input types
- ✅ **Loading states**: Clear feedback on mobile
- ✅ **Error handling**: Mobile-friendly error messages

## 🔒 Security Best Practices

1. **PCI Compliance**:
   - Stripe handles PCI compliance
   - Never store card data directly
   - Use Stripe Elements for card input

2. **Data Protection**:
   - Encrypt sensitive data
   - Use HTTPS everywhere
   - Implement proper access controls

3. **Fraud Prevention**:
   - Enable Stripe Radar
   - Monitor suspicious activity
   - Implement velocity checks

## 📞 Support

### Stripe Support
- **Documentation**: [stripe.com/docs](https://stripe.com/docs)
- **API Reference**: [stripe.com/docs/api](https://stripe.com/docs/api)
- **Support**: Available in your Stripe Dashboard

### System Support
- **Payment Issues**: Check browser console for errors
- **Configuration**: Verify environment variables
- **Testing**: Use provided test card numbers

## 🎯 Next Steps

1. **Configure your test keys** in `.env`
2. **Test payments** using the provided test cards
3. **Integrate payment form** into your invoice pages
4. **Set up webhooks** for production
5. **Switch to live keys** when ready

Your ISKA RMS system is now ready for payment processing! 🚀 