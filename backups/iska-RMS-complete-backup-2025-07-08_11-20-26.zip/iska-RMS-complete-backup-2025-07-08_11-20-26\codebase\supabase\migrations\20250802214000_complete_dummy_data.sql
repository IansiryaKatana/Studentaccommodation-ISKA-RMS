-- =====================================================
-- COMPLETE DUMMY DATA MIGRATION
-- Fill all missing tables with comprehensive dummy data
-- =====================================================

-- Insert missing room grades if not exists
INSERT INTO room_grades (name, weekly_rate, studio_count, description, is_active) 
SELECT * FROM (VALUES 
    ('Silver', 160.00, 12, 'Standard accommodation with essential amenities', true),
    ('Gold', 175.00, 18, 'Premium accommodation with enhanced features', true),
    ('Platinum', 195.00, 8, 'Luxury accommodation with premium amenities', true),
    ('Rhodium', 200.00, 6, 'Ultra-luxury accommodation with exclusive features', true),
    ('Thodium Plus', 225.00, 4, 'Premium luxury accommodation with all amenities', true)
) AS v(name, weekly_rate, studio_count, description, is_active)
WHERE NOT EXISTS (SELECT 1 FROM room_grades WHERE room_grades.name = v.name);

-- Insert missing durations if not exists
INSERT INTO durations (name, duration_type, weeks_count, check_in_date, check_out_date, academic_year, is_active)
SELECT name, duration_type, weeks_count, check_in_date::date, check_out_date::date, academic_year, is_active FROM (VALUES 
    ('45-weeks', 'student', 45, '2025-09-01', '2026-07-13', '2025/2026', true),
    ('51-weeks', 'student', 51, '2025-09-01', '2026-08-24', '2025/2026', true),
    ('Weekly', 'tourist', 1, '2025-01-01', '2025-12-31', '2025', true),
    ('Monthly', 'tourist', 4, '2025-01-01', '2025-12-31', '2025', true),
    ('Summer Term', 'student', 12, '2025-06-01', '2025-08-31', '2025/2026', true)
) AS v(name, duration_type, weeks_count, check_in_date, check_out_date, academic_year, is_active)
WHERE NOT EXISTS (SELECT 1 FROM durations WHERE durations.name = v.name AND durations.academic_year = v.academic_year);

-- Insert missing lead sources if not exists
INSERT INTO lead_sources (name, description, is_active)
SELECT * FROM (VALUES 
    ('Website', 'Direct website inquiries', true),
    ('Social Media', 'Social media advertising and posts', true),
    ('Referral', 'Word of mouth and referrals', true),
    ('University Partnership', 'Direct university partnerships', true),
    ('Online Advertising', 'Google Ads and other online ads', true),
    ('Print Media', 'Newspaper and magazine ads', true),
    ('Events', 'University fairs and events', true)
) AS v(name, description, is_active)
WHERE NOT EXISTS (SELECT 1 FROM lead_sources WHERE lead_sources.name = v.name);

-- Insert missing installment plans
INSERT INTO installment_plans (name, description, number_of_installments, discount_percentage, late_fee_percentage, late_fee_flat, is_active)
SELECT name, description, number_of_installments, discount_percentage, late_fee_percentage, late_fee_flat, is_active FROM (VALUES 
    ('Monthly', 'Pay monthly installments', 12, 0.00, 2.00, 10.00, true),
    ('Quarterly', 'Pay quarterly installments', 4, 1.00, 2.00, 10.00, true),
    ('Semester', 'Pay per semester', 2, 2.00, 2.00, 10.00, true),
    ('Full Payment', 'Pay full amount upfront', 1, 5.00, 0.00, 0.00, true),
    ('Weekly', 'Pay weekly installments', 52, 0.00, 2.00, 10.00, true)
) AS v(name, description, number_of_installments, discount_percentage, late_fee_percentage, late_fee_flat, is_active)
WHERE NOT EXISTS (SELECT 1 FROM installment_plans WHERE installment_plans.name = v.name);

-- Insert missing maintenance categories
INSERT INTO maintenance_categories (name, description, priority, is_active)
SELECT name, description, 
  CASE priority_level WHEN 'high' THEN 3 WHEN 'medium' THEN 2 WHEN 'low' THEN 1 ELSE 1 END AS priority, 
  is_active FROM (VALUES 
    ('Plumbing', 'Water, heating, and drainage issues', 'medium', true),
    ('Electrical', 'Lighting, power, and electrical systems', 'high', true),
    ('HVAC', 'Heating, ventilation, and air conditioning', 'high', true),
    ('Appliances', 'Kitchen and laundry appliances', 'medium', true),
    ('Furniture', 'Furniture repairs and replacements', 'low', true),
    ('Structural', 'Building structure and safety issues', 'high', true),
    ('Cleaning', 'Deep cleaning and sanitization', 'low', true),
    ('Pest Control', 'Pest prevention and treatment', 'medium', true)
) AS v(name, description, priority_level, is_active)
WHERE NOT EXISTS (SELECT 1 FROM maintenance_categories WHERE maintenance_categories.name = v.name);

-- Insert missing module styles
INSERT INTO module_styles (module_name, gradient_start, gradient_end, is_active)
SELECT module_name, gradient_start, gradient_end, is_active FROM (VALUES 
    ('dashboard', '#3B82F6', '#8B5CF6', true),
    ('leads', '#10B981', '#059669', true),
    ('reservations', '#F97316', '#DC2626', true),
    ('students', '#6366F1', '#3B82F6', true),
    ('cleaning', '#14B8A6', '#0891B2', true),
    ('finance', '#8B5CF6', '#EC4899', true),
    ('data', '#6B7280', '#475569', true),
    ('settings', '#64748B', '#4B5563', true)
) AS v(module_name, gradient_start, gradient_end, is_active)
WHERE NOT EXISTS (SELECT 1 FROM module_styles WHERE module_styles.module_name = v.module_name);

-- Insert missing student option fields
INSERT INTO student_option_fields (field_name, field_type, field_label, is_required, is_active)
SELECT field_name, field_type, field_label, is_required, is_active FROM (VALUES 
    ('university', 'text', 'University', true, true),
    ('course', 'text', 'Course of Study', true, true),
    ('year_of_study', 'number', 'Year of Study', true, true),
    ('emergency_contact_name', 'text', 'Emergency Contact Name', true, true),
    ('emergency_contact_phone', 'phone', 'Emergency Contact Phone', true, true),
    ('guarantor_name', 'text', 'Guarantor Name', false, true),
    ('guarantor_phone', 'phone', 'Guarantor Phone', false, true),
    ('guarantor_email', 'email', 'Guarantor Email', false, true),
    ('guarantor_address', 'textarea', 'Guarantor Address', false, true),
    ('guarantor_relationship', 'select', 'Guarantor Relationship', false, true),
    ('passport_number', 'text', 'Passport Number', false, true),
    ('nationality', 'text', 'Nationality', false, true)
) AS v(field_name, field_type, field_label, is_required, is_active)
WHERE NOT EXISTS (SELECT 1 FROM student_option_fields WHERE student_option_fields.field_name = v.field_name);

-- Insert missing lead option fields
INSERT INTO lead_option_fields (field_name, field_type, field_label, is_required, is_active)
SELECT field_name, field_type, field_label, is_required, is_active FROM (VALUES 
    ('first_name', 'text', 'First Name', true, true),
    ('last_name', 'text', 'Last Name', true, true),
    ('email', 'email', 'Email Address', false, true),
    ('phone', 'phone', 'Phone Number', false, true),
    ('source', 'select', 'Lead Source', true, true),
    ('budget', 'number', 'Budget Range', false, true),
    ('move_in_date', 'date', 'Preferred Move-in Date', false, true),
    ('duration_months', 'number', 'Duration (months)', false, true),
    ('notes', 'textarea', 'Additional Notes', false, true),
    ('assigned_to', 'select', 'Assigned To', false, true)
) AS v(field_name, field_type, field_label, is_required, is_active)
WHERE NOT EXISTS (SELECT 1 FROM lead_option_fields WHERE lead_option_fields.field_name = v.field_name);

-- Insert missing pricing matrix entries
INSERT INTO pricing_matrix (room_grade_id, duration_id, weekly_rate_override, is_active)
SELECT rg.id, d.id, pm.weekly_rate_override, pm.is_active FROM (VALUES 
    ('Silver', '45-weeks', '2025/2026', 160.00, true),
    ('Silver', '51-weeks', '2025/2026', 160.00, true),
    ('Silver', 'Weekly', '2025', 160.00, true),
    ('Gold', '45-weeks', '2025/2026', 175.00, true),
    ('Gold', '51-weeks', '2025/2026', 175.00, true),
    ('Gold', 'Weekly', '2025', 175.00, true),
    ('Platinum', '45-weeks', '2025/2026', 195.00, true),
    ('Platinum', '51-weeks', '2025/2026', 195.00, true),
    ('Platinum', 'Weekly', '2025', 195.00, true),
    ('Rhodium', '45-weeks', '2025/2026', 200.00, true),
    ('Rhodium', '51-weeks', '2025/2026', 200.00, true),
    ('Rhodium', 'Weekly', '2025', 200.00, true),
    ('Thodium Plus', '45-weeks', '2025/2026', 225.00, true),
    ('Thodium Plus', '51-weeks', '2025/2026', 225.00, true),
    ('Thodium Plus', 'Weekly', '2025', 225.00, true)
) AS pm(room_grade_name, duration_name, academic_year, weekly_rate_override, is_active)
JOIN room_grades rg ON rg.name = pm.room_grade_name
JOIN durations d ON d.name = pm.duration_name AND d.academic_year = pm.academic_year
WHERE NOT EXISTS (
    SELECT 1 FROM pricing_matrix 
    WHERE pricing_matrix.room_grade_id = rg.id 
    AND pricing_matrix.duration_id = d.id
);

-- Insert missing cleaners
INSERT INTO cleaners (user_id, hourly_rate, is_active)
SELECT u.id, 15.00, true FROM users u 
WHERE u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM cleaners WHERE cleaners.user_id = u.id);

-- Insert missing cleaning tasks
INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT s.id, c.id, '2025-01-15'::date, '09:00:00'::time, 120, 'completed', 'Standard cleaning after check-out', u.id
FROM studios s, cleaners c, users u
WHERE s.studio_number = 'S104' AND u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-15'::date);

INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT s.id, c.id, '2025-01-15'::date, '10:00:00'::time, 120, 'in_progress', 'Deep cleaning required', u.id
FROM studios s, cleaners c, users u
WHERE s.studio_number = 'G104' AND u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-15'::date);

INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT s.id, c.id, '2025-01-15'::date, '11:00:00'::time, 90, 'scheduled', 'Regular maintenance cleaning', u.id
FROM studios s, cleaners c, users u
WHERE s.studio_number = 'P104' AND u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-15'::date);

INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT s.id, c.id, '2025-01-15'::date, '14:00:00'::time, 120, 'scheduled', 'Post-occupancy cleaning', u.id
FROM studios s, cleaners c, users u
WHERE s.studio_number = 'R203' AND u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-15'::date);

-- Insert missing maintenance requests
INSERT INTO maintenance_requests (studio_id, category_id, title, description, priority, status, reported_by)
SELECT s.id, mc.id, 'Leaky Faucet', 'Bathroom faucet is dripping constantly', 2, 'completed', u.id
FROM studios s, maintenance_categories mc, users u
WHERE s.studio_number = 'S204' AND mc.name = 'Plumbing' AND u.email = 'student1@university.ac.uk'
AND NOT EXISTS (SELECT 1 FROM maintenance_requests WHERE maintenance_requests.studio_id = s.id AND maintenance_requests.title = 'Leaky Faucet');

INSERT INTO maintenance_requests (studio_id, category_id, title, description, priority, status, reported_by)
SELECT s.id, mc.id, 'Heating Issue', 'Heating system not working properly', 3, 'in_progress', u.id
FROM studios s, maintenance_categories mc, users u
WHERE s.studio_number = 'G204' AND mc.name = 'HVAC' AND u.email = 'student2@university.ac.uk'
AND NOT EXISTS (SELECT 1 FROM maintenance_requests WHERE maintenance_requests.studio_id = s.id AND maintenance_requests.title = 'Heating Issue');

INSERT INTO maintenance_requests (studio_id, category_id, title, description, priority, status, reported_by)
SELECT s.id, mc.id, 'Light Bulb Replacement', 'Main ceiling light needs replacement', 1, 'open', u.id
FROM studios s, maintenance_categories mc, users u
WHERE s.studio_number = 'P204' AND mc.name = 'Electrical' AND u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM maintenance_requests WHERE maintenance_requests.studio_id = s.id AND maintenance_requests.title = 'Light Bulb Replacement');

-- Insert missing invoices
INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-001', r.id, 1750.00, 1750.00, '2025-09-15'::date, 'completed', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES001' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-001');

INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-002', r.id, 1750.00, 1750.00, '2025-10-15'::date, 'completed', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES001' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-002');

INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-003', r.id, 1750.00, 1750.00, '2025-11-15'::date, 'completed', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES001' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-003');

INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-004', r.id, 1750.00, 1750.00, '2025-12-15'::date, 'pending', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES001' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-004');

INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-005', r.id, 1950.00, 1950.00, '2025-09-15'::date, 'completed', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES002' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-005');

INSERT INTO invoices (invoice_number, reservation_id, amount, total_amount, due_date, status, created_by)
SELECT 'INV-2025-006', r.id, 1950.00, 1950.00, '2025-10-15'::date, 'pending', u.id
FROM reservations r, users u
WHERE r.reservation_number = 'RES002' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM invoices WHERE invoices.invoice_number = 'INV-2025-006');

-- Insert missing payments
INSERT INTO payments (invoice_id, amount, method, status, transaction_id, created_by)
SELECT i.id, 1750.00, 'bank_transfer', 'completed', 'TXN-001', u.id
FROM invoices i, users u
WHERE i.invoice_number = 'INV-2025-001' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM payments WHERE payments.transaction_id = 'TXN-001');

INSERT INTO payments (invoice_id, amount, method, status, transaction_id, created_by)
SELECT i.id, 1750.00, 'stripe', 'completed', 'TXN-002', u.id
FROM invoices i, users u
WHERE i.invoice_number = 'INV-2025-002' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM payments WHERE payments.transaction_id = 'TXN-002');

INSERT INTO payments (invoice_id, amount, method, status, transaction_id, created_by)
SELECT i.id, 1750.00, 'bank_transfer', 'completed', 'TXN-003', u.id
FROM invoices i, users u
WHERE i.invoice_number = 'INV-2025-003' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM payments WHERE payments.transaction_id = 'TXN-003');

INSERT INTO payments (invoice_id, amount, method, status, transaction_id, created_by)
SELECT i.id, 1950.00, 'stripe', 'completed', 'TXN-004', u.id
FROM invoices i, users u
WHERE i.invoice_number = 'INV-2025-005' AND u.email = 'accountant@iska.com'
AND NOT EXISTS (SELECT 1 FROM payments WHERE payments.transaction_id = 'TXN-004');

-- Insert missing reservation installments
INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 1, '2025-09-15'::date, 1750.00, 'completed'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES001' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 1);

INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 2, '2025-10-15'::date, 1750.00, 'completed'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES001' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 2);

INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 3, '2025-11-15'::date, 1750.00, 'completed'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES001' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 3);

INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 4, '2025-12-15'::date, 1750.00, 'pending'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES001' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 4);

INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 1, '2025-09-15'::date, 1950.00, 'completed'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES002' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 1);

INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status)
SELECT r.id, ip.id, 2, '2025-10-15'::date, 1950.00, 'pending'
FROM reservations r, installment_plans ip
WHERE r.reservation_number = 'RES002' AND ip.name = 'Monthly'
AND NOT EXISTS (SELECT 1 FROM reservation_installments WHERE reservation_installments.reservation_id = r.id AND reservation_installments.installment_number = 2);

-- Insert missing notifications
INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT u.id, 'Payment Due', 'Your next installment payment is due on 2025-12-15', 'payment_reminder', false, NOW()
FROM users u
WHERE u.email = 'student1@university.ac.uk'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE notifications.user_id = u.id AND notifications.title = 'Payment Due');

INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT u.id, 'Payment Due', 'Your next installment payment is due on 2025-10-15', 'payment_reminder', false, NOW()
FROM users u
WHERE u.email = 'student2@university.ac.uk'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE notifications.user_id = u.id AND notifications.title = 'Payment Due');

INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT u.id, 'New Cleaning Task', 'You have been assigned a new cleaning task for studio S104', 'task_assignment', false, NOW()
FROM users u
WHERE u.email = 'cleaner@iska.com'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE notifications.user_id = u.id AND notifications.title = 'New Cleaning Task');

INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT u.id, 'New Lead', 'A new lead has been assigned to you', 'lead_assignment', false, NOW()
FROM users u
WHERE u.email = 'sales@iska.com'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE notifications.user_id = u.id AND notifications.title = 'New Lead');

INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT u.id, 'Check-in Reminder', 'Student check-in scheduled for tomorrow', 'check_in_reminder', false, NOW()
FROM users u
WHERE u.email = 'reservations@iska.com'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE notifications.user_id = u.id AND notifications.title = 'Check-in Reminder');

-- Insert missing audit log entries
INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
SELECT u.id, 'CREATE', 'users', st.id, NULL, '{"email": "student1@university.ac.uk", "first_name": "Alex"}', '192.168.1.1', 'Mozilla/5.0'
FROM users u, students st
WHERE u.email = 'admin@iska.com' AND st.student_id = 'STU001'
AND NOT EXISTS (SELECT 1 FROM audit_log WHERE audit_log.user_id = u.id AND audit_log.action = 'CREATE' AND audit_log.entity_type = 'users');

INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
SELECT u.id, 'UPDATE', 'leads', l.id, '{"status": "new"}', '{"status": "contacted"}', '192.168.1.2', 'Mozilla/5.0'
FROM users u, leads l
WHERE u.email = 'sales@iska.com' AND l.id IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM audit_log WHERE audit_log.user_id = u.id AND audit_log.action = 'UPDATE' AND audit_log.entity_type = 'leads')
LIMIT 1;

INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
SELECT u.id, 'CREATE', 'reservations', r.id, NULL, '{"reservation_number": "RES001", "type": "student"}', '192.168.1.3', 'Mozilla/5.0'
FROM users u, reservations r
WHERE u.email = 'reservations@iska.com' AND r.reservation_number = 'RES001'
AND NOT EXISTS (SELECT 1 FROM audit_log WHERE audit_log.user_id = u.id AND audit_log.action = 'CREATE' AND audit_log.entity_type = 'reservations');

INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
SELECT u.id, 'CREATE', 'invoices', i.id, NULL, '{"invoice_number": "INV-2025-001", "amount": 1750.00}', '192.168.1.4', 'Mozilla/5.0'
FROM users u, invoices i
WHERE u.email = 'accountant@iska.com' AND i.invoice_number = 'INV-2025-001'
AND NOT EXISTS (SELECT 1 FROM audit_log WHERE audit_log.user_id = u.id AND audit_log.action = 'CREATE' AND audit_log.entity_type = 'invoices');

INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent)
SELECT u.id, 'UPDATE', 'cleaning_tasks', ct.id, '{"status": "scheduled"}', '{"status": "completed"}', '192.168.1.5', 'Mozilla/5.0'
FROM users u, cleaning_tasks ct
WHERE u.email = 'cleaner@iska.com' AND ct.id IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM audit_log WHERE audit_log.user_id = u.id AND audit_log.action = 'UPDATE' AND audit_log.entity_type = 'cleaning_tasks')
LIMIT 1;

-- Insert missing lead follow-ups
INSERT INTO lead_follow_ups (lead_id, type, notes, scheduled_date, completed_date, created_by)
SELECT l.id, 'call', 'Initial contact call - interested in Gold studio', '2025-01-10 10:00:00'::timestamp, '2025-01-10 10:15:00'::timestamp, u.id
FROM leads l, users u
WHERE l.email = 'david.wilson@email.com' AND u.email = 'sales@iska.com'
AND NOT EXISTS (SELECT 1 FROM lead_follow_ups WHERE lead_follow_ups.lead_id = l.id AND lead_follow_ups.type = 'call');

INSERT INTO lead_follow_ups (lead_id, type, notes, scheduled_date, completed_date, created_by)
SELECT l.id, 'email', 'Sent proposal for Platinum studio', '2025-01-12 14:00:00'::timestamp, '2025-01-12 14:30:00'::timestamp, u.id
FROM leads l, users u
WHERE l.email = 'emma.brown@email.com' AND u.email = 'sales@iska.com'
AND NOT EXISTS (SELECT 1 FROM lead_follow_ups WHERE lead_follow_ups.lead_id = l.id AND lead_follow_ups.type = 'email');

INSERT INTO lead_follow_ups (lead_id, type, notes, scheduled_date, completed_date, created_by)
SELECT l.id, 'meeting', 'Scheduled property viewing', '2025-01-15 15:00:00'::timestamp, NULL, u.id
FROM leads l, users u
WHERE l.email = 'james.taylor@email.com' AND u.email = 'sales@iska.com'
AND NOT EXISTS (SELECT 1 FROM lead_follow_ups WHERE lead_follow_ups.lead_id = l.id AND lead_follow_ups.type = 'meeting');

INSERT INTO lead_follow_ups (lead_id, type, notes, scheduled_date, completed_date, created_by)
SELECT l.id, 'proposal', 'Prepared custom proposal for international student', '2025-01-14 11:00:00'::timestamp, '2025-01-14 11:45:00'::timestamp, u.id
FROM leads l, users u
WHERE l.email = 'sophie.anderson@email.com' AND u.email = 'sales@iska.com'
AND NOT EXISTS (SELECT 1 FROM lead_follow_ups WHERE lead_follow_ups.lead_id = l.id AND lead_follow_ups.type = 'proposal');

-- Update user last_login timestamps
UPDATE users SET last_login = NOW() - INTERVAL '1 day' WHERE email = 'admin@iska.com';
UPDATE users SET last_login = NOW() - INTERVAL '2 hours' WHERE email = 'sales@iska.com';
UPDATE users SET last_login = NOW() - INTERVAL '30 minutes' WHERE email = 'reservations@iska.com';
UPDATE users SET last_login = NOW() - INTERVAL '1 hour' WHERE email = 'cleaner@iska.com';
UPDATE users SET last_login = NOW() - INTERVAL '3 hours' WHERE email = 'accountant@iska.com';
UPDATE users SET last_login = NOW() - INTERVAL '1 week' WHERE email = 'student1@university.ac.uk';
UPDATE users SET last_login = NOW() - INTERVAL '2 days' WHERE email = 'student2@university.ac.uk';
UPDATE users SET last_login = NOW() - INTERVAL '1 day' WHERE email = 'tourist1@email.com'; 