
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { MainLayout } from '@/components/layout/MainLayout';
import Dashboard from '@/components/dashboard/Dashboard';
import LeadsModule from '@/pages/LeadsModule';
import ReservationsModule from '@/pages/ReservationsModule';
import StudentsModule from '@/pages/StudentsModule';
import CleaningModule from '@/pages/CleaningModule';
import FinanceModule from '@/pages/FinanceModule';
import DataModule from '@/pages/DataModule';
import SettingsModule from '@/pages/SettingsModule';
import StudentPortal from '@/pages/StudentPortal';
import NotFound from '@/pages/NotFound';

// Mock user data for the application
const mockUser = {
  id: '1',
  email: 'admin@iska-rms.com',
  name: 'Admin User',
  role: 'administrator',
};

function App() {
  const handleLogout = () => {
    // Simple logout that just reloads the page
    window.location.reload();
  };

  return (
    <Router>
      <MainLayout 
        userRole={mockUser.role as any}
        userName={mockUser.name}
        onLogout={handleLogout}
      >
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/leads/*" element={<LeadsModule />} />
          <Route path="/ota-bookings/*" element={<ReservationsModule />} />
          <Route path="/students/*" element={<StudentsModule />} />
          <Route path="/cleaning/*" element={<CleaningModule />} />
          <Route path="/finance/*" element={<FinanceModule />} />
          <Route path="/data/*" element={<DataModule />} />
          <Route path="/settings/*" element={<SettingsModule />} />
          <Route path="/student-portal/:studentId/*" element={<StudentPortal />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </MainLayout>
      <Toaster />
    </Router>
  );
}

export default App;
