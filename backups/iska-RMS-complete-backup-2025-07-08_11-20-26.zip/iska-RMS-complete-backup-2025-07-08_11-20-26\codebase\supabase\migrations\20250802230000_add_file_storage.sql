-- =====================================================
-- FILE STORAGE SYSTEM
-- =====================================================

-- File categories enum
CREATE TYPE file_category AS ENUM (
    'invoice', 
    'contract', 
    'id_document', 
    'payment_proof', 
    'maintenance_photo', 
    'cleaning_report', 
    'lead_attachment', 
    'student_document', 
    'tourist_document',
    'system_backup',
    'general'
);

-- File storage table
CREATE TABLE file_storage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL, -- Supabase storage path
    file_size BIGINT NOT NULL, -- Size in bytes
    mime_type VARCHAR(100) NOT NULL,
    category file_category NOT NULL DEFAULT 'general',
    description TEXT,
    tags TEXT[], -- Array of tags for easy searching
    related_entity_type VARCHAR(50), -- 'lead', 'reservation', 'payment', 'student', 'tourist', etc.
    related_entity_id UUID, -- ID of the related entity
    uploaded_by UUID REFERENCES users(id),
    is_public BOOLEAN DEFAULT false, -- Whether file can be accessed without authentication
    is_deleted BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- File sharing table for temporary access links
CREATE TABLE file_shares (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES file_storage(id) ON DELETE CASCADE,
    share_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE,
    max_downloads INTEGER DEFAULT 1,
    download_count INTEGER DEFAULT 0,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for file storage
CREATE INDEX idx_file_storage_category ON file_storage(category);
CREATE INDEX idx_file_storage_related_entity ON file_storage(related_entity_type, related_entity_id);
CREATE INDEX idx_file_storage_uploaded_by ON file_storage(uploaded_by);
CREATE INDEX idx_file_storage_created_at ON file_storage(created_at);
CREATE INDEX idx_file_storage_tags ON file_storage USING GIN(tags);
CREATE INDEX idx_file_storage_deleted ON file_storage(is_deleted);

-- Indexes for file shares
CREATE INDEX idx_file_shares_token ON file_shares(share_token);
CREATE INDEX idx_file_shares_expires_at ON file_shares(expires_at);

-- Trigger for updated_at
CREATE TRIGGER update_file_storage_updated_at 
    BEFORE UPDATE ON file_storage 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to generate share token
CREATE OR REPLACE FUNCTION generate_share_token()
RETURNS VARCHAR(255) AS $$
BEGIN
    RETURN 'share_' || encode(gen_random_bytes(16), 'hex');
END;
$$ LANGUAGE plpgsql;

-- Function to create file share
CREATE OR REPLACE FUNCTION create_file_share(
    p_file_id UUID,
    p_expires_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    p_max_downloads INTEGER DEFAULT 1,
    p_created_by UUID DEFAULT NULL
)
RETURNS VARCHAR(255) AS $$
DECLARE
    v_share_token VARCHAR(255);
BEGIN
    v_share_token := generate_share_token();
    
    INSERT INTO file_shares (file_id, share_token, expires_at, max_downloads, created_by)
    VALUES (p_file_id, v_share_token, p_expires_at, p_max_downloads, p_created_by);
    
    RETURN v_share_token;
END;
$$ LANGUAGE plpgsql;

-- Function to validate and increment download count
CREATE OR REPLACE FUNCTION validate_file_share(p_share_token VARCHAR(255))
RETURNS UUID AS $$
DECLARE
    v_file_id UUID;
BEGIN
    SELECT fs.file_id INTO v_file_id
    FROM file_shares fs
    WHERE fs.share_token = p_share_token
    AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
    AND (fs.max_downloads IS NULL OR fs.download_count < fs.max_downloads);
    
    IF v_file_id IS NOT NULL THEN
        UPDATE file_shares 
        SET download_count = download_count + 1
        WHERE share_token = p_share_token;
    END IF;
    
    RETURN v_file_id;
END;
$$ LANGUAGE plpgsql;

-- Grant permissions for demo purposes
GRANT ALL ON file_storage TO authenticated;
GRANT ALL ON file_storage TO anon;
GRANT ALL ON file_shares TO authenticated;
GRANT ALL ON file_shares TO anon;

-- Disable RLS for demo purposes
ALTER TABLE file_storage DISABLE ROW LEVEL SECURITY;
ALTER TABLE file_shares DISABLE ROW LEVEL SECURITY; 