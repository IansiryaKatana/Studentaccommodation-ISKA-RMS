-- =====================================================
-- UPDATE STUDENT SCHEMA TO MATCH UI FIELDS
-- =====================================================

-- Drop existing students table and recreate with proper fields
DROP TABLE IF EXISTS students CASCADE;

-- Create updated students table with only the fields from the UI
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    
    -- Personal Information (from UI)
    birthday DATE,
    ethnicity VARCHAR(50),
    gender VARCHAR(20),
    ucas_id VARCHAR(50),
    country VARCHAR(100),
    
    -- Contact Information (from UI)
    address_line1 VARCHAR(255),
    post_code VARCHAR(20),
    town VARCHAR(100),
    
    -- Academic Information (from UI)
    academic_year VARCHAR(20), -- '2025/2026', '2026/2027'
    year_of_study VARCHAR(20), -- '1st', '2nd', '3rd', '4+'
    field_of_study VARCHAR(200),
    
    -- Guarantor Information (from UI)
    guarantor_name VARCHAR(100),
    guarantor_email VARCHAR(255),
    guarantor_phone VARCHAR(20),
    guarantor_relationship VARCHAR(50),
    
    -- Payment Preferences (from UI)
    wants_installments BOOLEAN DEFAULT false,
    installment_plan_id UUID REFERENCES installment_plans(id),
    deposit_paid BOOLEAN DEFAULT false,
    
    -- File Upload References
    passport_file_url TEXT,
    visa_file_url TEXT,
    utility_bill_file_url TEXT,
    guarantor_id_file_url TEXT,
    bank_statement_file_url TEXT,
    proof_of_income_file_url TEXT,
    
    -- Legacy fields (keep for compatibility)
    student_id VARCHAR(50) UNIQUE,
    university VARCHAR(200),
    course VARCHAR(200),
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create file uploads table for better organization
CREATE TABLE student_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    document_type VARCHAR(50) NOT NULL, -- 'passport', 'visa', 'utility_bill', 'guarantor_id', 'bank_statement', 'proof_of_income'
    file_url TEXT NOT NULL,
    file_name VARCHAR(255),
    file_size INTEGER,
    mime_type VARCHAR(100),
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes for better performance
CREATE INDEX idx_students_user_id ON students(user_id);
CREATE INDEX idx_students_ucas_id ON students(ucas_id);
CREATE INDEX idx_students_guarantor_email ON students(guarantor_email);
CREATE INDEX idx_student_documents_student_id ON student_documents(student_id);
CREATE INDEX idx_student_documents_type ON student_documents(document_type);

-- Add trigger for updated_at
CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create storage buckets for file uploads
INSERT INTO storage.buckets (id, name, public) VALUES 
('student-documents', 'student-documents', false),
('student-passports', 'student-passports', false),
('student-visas', 'student-visas', false),
('guarantor-documents', 'guarantor-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Set up RLS policies for storage buckets
CREATE POLICY "Students can view their own documents" ON storage.objects
    FOR SELECT USING (
        bucket_id IN ('student-documents', 'student-passports', 'student-visas', 'guarantor-documents') AND
        auth.uid()::text = (storage.foldername(name))[1]
    );

CREATE POLICY "Students can upload their own documents" ON storage.objects
    FOR INSERT WITH CHECK (
        bucket_id IN ('student-documents', 'student-passports', 'student-visas', 'guarantor-documents') AND
        auth.uid()::text = (storage.foldername(name))[1]
    );

CREATE POLICY "Students can update their own documents" ON storage.objects
    FOR UPDATE USING (
        bucket_id IN ('student-documents', 'student-passports', 'student-visas', 'guarantor-documents') AND
        auth.uid()::text = (storage.foldername(name))[1]
    );

CREATE POLICY "Students can delete their own documents" ON storage.objects
    FOR DELETE USING (
        bucket_id IN ('student-documents', 'student-passports', 'student-visas', 'guarantor-documents') AND
        auth.uid()::text = (storage.foldername(name))[1]
    );

-- Admin policies for viewing all documents
CREATE POLICY "Admins can view all student documents" ON storage.objects
    FOR SELECT USING (
        bucket_id IN ('student-documents', 'student-passports', 'student-visas', 'guarantor-documents') AND
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    );

-- RLS policies for students table
ALTER TABLE students ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view their own profile" ON students
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Students can update their own profile" ON students
    FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Admins can view all students" ON students
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    );

CREATE POLICY "Admins can insert students" ON students
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    );

CREATE POLICY "Admins can update students" ON students
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    );

-- RLS policies for student_documents table
ALTER TABLE student_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view their own documents" ON student_documents
    FOR SELECT USING (
        student_id IN (
            SELECT id FROM students WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Students can insert their own documents" ON student_documents
    FOR INSERT WITH CHECK (
        student_id IN (
            SELECT id FROM students WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Admins can view all student documents" ON student_documents
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    );

CREATE POLICY "Admins can insert student documents" ON student_documents
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.role IN ('administrator', 'reservations')
        )
    ); 