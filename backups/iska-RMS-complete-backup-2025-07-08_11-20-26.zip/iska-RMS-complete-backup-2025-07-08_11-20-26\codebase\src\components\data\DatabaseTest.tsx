import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Database, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { ApiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';

const DatabaseTest = () => {
  const [testResults, setTestResults] = useState<{
    connection: 'loading' | 'success' | 'error';
    tables: Record<string, 'loading' | 'success' | 'error'>;
  }>({
    connection: 'loading',
    tables: {}
  });

  const { toast } = useToast();

  const testDatabaseConnection = async () => {
    try {
      // Test basic connection
      const { data, error } = await ApiService.testConnection();

      if (error) {
        setTestResults(prev => ({ ...prev, connection: 'error' }));
        toast({
          title: 'Database connection error',
          description: 'Failed to connect to database',
          variant: 'destructive',
        });
      } else {
        setTestResults(prev => ({ ...prev, connection: 'success' }));
        toast({
          title: 'Database connected',
          description: 'Successfully connected to the database.',
        });
      }

      // Test individual tables
      const tables = ['users', 'leads', 'reservations', 'studios', 'room_grades'];
      
      for (const table of tables) {
        try {
          const { data: tableData, error: tableError } = await ApiService.testTableAccess(table);

          setTestResults(prev => ({
            ...prev,
            [table]: tableError ? 'error' : 'success'
          }));
        } catch (error) {
          setTestResults(prev => ({
            ...prev,
            [table]: 'error'
          }));
        }
      }
    } catch (error) {
      setTestResults(prev => ({ ...prev, connection: 'error' }));
      toast({
        title: 'Database test error',
        description: 'Failed to test database connection',
        variant: 'destructive',
      });
    }
  };

  const getStatusIcon = (status: 'loading' | 'success' | 'error') => {
    switch (status) {
      case 'loading':
        return <RefreshCw className="h-4 w-4 animate-spin" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: 'loading' | 'success' | 'error') => {
    switch (status) {
      case 'loading':
        return 'Testing...';
      case 'success':
        return 'Connected';
      case 'error':
        return 'Failed';
    }
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>Database Connection Test</CardTitle>
          <CardDescription>
            This test checks the connection to your database and verifies the availability of key tables.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            {getStatusIcon(testResults.connection)}
            <span>Database Connection: {getStatusText(testResults.connection)}</span>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Table Tests:</h4>
            {Object.entries(testResults.tables).map(([table, status]) => (
              <div key={table} className="flex items-center gap-2">
                {getStatusIcon(status)}
                <span className="capitalize">{table.replace('_', ' ')}: {getStatusText(status)}</span>
              </div>
            ))}
          </div>

          <Button onClick={testDatabaseConnection} className="mt-4">
            Retest Connection
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default DatabaseTest; 