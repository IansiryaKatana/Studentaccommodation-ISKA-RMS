
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Palette, Plus, Edit, Trash2, Save, Loader2, Eye } from 'lucide-react';

import { useToast } from '@/hooks/use-toast';
import { ApiService } from '@/services/api';

interface ModuleStyle {
  id: string;
  name: string;
  description: string;
  module: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  font_family: string;
  font_size: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const ModuleStylesManagement = () => {
  const [styles, setStyles] = useState<ModuleStyle[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingStyle, setEditingStyle] = useState<ModuleStyle | null>(null);
  const [newStyle, setNewStyle] = useState<Partial<ModuleStyle>>({
    name: '',
    description: '',
    module: '',
    primary_color: '#3b82f6',
    secondary_color: '#64748b',
    accent_color: '#8b5cf6',
    font_family: 'Inter',
    font_size: '14px',
    is_active: true
  });
  const { toast } = useToast();

  const modules = [
    'leads', 'reservations', 'students', 'cleaning', 'finance', 'data', 'settings', 'student-portal'
  ];

  const fontFamilies = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Poppins', 'Montserrat', 'Source Sans Pro', 'Nunito'
  ];

  const fontSizes = ['12px', '14px', '16px', '18px', '20px'];

  useEffect(() => {
    fetchStyles();
  }, []);

  const fetchStyles = async () => {
    try {
      setIsLoading(true);
      const stylesData = await ApiService.getModuleStyles();
      setStyles(stylesData);
    } catch (error) {
      console.error('Error fetching module styles:', error);
      toast({
        title: "Error",
        description: "Failed to load module styles. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddStyle = async () => {
    if (!newStyle.name || !newStyle.module) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSaving(true);
      
      const createdStyle: ModuleStyle = {
        id: Date.now().toString(),
        name: newStyle.name!,
        description: newStyle.description!,
        module: newStyle.module!,
        primary_color: newStyle.primary_color!,
        secondary_color: newStyle.secondary_color!,
        accent_color: newStyle.accent_color!,
        font_family: newStyle.font_family!,
        font_size: newStyle.font_size!,
        is_active: newStyle.is_active!,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      // In a real implementation, you would save to the database
      // const savedStyle = await ApiService.createModuleStyle(createdStyle);
      
      setStyles([...styles, createdStyle]);
      setShowAddDialog(false);
      setNewStyle({
        name: '',
        description: '',
        module: '',
        primary_color: '#3b82f6',
        secondary_color: '#64748b',
        accent_color: '#8b5cf6',
        font_family: 'Inter',
        font_size: '14px',
        is_active: true
      });
      
      toast({
        title: "Success",
        description: "Module style created successfully.",
      });
    } catch (error) {
      console.error('Error creating style:', error);
      toast({
        title: "Error",
        description: "Failed to create module style. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateStyle = async () => {
    if (!editingStyle) return;

    try {
      setIsSaving(true);
      
      // In a real implementation, you would update in the database
      // await ApiService.updateModuleStyle(editingStyle.id, editingStyle);
      
      const updatedStyles = styles.map(style => 
        style.id === editingStyle.id ? { ...editingStyle, updated_at: new Date().toISOString() } : style
      );
      
      setStyles(updatedStyles);
      setEditingStyle(null);
      
      toast({
        title: "Success",
        description: "Module style updated successfully.",
      });
    } catch (error) {
      console.error('Error updating style:', error);
      toast({
        title: "Error",
        description: "Failed to update module style. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteStyle = async (id: string) => {
    try {
      setIsSaving(true);
      
      // In a real implementation, you would delete from the database
      // await ApiService.deleteModuleStyle(id);
      
      setStyles(styles.filter(style => style.id !== id));
      
      toast({
        title: "Success",
        description: "Module style deleted successfully.",
      });
    } catch (error) {
      console.error('Error deleting style:', error);
      toast({
        title: "Error",
        description: "Failed to delete module style. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const getModuleLabel = (module: string) => {
    const labels: Record<string, string> = {
      leads: 'Leads Management',
      reservations: 'Reservations',
      students: 'Students',
      cleaning: 'Cleaning',
      finance: 'Finance',
      data: 'Data Management',
      settings: 'Settings',
      'student-portal': 'Student Portal'
    };
    return labels[module] || module;
  };

  const ColorPreview = ({ color }: { color: string }) => (
    <div 
      className="w-6 h-6 rounded border border-gray-300"
      style={{ backgroundColor: color }}
    />
  );

  if (isLoading) {
    return (
      <div className="space-y-6 p-6">
        <div className="flex items-center space-x-4">
          <Link to="/data">
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Data
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Module Styles Management</h1>
            <p className="text-muted-foreground">Customize module colors and fonts with live preview</p>
          </div>
        </div>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Module Styles Management</h1>
          <p className="text-muted-foreground">Customize module colors and fonts with live preview</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Style
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {styles.map((style) => (
          <Card key={style.id} className="relative">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <Palette className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <CardTitle className="text-lg">{style.name}</CardTitle>
                    <CardDescription>{style.description}</CardDescription>
                  </div>
                </div>
                <Badge variant={style.is_active ? "default" : "secondary"}>
                  {style.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Module */}
                <div className="space-y-2">
                  <p className="text-sm font-medium">Module:</p>
                  <Badge variant="outline">{getModuleLabel(style.module)}</Badge>
                </div>

                {/* Colors */}
                <div className="space-y-2">
                  <p className="text-sm font-medium">Colors:</p>
                  <div className="flex space-x-2">
                    <div className="flex items-center space-x-1">
                      <ColorPreview color={style.primary_color} />
                      <span className="text-xs text-muted-foreground">Primary</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <ColorPreview color={style.secondary_color} />
                      <span className="text-xs text-muted-foreground">Secondary</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <ColorPreview color={style.accent_color} />
                      <span className="text-xs text-muted-foreground">Accent</span>
                    </div>
                  </div>
                </div>

                {/* Font */}
                <div className="space-y-2">
                  <p className="text-sm font-medium">Font:</p>
                  <div className="text-sm text-muted-foreground">
                    {style.font_family} • {style.font_size}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex space-x-2 pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingStyle(style)}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteStyle(style.id)}
                    disabled={isSaving}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add Style Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Module Style</DialogTitle>
            <DialogDescription>
              Create a new style configuration for a module
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="styleName">Style Name</Label>
              <Input
                id="styleName"
                value={newStyle.name}
                onChange={(e) => setNewStyle({ ...newStyle, name: e.target.value })}
                placeholder="Enter style name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="styleDescription">Description</Label>
              <Textarea
                id="styleDescription"
                value={newStyle.description}
                onChange={(e) => setNewStyle({ ...newStyle, description: e.target.value })}
                placeholder="Enter style description"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="styleModule">Module</Label>
              <Select value={newStyle.module} onValueChange={(value) => setNewStyle({ ...newStyle, module: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select module" />
                </SelectTrigger>
                <SelectContent>
                  {modules.map((module) => (
                    <SelectItem key={module} value={module}>
                      {getModuleLabel(module)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="primaryColor">Primary Color</Label>
                <div className="flex space-x-2">
                  <Input
                    id="primaryColor"
                    type="color"
                    value={newStyle.primary_color}
                    onChange={(e) => setNewStyle({ ...newStyle, primary_color: e.target.value })}
                    className="w-12 h-10"
                  />
                  <Input
                    value={newStyle.primary_color}
                    onChange={(e) => setNewStyle({ ...newStyle, primary_color: e.target.value })}
                    placeholder="#3b82f6"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="secondaryColor">Secondary Color</Label>
                <div className="flex space-x-2">
                  <Input
                    id="secondaryColor"
                    type="color"
                    value={newStyle.secondary_color}
                    onChange={(e) => setNewStyle({ ...newStyle, secondary_color: e.target.value })}
                    className="w-12 h-10"
                  />
                  <Input
                    value={newStyle.secondary_color}
                    onChange={(e) => setNewStyle({ ...newStyle, secondary_color: e.target.value })}
                    placeholder="#64748b"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accentColor">Accent Color</Label>
                <div className="flex space-x-2">
                  <Input
                    id="accentColor"
                    type="color"
                    value={newStyle.accent_color}
                    onChange={(e) => setNewStyle({ ...newStyle, accent_color: e.target.value })}
                    className="w-12 h-10"
                  />
                  <Input
                    value={newStyle.accent_color}
                    onChange={(e) => setNewStyle({ ...newStyle, accent_color: e.target.value })}
                    placeholder="#8b5cf6"
                  />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fontFamily">Font Family</Label>
                <Select value={newStyle.font_family} onValueChange={(value) => setNewStyle({ ...newStyle, font_family: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fontFamilies.map((font) => (
                      <SelectItem key={font} value={font}>
                        {font}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="fontSize">Font Size</Label>
                <Select value={newStyle.font_size} onValueChange={(value) => setNewStyle({ ...newStyle, font_size: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fontSizes.map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddStyle} disabled={isSaving}>
                {isSaving ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4 mr-2" />
                )}
                Create Style
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Style Dialog */}
      <Dialog open={!!editingStyle} onOpenChange={() => setEditingStyle(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Module Style</DialogTitle>
            <DialogDescription>
              Update style configuration and colors
            </DialogDescription>
          </DialogHeader>
          {editingStyle && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="editStyleName">Style Name</Label>
                <Input
                  id="editStyleName"
                  value={editingStyle.name}
                  onChange={(e) => setEditingStyle({ ...editingStyle, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editStyleDescription">Description</Label>
                <Textarea
                  id="editStyleDescription"
                  value={editingStyle.description}
                  onChange={(e) => setEditingStyle({ ...editingStyle, description: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editStyleModule">Module</Label>
                <Select value={editingStyle.module} onValueChange={(value) => setEditingStyle({ ...editingStyle, module: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {modules.map((module) => (
                      <SelectItem key={module} value={module}>
                        {getModuleLabel(module)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editPrimaryColor">Primary Color</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="editPrimaryColor"
                      type="color"
                      value={editingStyle.primary_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, primary_color: e.target.value })}
                      className="w-12 h-10"
                    />
                    <Input
                      value={editingStyle.primary_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, primary_color: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editSecondaryColor">Secondary Color</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="editSecondaryColor"
                      type="color"
                      value={editingStyle.secondary_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, secondary_color: e.target.value })}
                      className="w-12 h-10"
                    />
                    <Input
                      value={editingStyle.secondary_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, secondary_color: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editAccentColor">Accent Color</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="editAccentColor"
                      type="color"
                      value={editingStyle.accent_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, accent_color: e.target.value })}
                      className="w-12 h-10"
                    />
                    <Input
                      value={editingStyle.accent_color}
                      onChange={(e) => setEditingStyle({ ...editingStyle, accent_color: e.target.value })}
                    />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editFontFamily">Font Family</Label>
                  <Select value={editingStyle.font_family} onValueChange={(value) => setEditingStyle({ ...editingStyle, font_family: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {fontFamilies.map((font) => (
                        <SelectItem key={font} value={font}>
                          {font}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editFontSize">Font Size</Label>
                  <Select value={editingStyle.font_size} onValueChange={(value) => setEditingStyle({ ...editingStyle, font_size: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {fontSizes.map((size) => (
                        <SelectItem key={size} value={size}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setEditingStyle(null)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateStyle} disabled={isSaving}>
                  {isSaving ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Update Style
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ModuleStylesManagement;
