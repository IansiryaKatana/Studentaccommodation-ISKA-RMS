# 🗄️ Supabase Storage Setup Guide

## Overview

This guide explains how to set up Supabase Storage for the ISKA RMS application to enable secure file storage and configuration management.

## Why Manual Setup?

Due to Row Level Security (RLS) policies, the application cannot automatically create storage buckets. You need to create the bucket manually in the Supabase Dashboard.

## Step-by-Step Setup

### 1. Access Supabase Dashboard

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your ISKA RMS project
3. Navigate to **Storage** in the left sidebar

### 2. Create Storage Bucket

1. Click **"New bucket"** button
2. Enter the following details:
   - **Name**: `iska-rms-files`
   - **Public bucket**: ❌ **Unchecked** (Keep private)
   - **File size limit**: `50 MB`
   - **Allowed MIME types**: Leave empty (will use default)

3. Click **"Create bucket"**

### 3. Configure Bucket Policies (Optional)

For enhanced security, you can configure RLS policies:

1. Go to **Storage** → **Policies**
2. Select the `iska-rms-files` bucket
3. Click **"New policy"**

#### Example Policy for Authenticated Users:
```sql
-- Allow authenticated users to upload files
CREATE POLICY "Allow authenticated uploads" ON storage.objects
FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Allow authenticated users to view their own files
CREATE POLICY "Allow authenticated reads" ON storage.objects
FOR SELECT USING (auth.role() = 'authenticated');

-- Allow authenticated users to update their own files
CREATE POLICY "Allow authenticated updates" ON storage.objects
FOR UPDATE USING (auth.role() = 'authenticated');
```

### 4. Test Storage

1. Go to **Settings** → **Config Management** in your ISKA RMS application
2. Try uploading a Stripe configuration
3. Check the browser console for success messages

## Troubleshooting

### Storage Not Available
- **Error**: "StorageApiError: new row violates row-level security policy"
- **Solution**: Create the bucket manually as described above

### File Upload Fails
- **Error**: "File type not allowed"
- **Solution**: The bucket is configured correctly, but file type validation is working

### Configuration Not Loading
- **Error**: "Configuration file not found"
- **Solution**: Upload your configuration first using the Config Management UI

## Fallback System

The application includes a fallback system:

1. **Primary**: Supabase Storage (secure, persistent)
2. **Fallback**: Browser localStorage (temporary, less secure)

If storage is not available, configurations will be saved to localStorage automatically.

## Security Considerations

### Storage Security
- Files are stored in private buckets
- Access is restricted to authenticated users
- RLS policies can be configured for fine-grained control

### Configuration Security
- Stripe keys are encrypted at rest in Supabase
- Keys are masked in the UI
- Access is logged for audit purposes

## Next Steps

1. **Create the storage bucket** following the steps above
2. **Test the configuration upload** in the Config Management UI
3. **Upload your Stripe keys** to enable payment processing
4. **Monitor storage usage** in the Supabase Dashboard

## Support

If you encounter issues:
1. Check the browser console for error messages
2. Verify the bucket name is exactly `iska-rms-files`
3. Ensure the bucket is private (not public)
4. Contact support if problems persist

---

**Note**: Once the storage bucket is created, the application will automatically use it for all file operations. The fallback to localStorage ensures the app continues to work even if storage is temporarily unavailable. 