import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Users, 
  Building, 
  Calendar, 
  UserCheck, 
  Plus,
  GraduationCap,
  CreditCard,
  CheckCircle,
  Clock
} from 'lucide-react';
import { ApiService } from '@/services/api';

const StudentsOverview = () => {
  const [stats, setStats] = useState({
    totalStudents: 0,
    activeStudents: 0,
    assignedStudios: 0,
    pendingCheckIns: 0,
    totalRevenue: 0,
    completedPayments: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setIsLoading(true);
      const students = await ApiService.getStudents();
      
      // Calculate basic stats
      const totalStudents = students.length;
      const activeStudents = students.filter(s => s.user.is_active).length;
      const assignedStudios = students.filter(s => s.studio_id).length;
      const pendingCheckIns = students.filter(s => !s.checked_in).length;
      
      // Calculate revenue from invoices and reservations
      let totalRevenue = 0;
      let completedPayments = 0;
      
      try {
        // Get all invoices to calculate total revenue
        const allInvoices = await ApiService.getInvoices();
        
        // Get all student reservations to calculate revenue
        const allReservations = await ApiService.getReservations();
        const studentReservations = allReservations.filter(r => r.type === 'student');
        
        // Calculate total revenue from student reservations
        totalRevenue = studentReservations.reduce((sum, reservation) => {
          return sum + (reservation.total_amount || 0);
        }, 0);
        
        // Calculate completed payments from student-related invoices
        const studentInvoices = allInvoices.filter(invoice => {
          // Check if this invoice is for a student (either through reservation or direct student invoice)
          return studentReservations.some(res => res.id === invoice.reservation_id) || 
                 invoice.reservation_id === null; // Direct student invoices have null reservation_id
        });
        
        completedPayments = studentInvoices.filter(invoice => 
          invoice.status === 'completed'
        ).length;
        
        console.log('Revenue calculation:', {
          studentReservations: studentReservations.length,
          totalRevenue,
          studentInvoices: studentInvoices.length,
          completedPayments
        });
        
      } catch (error) {
        console.error('Error calculating revenue:', error);
        // Continue with basic stats even if revenue calculation fails
      }
      
      setStats({
        totalStudents,
        activeStudents,
        assignedStudios,
        pendingCheckIns,
        totalRevenue,
        completedPayments
      });
    } catch (error) {
      console.error('Error fetching student stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'Add Student Booking',
      description: 'Create a new student reservation',
      icon: Plus,
      path: '/students/add-booking',
      color: 'bg-green-500'
    },
    {
      title: 'Manage Studios',
      description: 'View and assign student studios',
      icon: Building,
      path: '/students/studios',
      color: 'bg-blue-500'
    },
    {
      title: 'Calendar View',
      description: 'Check-in/out schedule',
      icon: Calendar,
      path: '/students/calendar',
      color: 'bg-purple-500'
    },
    {
      title: 'Check-in/Check-out',
      description: 'Process arrivals and departures',
      icon: UserCheck,
      path: '/students/checkin-checkout',
      color: 'bg-orange-500'
    }
  ];

  const statsCards = [
    {
      title: 'Total Students',
      value: stats.totalStudents,
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      title: 'Active Students',
      value: stats.activeStudents,
      icon: GraduationCap,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      title: 'Assigned Studios',
      value: stats.assignedStudios,
      icon: Building,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      title: 'Total Revenue',
      value: `£${stats.totalRevenue.toLocaleString()}`,
      icon: CreditCard,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      title: 'Completed Payments',
      value: stats.completedPayments,
      icon: CheckCircle,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      title: 'Pending Check-ins',
      value: stats.pendingCheckIns,
      icon: Clock,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Students Overview</h1>
          <p className="text-gray-600 mt-1">Manage student records and accommodations</p>
        </div>
        <Link to="/students/add-booking">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Student Booking
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        {statsCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {isLoading ? '...' : stat.value}
                    </p>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link key={index} to={action.path}>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`p-3 rounded-full ${action.color} mb-4`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">{action.title}</h3>
                      <p className="text-sm text-gray-600">{action.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Student Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <GraduationCap className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Recent student activities will appear here</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentsOverview;