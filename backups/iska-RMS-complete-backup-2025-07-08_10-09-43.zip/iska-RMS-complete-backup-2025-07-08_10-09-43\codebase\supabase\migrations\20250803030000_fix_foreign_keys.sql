-- =====================================================
-- FIX FOREIGN KEY RELATIONSHIPS
-- =====================================================

-- Drop existing foreign key constraints if they exist
ALTER TABLE reservations DROP CONSTRAINT IF EXISTS reservations_student_id_fkey;
ALTER TABLE reservations DROP CONSTRAINT IF EXISTS reservations_tourist_id_fkey;
ALTER TABLE reservations DROP CONSTRAINT IF EXISTS reservations_studio_id_fkey;
ALTER TABLE reservations DROP CONSTRAINT IF EXISTS reservations_duration_id_fkey;

-- Clean up orphaned reservations (those referencing non-existent students/tourists/studios)
UPDATE reservations SET student_id = NULL WHERE student_id NOT IN (SELECT id FROM students);
UPDATE reservations SET tourist_id = NULL WHERE tourist_id NOT IN (SELECT id FROM tourist_profiles);
UPDATE reservations SET studio_id = NULL WHERE studio_id NOT IN (SELECT id FROM studios);

-- Re-add foreign key constraints
ALTER TABLE reservations 
ADD CONSTRAINT reservations_student_id_fkey 
FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE SET NULL;

ALTER TABLE reservations 
ADD CONSTRAINT reservations_tourist_id_fkey 
FOREIGN KEY (tourist_id) REFERENCES tourist_profiles(id) ON DELETE SET NULL;

ALTER TABLE reservations 
ADD CONSTRAINT reservations_studio_id_fkey 
FOREIGN KEY (studio_id) REFERENCES studios(id) ON DELETE SET NULL;

ALTER TABLE reservations 
ADD CONSTRAINT reservations_duration_id_fkey 
FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE RESTRICT;

-- Ensure the durations table exists and has the correct structure
CREATE TABLE IF NOT EXISTS durations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL, -- '45-weeks', '51-weeks', 'Daily', 'Weekly'
    duration_type VARCHAR(20) NOT NULL, -- 'student', 'tourist'
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    weeks_count INTEGER NOT NULL,
    academic_year VARCHAR(20), -- '2025/2026', '2026/2027'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add some sample duration data if it doesn't exist
INSERT INTO durations (name, duration_type, check_in_date, check_out_date, weeks_count, academic_year, is_active) 
SELECT * FROM (VALUES
('45-weeks', 'student', '2025-09-15'::DATE, '2026-07-20'::DATE, 45, '2025/2026', true),
('51-weeks', 'student', '2025-09-15'::DATE, '2026-08-31'::DATE, 51, '2025/2026', true),
('Daily', 'tourist', '2025-01-01'::DATE, '2025-01-02'::DATE, 1, NULL, true),
('Weekly', 'tourist', '2025-01-01'::DATE, '2025-01-08'::DATE, 1, NULL, true)
) AS v(name, duration_type, check_in_date, check_out_date, weeks_count, academic_year, is_active)
WHERE NOT EXISTS (SELECT 1 FROM durations WHERE durations.name = v.name);

-- Ensure room_grades table has data
INSERT INTO room_grades (name, weekly_rate, studio_count, description, is_active)
SELECT * FROM (VALUES
('Silver', 150.00, 10, 'Standard studio accommodation', true),
('Gold', 180.00, 8, 'Premium studio with enhanced amenities', true),
('Platinum', 220.00, 6, 'Luxury studio with premium features', true),
('Rhodium', 280.00, 4, 'Ultra-luxury studio with exclusive amenities', true),
('Thodium Plus', 350.00, 2, 'The ultimate luxury studio experience', true)
) AS v(name, weekly_rate, studio_count, description, is_active)
WHERE NOT EXISTS (SELECT 1 FROM room_grades WHERE room_grades.name = v.name); 