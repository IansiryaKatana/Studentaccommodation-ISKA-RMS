
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface ModuleCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
  onClick: () => void;
  accessGranted: boolean;
}

const ModuleCard: React.FC<ModuleCardProps> = ({
  title,
  description,
  icon: Icon,
  gradient,
  onClick,
  accessGranted
}) => {
  return (
    <Card
      className={`module-card cursor-pointer overflow-hidden border-0 ${
        !accessGranted ? 'opacity-50 cursor-not-allowed' : ''
      }`}
      onClick={accessGranted ? onClick : undefined}
    >
      <div className={`h-2 ${gradient}`} />
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <div className={`p-3 rounded-xl ${gradient} bg-opacity-10`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-gray-900 truncate">
              {title}
            </h3>
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
              {description}
            </p>
            {!accessGranted && (
              <p className="text-xs text-red-500 mt-2">
                Access restricted
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModuleCard;
