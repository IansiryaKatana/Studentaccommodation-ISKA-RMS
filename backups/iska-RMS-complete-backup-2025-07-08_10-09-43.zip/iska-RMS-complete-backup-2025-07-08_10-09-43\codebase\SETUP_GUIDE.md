# ISKA RMS - Complete Setup Guide

## 🚀 System Overview

ISKA RMS is a comprehensive property management system built with:
- **Frontend**: React + TypeScript + Vite
- **UI Framework**: shadcn/ui + Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Payments**: Stripe
- **State Management**: TanStack Query
- **Routing**: React Router DOM

## 📋 Prerequisites

- Node.js 18+ 
- npm or yarn
- Supabase account
- Stripe account (for payments)

## 🛠️ Installation Steps

### 1. Clone and Install Dependencies

```bash
# Install all dependencies including Stripe
npm install

# Install additional dependencies if needed
npm install @types/node @types/react @types/react-dom
```

### 2. Environment Setup

Create a `.env` file in the root directory:

```bash
# Copy the example file
cp env.example .env
```

Update the `.env` file with your actual credentials:

```env
# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe Configuration
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key
VITE_STRIPE_SECRET_KEY=sk_test_your_secret_key
VITE_STRIPE_API_BASE=https://api.stripe.com/v1

# Application Configuration
VITE_APP_NAME=ISKA RMS
VITE_APP_VERSION=1.0.0
VITE_APP_ENV=development
```

### 3. Database Setup

#### A. Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Note down your project URL and anon key

#### B. Run Database Schema
1. Go to your Supabase dashboard
2. Navigate to SQL Editor
3. Copy and paste the entire content from `supabase/schema.sql`
4. Execute the SQL script

#### C. Update Supabase Types
After running the schema, generate updated types:

```bash
# Install Supabase CLI if not already installed
npm install -g supabase

# Generate types (you'll need to configure this with your project)
supabase gen types typescript --project-id your-project-id > src/integrations/supabase/types.ts
```

### 4. Stripe Setup

#### A. Create Stripe Account
1. Go to [stripe.com](https://stripe.com)
2. Create an account and get your API keys
3. Update your `.env` file with the keys

#### B. Configure Webhooks (Optional)
For production, set up webhooks to handle payment events:

```bash
# Webhook endpoints to configure:
POST /api/stripe/webhook
```

### 5. Start Development Server

```bash
npm run dev
```

The application will be available at `http://localhost:5173`

## 🏗️ System Architecture

### Core Modules

1. **Authentication & Users**
   - User management with roles
   - Secure login/logout
   - Role-based access control

2. **Leads Management**
   - Lead capture and tracking
   - Follow-up management
   - Lead source tracking
   - Status progression

3. **Reservations & Bookings**
   - Student bookings
   - Tourist bookings
   - Room management
   - Check-in/out process
   - Calendar view

4. **Finance & Payments**
   - Invoice generation
   - Stripe payment processing
   - Payment tracking
   - Financial reports

5. **Cleaning Management**
   - Cleaning schedules
   - Cleaner management
   - Task tracking
   - Quality verification

6. **Data Management**
   - System configuration
   - Room grades and pricing
   - Duration management
   - Custom fields

7. **Settings**
   - User management
   - System preferences
   - Security settings
   - Integration settings

### Database Tables

The system includes 20+ tables covering:

- **Users & Authentication**: `users`, `user_roles`
- **Leads**: `leads`, `lead_sources`, `lead_follow_ups`
- **Property**: `rooms`, `room_grades`
- **Bookings**: `bookings`, `students`, `tourist_profiles`
- **Finance**: `invoices`, `payments`, `installment_plans`
- **Cleaning**: `cleaning_tasks`, `cleaners`
- **Maintenance**: `maintenance_requests`, `maintenance_categories`
- **System**: `durations`, `pricing_matrix`, `module_styles`
- **Audit**: `audit_log`, `notifications`

## 🔧 Development Workflow

### 1. Database Changes
When making database changes:

1. Update the schema in `supabase/schema.sql`
2. Run the changes in Supabase SQL Editor
3. Regenerate types: `supabase gen types typescript`
4. Update API service layer in `src/services/api.ts`

### 2. Component Development
Follow the existing patterns:

- Use shadcn/ui components
- Implement mobile responsiveness
- Follow the gradient color scheme
- Use proper TypeScript types

### 3. API Integration
Use the `ApiService` class for all database operations:

```typescript
import { ApiService } from '@/services/api';

// Example usage
const leads = await ApiService.getLeads();
const newLead = await ApiService.createLead(leadData);
```

### 4. Payment Integration
Use the `StripeService` for payment operations:

```typescript
import { StripeService } from '@/integrations/stripe/service';

// Example usage
const paymentIntent = await StripeService.createPaymentIntent({
  amount: 1000,
  currency: 'gbp',
  booking_id: 'booking-id',
  customer_email: 'customer@example.com'
});
```

## 📱 Mobile Responsiveness

The system is built with mobile-first design:

- **Desktop**: Full sidebar navigation
- **Tablet**: Collapsible sidebar
- **Mobile**: Bottom navigation or drawer

Key responsive features:
- Flex layouts for forms
- Dialog forms enter from bottom
- Responsive grid systems
- Touch-friendly interfaces

## 🔒 Security Features

- Row Level Security (RLS) enabled on all tables
- Role-based access control
- Secure authentication
- Input validation and sanitization
- Audit logging for all changes

## 🚀 Deployment

### Development
```bash
npm run dev
```

### Production Build
```bash
npm run build
npm run preview
```

### Environment Variables for Production
Ensure all environment variables are set in your production environment:
- Supabase credentials
- Stripe keys
- Application configuration

## 📊 Monitoring & Analytics

The system includes:
- Audit logging for all database changes
- User activity tracking
- Payment transaction logging
- Error monitoring capabilities

## 🔄 Data Migration

For existing data migration:
1. Export data from current system
2. Transform to match new schema
3. Import using Supabase data import tools
4. Verify data integrity

## 🆘 Troubleshooting

### Common Issues

1. **Supabase Connection Errors**
   - Verify environment variables
   - Check Supabase project status
   - Ensure RLS policies are configured

2. **Stripe Payment Errors**
   - Verify API keys
   - Check webhook configuration
   - Ensure proper error handling

3. **TypeScript Errors**
   - Regenerate Supabase types
   - Check import paths
   - Verify type definitions

### Support

For technical support:
1. Check the console for error messages
2. Verify all environment variables
3. Ensure database schema is properly applied
4. Check network connectivity

## 📈 Future Enhancements

Planned features:
- Advanced reporting dashboard
- Email automation
- SMS notifications
- Mobile app
- Advanced analytics
- Multi-property support
- API for third-party integrations

---

**Note**: This is a comprehensive property management system. Ensure you have proper backups and testing procedures before deploying to production. 