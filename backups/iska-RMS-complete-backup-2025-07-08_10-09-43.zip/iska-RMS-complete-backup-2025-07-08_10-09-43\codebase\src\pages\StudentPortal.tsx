
import React from 'react';
import { Routes, Route, useParams } from 'react-router-dom';
import StudentOverview from '@/components/student-portal/StudentOverview';
import StudentPayments from '@/components/student-portal/StudentPayments';
import StudentProfile from '@/components/student-portal/StudentProfile';
import StudentMaintenance from '@/components/student-portal/StudentMaintenance';
import StudentAgreements from '@/components/student-portal/StudentAgreements';

const StudentPortal = () => {
  const { studentId } = useParams();

  // Use the provided student ID or default to a mock student ID for demo
  const actualStudentId = studentId || 'demo-student-123';

  // For demo purposes, we'll use a mock student ID if none is provided
  if (!studentId) {
    console.log('No student ID provided, using demo student ID:', actualStudentId);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route index element={<StudentOverview studentId={actualStudentId} />} />
        <Route path="payments" element={<StudentPayments studentId={actualStudentId} />} />
        <Route path="profile" element={<StudentProfile studentId={actualStudentId} />} />
        <Route path="maintenance" element={<StudentMaintenance studentId={actualStudentId} />} />
        <Route path="agreements" element={<StudentAgreements studentId={actualStudentId} />} />
      </Routes>
    </div>
  );
};

export default StudentPortal;
