
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Save, User, GraduationCap, CreditCard, Calendar, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ApiService } from '@/services/api';

interface OptionField {
  id: string;
  name: string;
  field_type: string;
  options?: string[];
  is_active: boolean;
}

interface InstallmentPlan {
  id: string;
  name: string;
  description?: string;
  number_of_installments: number;
  discount_percentage: number;
  is_active: boolean;
}

const AddStudent = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);
  
  // Dynamic data from database
  const [universities, setUniversities] = useState<OptionField[]>([]);
  const [courses, setCourses] = useState<OptionField[]>([]);
  const [roomGrades, setRoomGrades] = useState<any[]>([]);
  const [installmentPlans, setInstallmentPlans] = useState<InstallmentPlan[]>([]);
  const [depositOptions] = useState([
    { value: 'true', label: 'Yes' },
    { value: 'false', label: 'No' }
  ]);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    university: '',
    course: '',
    studentId: '',
    emergencyContact: '',
    emergencyPhone: '',
    roomGrade: '',
    depositPaid: '',
    checkInDate: '',
    checkOutDate: '',
    paymentPlan: '',
    specialRequirements: '',
    documents: ''
  });

  useEffect(() => {
    fetchFormData();
  }, []);

  const fetchFormData = async () => {
    try {
      setIsDataLoading(true);
      
      // Fetch all required data from database
      const [studentOptionFields, roomGradesData, installmentPlansData] = await Promise.all([
        ApiService.getStudentOptionFields(),
        ApiService.getRoomGrades(),
        ApiService.getInstallmentPlans()
      ]);

      // Filter and organize option fields
      const universityField = studentOptionFields.find(field => 
        field.name.toLowerCase().includes('university') || 
        field.field_type === 'university'
      );
      const courseField = studentOptionFields.find(field => 
        field.name.toLowerCase().includes('course') || 
        field.field_type === 'course'
      );

      setUniversities(universityField ? [universityField] : []);
      setCourses(courseField ? [courseField] : []);
      setRoomGrades(roomGradesData);
      setInstallmentPlans(installmentPlansData.filter(plan => plan.is_active));
      
    } catch (error) {
      console.error('Error fetching form data:', error);
      toast({
        title: "Error",
        description: "Failed to load form options. Please refresh the page.",
        variant: "destructive",
      });
    } finally {
      setIsDataLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.university) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // First create the user
      const userData = {
        email: formData.email,
        first_name: formData.firstName,
        last_name: formData.lastName,
        phone: formData.phone,
        role: 'student' as const,
        is_active: true
      };
      
      const user = await ApiService.createUser(userData);
      
      // Then create the student profile
      const studentData = {
        user_id: user.id,
        student_id: formData.studentId || `STU${Date.now()}`,
        university: formData.university,
        course: formData.course,
        year_of_study: '1st', // Default to first year
        emergency_contact_name: formData.emergencyContact,
        emergency_contact_phone: formData.emergencyPhone,
        deposit_paid: formData.depositPaid === 'true',
        installment_plan_id: formData.paymentPlan || undefined
      };
      
      await ApiService.createStudent(studentData);
      
      toast({
        title: "Student Added",
        description: "New student record has been successfully created.",
      });
      
      navigate('/students');
    } catch (error) {
      console.error('Error creating student:', error);
      toast({
        title: "Error",
        description: "Failed to create student. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isDataLoading) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
          <p className="ml-2 text-gray-500">Loading form data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => navigate('/students')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Students
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Add New Student</h1>
          <p className="text-gray-600 mt-1">Create a new student record</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange('firstName', e.target.value)}
                  placeholder="Enter first name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange('lastName', e.target.value)}
                  placeholder="Enter last name"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="student@university.edu"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="emergencyContact">Emergency Contact</Label>
                <Input
                  id="emergencyContact"
                  value={formData.emergencyContact}
                  onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                  placeholder="Contact name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyPhone">Emergency Phone</Label>
                <Input
                  id="emergencyPhone"
                  value={formData.emergencyPhone}
                  onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
                  placeholder="+1 (555) 987-6543"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Academic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5" />
              Academic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="university">University *</Label>
                <Select onValueChange={(value) => handleInputChange('university', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select university" />
                  </SelectTrigger>
                  <SelectContent>
                    {universities.length > 0 && universities[0].options ? (
                      universities[0].options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="other">Other</SelectItem>
                        <SelectItem value="custom">Enter custom university</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
                {formData.university === 'custom' && (
                  <Input
                    placeholder="Enter university name"
                    onChange={(e) => handleInputChange('university', e.target.value)}
                    className="mt-2"
                  />
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="course">Course/Program</Label>
                <Select onValueChange={(value) => handleInputChange('course', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.length > 0 && courses[0].options ? (
                      courses[0].options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="other">Other</SelectItem>
                        <SelectItem value="custom">Enter custom course</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
                {formData.course === 'custom' && (
                  <Input
                    placeholder="Enter course name"
                    onChange={(e) => handleInputChange('course', e.target.value)}
                    className="mt-2"
                  />
                )}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="studentId">Student ID</Label>
              <Input
                id="studentId"
                value={formData.studentId}
                onChange={(e) => handleInputChange('studentId', e.target.value)}
                placeholder="University student ID number"
              />
            </div>
          </CardContent>
        </Card>

        {/* Accommodation Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Accommodation Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="checkInDate">Check-in Date</Label>
                <Input
                  id="checkInDate"
                  type="date"
                  value={formData.checkInDate}
                  onChange={(e) => handleInputChange('checkInDate', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="checkOutDate">Check-out Date</Label>
                <Input
                  id="checkOutDate"
                  type="date"
                  value={formData.checkOutDate}
                  onChange={(e) => handleInputChange('checkOutDate', e.target.value)}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="roomGrade">Room Grade</Label>
                <Select onValueChange={(value) => handleInputChange('roomGrade', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select room grade" />
                  </SelectTrigger>
                  <SelectContent>
                    {roomGrades.map((grade) => (
                      <SelectItem key={grade.id} value={grade.id}>
                        {grade.name} - £{grade.weekly_rate}/week
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="depositPaid">Deposit Paid</Label>
                <Select onValueChange={(value) => handleInputChange('depositPaid', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select deposit status" />
                  </SelectTrigger>
                  <SelectContent>
                    {depositOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialRequirements">Special Requirements</Label>
              <Textarea
                id="specialRequirements"
                value={formData.specialRequirements}
                onChange={(e) => handleInputChange('specialRequirements', e.target.value)}
                placeholder="Any special accommodation needs or preferences"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Payment Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Payment Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="paymentPlan">Payment Plan</Label>
              <Select onValueChange={(value) => handleInputChange('paymentPlan', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select payment plan" />
                </SelectTrigger>
                <SelectContent>
                  {installmentPlans.map((plan) => (
                    <SelectItem key={plan.id} value={plan.id}>
                      {plan.name} ({plan.number_of_installments} installments)
                      {plan.discount_percentage > 0 && ` - ${plan.discount_percentage}% discount`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => navigate('/students')}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isLoading ? 'Creating...' : 'Create Student'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default AddStudent;
