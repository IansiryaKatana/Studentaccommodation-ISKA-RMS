import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import PaymentForm from './PaymentForm';

const PaymentTest = () => {
  const { toast } = useToast();
  const [testInvoiceId] = useState('test-invoice-123');
  const [testAmount] = useState(150.00);
  const [testEmail] = useState('test@example.com');

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment Test Successful! 🎉",
      description: "The payment form is working correctly. You can now integrate it into your invoice pages.",
    });
  };

  const handlePaymentCancel = () => {
    toast({
      title: "Payment Cancelled",
      description: "Payment was cancelled by the user.",
    });
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Payment Testing</h1>
          <p className="text-muted-foreground">
            Test the Stripe payment integration with sample data
          </p>
        </div>
        <Link to="/finance">
          <Button variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Finance
          </Button>
        </Link>
      </div>

      {/* Test Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-blue-600" />
            Test Environment
          </CardTitle>
          <CardDescription>
            This page demonstrates the payment form functionality. Use the test card numbers below to simulate payments.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2">Test Card Numbers</h3>
              <div className="space-y-2 text-sm">
                <div className="p-2 bg-gray-50 rounded">
                  <strong>Visa:</strong> 4242424242424242
                </div>
                <div className="p-2 bg-gray-50 rounded">
                  <strong>Mastercard:</strong> 5555555555554444
                </div>
                <div className="p-2 bg-gray-50 rounded">
                  <strong>Amex:</strong> 378282246310005
                </div>
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Test Details</h3>
              <div className="space-y-2 text-sm">
                <div><strong>Expiry:</strong> Any future date</div>
                <div><strong>CVC:</strong> Any 3-4 digits</div>
                <div><strong>Amount:</strong> £{testAmount.toFixed(2)}</div>
                <div><strong>Invoice:</strong> {testInvoiceId}</div>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-yellow-800">
                <strong>Note:</strong> This is a test environment. No real payments will be processed.
                The payment form supports multiple payment methods including card, bank transfer, cash, and check.
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Form */}
      <PaymentForm
        invoiceId={testInvoiceId}
        amount={testAmount}
        customerEmail={testEmail}
        onSuccess={handlePaymentSuccess}
        onCancel={handlePaymentCancel}
      />

      {/* Integration Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Integration Instructions
          </CardTitle>
          <CardDescription>
            How to integrate the payment form into your invoice pages
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <h3 className="font-semibold">1. Import the Component</h3>
            <pre className="bg-gray-100 p-2 rounded text-sm">
{`import PaymentForm from '@/components/finance/PaymentForm';`}
            </pre>
          </div>
          
          <div className="space-y-2">
            <h3 className="font-semibold">2. Use in Your Component</h3>
            <pre className="bg-gray-100 p-2 rounded text-sm">
{`<PaymentForm
  invoiceId="your-invoice-id"
  amount={150.00}
  customerEmail="customer@example.com"
  onSuccess={() => console.log('Payment successful')}
  onCancel={() => console.log('Payment cancelled')}
/>`}
            </pre>
          </div>
          
          <div className="space-y-2">
            <h3 className="font-semibold">3. Configure Stripe Keys</h3>
            <p className="text-sm text-muted-foreground">
              Update your <code className="bg-gray-100 px-1 rounded">.env</code> file with your Stripe test keys:
            </p>
            <pre className="bg-gray-100 p-2 rounded text-sm">
{`VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
VITE_STRIPE_SECRET_KEY=sk_test_your_key_here`}
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* Features List */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Form Features</CardTitle>
          <CardDescription>
            Comprehensive payment processing capabilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h3 className="font-semibold">Payment Methods</h3>
              <ul className="space-y-1 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Credit/Debit Cards (Stripe)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Bank Transfer
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Cash
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Check
                </li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-semibold">Features</h3>
              <ul className="space-y-1 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Secure card input
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Error handling
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Loading states
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Mobile responsive
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentTest; 