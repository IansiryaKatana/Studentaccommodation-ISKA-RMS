
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ApiService, StudentWithUser, Reservation } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { User, Mail, Phone, MapPin, FileText, Calendar, Building, CreditCard, Shield, Loader2 } from 'lucide-react';

interface StudentProfileProps {
  studentId: string;
}

const StudentProfile = ({ studentId }: StudentProfileProps) => {
  const { toast } = useToast();
  const [student, setStudent] = useState<StudentWithUser | null>(null);
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStudentData();
  }, [studentId]);

  const fetchStudentData = async () => {
    try {
      setIsLoading(true);
      const [studentData, reservationData] = await Promise.all([
        ApiService.getStudentById(studentId),
        ApiService.getReservationByStudentId(studentId)
      ]);
      
      setStudent(studentData);
      setReservation(reservationData);
    } catch (error) {
      console.error('Error fetching student data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch student data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
        <p className="mt-2 text-sm text-gray-500">Loading student profile...</p>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="p-6 text-center">
        <p className="text-gray-500">Student not found</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Student Profile</h1>
        <p className="text-gray-600">View and manage student information</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="h-5 w-5 mr-2" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">First Name</label>
                <p className="text-sm">{student.user.first_name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Last Name</label>
                <p className="text-sm">{student.user.last_name}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Student ID</label>
                <p className="text-sm">{student.student_id}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">University</label>
                <p className="text-sm">{student.university}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Course</label>
                <p className="text-sm">{student.course}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Year of Study</label>
                <p className="text-sm">{student.year_of_study}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Email</label>
                <p className="text-sm">{student.user.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Phone</label>
                <p className="text-sm">{student.user.phone || 'N/A'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              Contact Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Email</label>
              <p className="text-sm">{student.user.email}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Phone</label>
              <p className="text-sm">{student.user.phone || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Emergency Contact</label>
              <p className="text-sm">{student.emergency_contact_name}</p>
              <p className="text-sm">{student.emergency_contact_phone}</p>
            </div>
          </CardContent>
        </Card>

        {/* Academic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Academic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">University</label>
              <p className="text-sm">{student.university}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Course</label>
              <p className="text-sm">{student.course}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Year of Study</label>
              <p className="text-sm">{student.year_of_study}</p>
            </div>
          </CardContent>
        </Card>

        {/* Reservation Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building className="h-5 w-5 mr-2" />
              Reservation Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Studio ID</label>
                <p className="text-sm font-mono">{reservation?.studio_id || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Check-in Date</label>
                <p className="text-sm">{reservation?.check_in_date || 'N/A'}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Duration</label>
                <p className="text-sm">{reservation?.duration_id || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Total Amount</label>
                <p className="text-sm">£{reservation?.total_amount?.toLocaleString() || 'N/A'}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Status</label>
                <p className="text-sm">{reservation?.status || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Reservation Number</label>
                <p className="text-sm">{reservation?.reservation_number || 'N/A'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Payment Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">Payment Status</label>
              <Badge className="bg-green-100 text-green-800">
                Active
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-600">Reservation Status</label>
              <Badge className={reservation?.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                {reservation?.status || 'N/A'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Guarantor Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Guarantor Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Guarantor Name</label>
              <p className="text-sm">{student.guarantor_name || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Relationship</label>
              <p className="text-sm">{student.guarantor_relationship || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Email</label>
              <p className="text-sm">{student.guarantor_email || 'N/A'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Phone</label>
              <p className="text-sm">{student.guarantor_phone || 'N/A'}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StudentProfile;
