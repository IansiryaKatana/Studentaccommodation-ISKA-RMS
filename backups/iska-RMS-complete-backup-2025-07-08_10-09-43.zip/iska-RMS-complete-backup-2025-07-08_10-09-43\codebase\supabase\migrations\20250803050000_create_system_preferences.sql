-- Create system_preferences table
CREATE TABLE IF NOT EXISTS system_preferences (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  key VARCHAR(255) UNIQUE NOT NULL,
  value TEXT,
  description TEXT,
  category VARCHAR(100) DEFAULT 'general',
  data_type VARCHAR(50) DEFAULT 'string',
  is_public BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Disable RLS for system_preferences table
ALTER TABLE system_preferences DISABLE ROW LEVEL SECURITY;

-- Insert default system preferences
INSERT INTO system_preferences (key, value, description, category, data_type) VALUES
  ('company_name', 'Student Housing Manager', 'Company name displayed throughout the system', 'general', 'string'),
  ('timezone', 'Europe/London', 'Default timezone for the system', 'localization', 'string'),
  ('date_format', 'DD/MM/YYYY', 'Default date format', 'localization', 'string'),
  ('currency', 'GBP', 'Default currency for financial operations', 'localization', 'string'),
  ('language', 'en', 'Default language for the system', 'localization', 'string'),
  ('fiscal_year_start', 'january', 'Fiscal year start month', 'business', 'string'),
  ('default_rent_cycle', 'monthly', 'Default rent cycle for new contracts', 'business', 'string'),
  ('auto_backup', 'true', 'Enable automatic backup', 'system', 'boolean'),
  ('maintenance_mode', 'false', 'Enable maintenance mode', 'system', 'boolean'),
  ('allow_registration', 'false', 'Allow new user registration', 'security', 'boolean'),
  ('require_email_verification', 'true', 'Require email verification for new users', 'security', 'boolean'),
  ('max_file_upload_size', '10485760', 'Maximum file upload size in bytes (10MB)', 'system', 'number'),
  ('session_timeout_minutes', '30', 'Session timeout in minutes', 'security', 'number'),
  ('email_notifications_enabled', 'true', 'Enable email notifications', 'notifications', 'boolean'),
  ('sms_notifications_enabled', 'false', 'Enable SMS notifications', 'notifications', 'boolean')
ON CONFLICT (key) DO NOTHING; 