// Script to create admin user in Supabase
// Run this in your browser console or as a Node.js script

const SUPABASE_URL = "https://vwgczfdedacpymnxzxcp.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ3Z2N6ZmRlZGFjcHltbnh6eGNwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQxMTYzMzksImV4cCI6MjA2OTY5MjMzOX0.-Be0-yqpi5dYGlZF7-5hDWasoyqXzI3VpFlhdnNB7ew";

// Import Supabase client (if running in Node.js)
// const { createClient } = require('@supabase/supabase-js');

// For browser console, use this:
const supabase = window.supabase || createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function createAdminUser() {
  try {
    console.log('Creating admin user...');
    
    // Step 1: Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: 'admin@iska-rms.com',
      password: 'password123',
    });

    if (authError) {
      console.error('Auth error:', authError);
      return;
    }

    console.log('Auth user created:', authData);

    // Step 2: Create user profile in users table
    if (authData.user) {
      const { data: userData, error: userError } = await supabase
        .from('users')
        .insert([
          {
            id: authData.user.id,
            email: 'admin@iska-rms.com',
            first_name: 'Admin',
            last_name: 'User',
            role: 'administrator',
            is_active: true,
            phone: '+1234567890'
          }
        ])
        .select()
        .single();

      if (userError) {
        console.error('User profile error:', userError);
        return;
      }

      console.log('User profile created:', userData);
      console.log('✅ Admin user created successfully!');
      console.log('Email: admin@iska-rms.com');
      console.log('Password: password123');
    }

  } catch (error) {
    console.error('Error creating admin user:', error);
  }
}

// Run the function
createAdminUser(); 