-- Create branding table for company information
CREATE TABLE IF NOT EXISTS branding (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name VARCHAR(255) NOT NULL DEFAULT 'ISKA RMS',
  company_address TEXT,
  company_phone VARCHAR(50),
  company_email VARCHAR(255),
  company_website VARCHAR(255),
  logo_url TEXT,
  favicon_url TEXT,
  primary_color VARCHAR(7) DEFAULT '#3B82F6',
  secondary_color VARCHAR(7) DEFAULT '#1F2937',
  accent_color VARCHAR(7) DEFAULT '#10B981',
  font_family VARCHAR(100) DEFAULT 'Inter',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default branding data
INSERT INTO branding (id, company_name, company_address, company_phone, company_email, company_website, primary_color, secondary_color, accent_color)
VALUES (
  gen_random_uuid(),
  'ISKA RMS',
  '123 Business Street, London, UK, SW1A 1AA',
  '+44 20 1234 5678',
  'info@iska-rms.com',
  'https://iska-rms.com',
  '#3B82F6',
  '#1F2937',
  '#10B981'
)
ON CONFLICT DO NOTHING;

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_branding_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_branding_updated_at
  BEFORE UPDATE ON branding
  FOR EACH ROW
  EXECUTE FUNCTION update_branding_updated_at();

-- Disable RLS for branding table
ALTER TABLE branding DISABLE ROW LEVEL SECURITY; 