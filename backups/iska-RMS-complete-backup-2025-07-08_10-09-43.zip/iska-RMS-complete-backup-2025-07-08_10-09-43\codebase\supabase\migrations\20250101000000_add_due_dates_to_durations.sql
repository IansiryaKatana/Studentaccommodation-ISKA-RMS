-- Migration: Add due_dates and deposit_amount to durations table
-- This script adds the new columns and populates them with sample data

-- Add new columns to durations table
ALTER TABLE durations 
ADD COLUMN IF NOT EXISTS due_dates JSONB DEFAULT '[]',
ADD COLUMN IF NOT EXISTS deposit_amount DECIMAL(10,2) DEFAULT 500.00;

-- Update existing durations with due dates
-- 45 weeks duration (3 installments)
UPDATE durations 
SET due_dates = '["2025-10-01", "2026-01-01", "2026-04-01"]'::jsonb,
    deposit_amount = 500.00
WHERE name = '45-weeks' AND duration_type = 'student' AND academic_year = '2025/2026';

UPDATE durations 
SET due_dates = '["2026-10-01", "2027-01-01", "2027-04-01"]'::jsonb,
    deposit_amount = 500.00
WHERE name = '45-weeks' AND duration_type = 'student' AND academic_year = '2026/2027';

-- 51 weeks duration (4 installments)
UPDATE durations 
SET due_dates = '["2025-10-01", "2026-01-01", "2026-04-01", "2026-07-01"]'::jsonb,
    deposit_amount = 500.00
WHERE name = '51-weeks' AND duration_type = 'student' AND academic_year = '2025/2026';

UPDATE durations 
SET due_dates = '["2026-10-01", "2027-01-01", "2027-04-01", "2027-07-01"]'::jsonb,
    deposit_amount = 500.00
WHERE name = '51-weeks' AND duration_type = 'student' AND academic_year = '2026/2027';

-- Add comments to document the new columns
COMMENT ON COLUMN durations.due_dates IS 'JSONB array of due dates for installments (e.g., ["2025-10-01", "2026-01-01"])';
COMMENT ON COLUMN durations.deposit_amount IS 'Standard deposit amount for this duration in GBP';

-- Create index for better performance on due_dates queries
CREATE INDEX IF NOT EXISTS idx_durations_due_dates ON durations USING GIN (due_dates); 