-- Add sample data for lead option fields
INSERT INTO lead_option_fields (field_name, field_type, field_label, is_required, options, is_active) VALUES
-- Room Grades
('room_grade', 'select', 'Desired Room Grade', true, ARRAY['Silver', 'Gold', 'Platinum', 'Rhodium', 'Thodium Plus'], true),

-- Durations  
('duration', 'select', 'Desired Duration', true, ARRAY['45-weeks', '51-weeks', 'Daily', 'Weekly'], true),

-- Response Categories
('response_category', 'select', 'Response Category', false, ARRAY['Hot', 'Warm', 'Cold'], true),

-- Follow-up Stages
('follow_up_stage', 'select', 'Follow-up Stage', false, ARRAY['Initial Contact', 'Information Sent', 'Proposal Sent', 'Follow-up Needed', 'Negotiating'], true); 