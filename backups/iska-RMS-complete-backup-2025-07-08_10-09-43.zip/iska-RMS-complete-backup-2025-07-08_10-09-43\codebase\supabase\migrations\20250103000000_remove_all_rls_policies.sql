-- Migration: Remove ALL RLS policies and disable RLS on all tables
-- This completely removes all Row Level Security to improve performance

-- Drop ALL RLS policies from all tables
-- Users table
DROP POLICY IF EXISTS "Allow read access for demo" ON users;
DROP POLICY IF EXISTS "Allow update access for demo" ON users;
DROP POLICY IF EXISTS "Allow insert access for demo" ON users;
DROP POLICY IF EXISTS "Allow delete access for demo" ON users;
DROP POLICY IF EXISTS "Users can view their own profile" ON users;
DROP POLICY IF EXISTS "Administrators can view all users" ON users;
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON users;
DROP POLICY IF EXISTS "Enable update for users based on user_id" ON users;
DROP POLICY IF EXISTS "Enable delete for users based on user_id" ON users;

-- Students table
DROP POLICY IF EXISTS "Allow read access for demo" ON students;
DROP POLICY IF EXISTS "Allow update access for demo" ON students;
DROP POLICY IF EXISTS "Allow insert access for demo" ON students;
DROP POLICY IF EXISTS "Allow delete access for demo" ON students;
DROP POLICY IF EXISTS "Students can view their own profile" ON students;
DROP POLICY IF EXISTS "Students can update their own profile" ON students;
DROP POLICY IF EXISTS "Admins can view all students" ON students;
DROP POLICY IF EXISTS "Admins can insert students" ON students;
DROP POLICY IF EXISTS "Admins can update students" ON students;

-- Tourist profiles table
DROP POLICY IF EXISTS "Allow read access for demo" ON tourist_profiles;
DROP POLICY IF EXISTS "Allow update access for demo" ON tourist_profiles;
DROP POLICY IF EXISTS "Allow insert access for demo" ON tourist_profiles;
DROP POLICY IF EXISTS "Allow delete access for demo" ON tourist_profiles;

-- Leads table
DROP POLICY IF EXISTS "Allow read access for demo" ON leads;
DROP POLICY IF EXISTS "Allow update access for demo" ON leads;
DROP POLICY IF EXISTS "Allow insert access for demo" ON leads;
DROP POLICY IF EXISTS "Allow delete access for demo" ON leads;

-- Lead sources table
DROP POLICY IF EXISTS "Allow read access for demo" ON lead_sources;
DROP POLICY IF EXISTS "Allow update access for demo" ON lead_sources;
DROP POLICY IF EXISTS "Allow insert access for demo" ON lead_sources;
DROP POLICY IF EXISTS "Allow delete access for demo" ON lead_sources;

-- Lead follow ups table
DROP POLICY IF EXISTS "Allow read access for demo" ON lead_follow_ups;
DROP POLICY IF EXISTS "Allow update access for demo" ON lead_follow_ups;
DROP POLICY IF EXISTS "Allow insert access for demo" ON lead_follow_ups;
DROP POLICY IF EXISTS "Allow delete access for demo" ON lead_follow_ups;

-- Reservations table
DROP POLICY IF EXISTS "Allow read access for demo" ON reservations;
DROP POLICY IF EXISTS "Allow update access for demo" ON reservations;
DROP POLICY IF EXISTS "Allow insert access for demo" ON reservations;
DROP POLICY IF EXISTS "Allow delete access for demo" ON reservations;

-- Payments table
DROP POLICY IF EXISTS "Allow read access for demo" ON payments;
DROP POLICY IF EXISTS "Allow update access for demo" ON payments;
DROP POLICY IF EXISTS "Allow insert access for demo" ON payments;
DROP POLICY IF EXISTS "Allow delete access for demo" ON payments;

-- Invoices table
DROP POLICY IF EXISTS "Allow read access for demo" ON invoices;
DROP POLICY IF EXISTS "Allow update access for demo" ON invoices;
DROP POLICY IF EXISTS "Allow insert access for demo" ON invoices;
DROP POLICY IF EXISTS "Allow delete access for demo" ON invoices;

-- Studios table
DROP POLICY IF EXISTS "Allow read access for demo" ON studios;
DROP POLICY IF EXISTS "Allow update access for demo" ON studios;
DROP POLICY IF EXISTS "Allow insert access for demo" ON studios;
DROP POLICY IF EXISTS "Allow delete access for demo" ON studios;

-- Durations table
DROP POLICY IF EXISTS "Allow read access for demo" ON durations;
DROP POLICY IF EXISTS "Allow update access for demo" ON durations;
DROP POLICY IF EXISTS "Allow insert access for demo" ON durations;
DROP POLICY IF EXISTS "Allow delete access for demo" ON durations;

-- Room grades table
DROP POLICY IF EXISTS "Allow read access for demo" ON room_grades;
DROP POLICY IF EXISTS "Allow update access for demo" ON room_grades;
DROP POLICY IF EXISTS "Allow insert access for demo" ON room_grades;
DROP POLICY IF EXISTS "Allow delete access for demo" ON room_grades;

-- Pricing matrix table
DROP POLICY IF EXISTS "Allow read access for demo" ON pricing_matrix;
DROP POLICY IF EXISTS "Allow update access for demo" ON pricing_matrix;
DROP POLICY IF EXISTS "Allow insert access for demo" ON pricing_matrix;
DROP POLICY IF EXISTS "Allow delete access for demo" ON pricing_matrix;

-- Installment plans table
DROP POLICY IF EXISTS "Allow read access for demo" ON installment_plans;
DROP POLICY IF EXISTS "Allow update access for demo" ON installment_plans;
DROP POLICY IF EXISTS "Allow insert access for demo" ON installment_plans;
DROP POLICY IF EXISTS "Allow delete access for demo" ON installment_plans;

-- Reservation installments table
DROP POLICY IF EXISTS "Allow read access for demo" ON reservation_installments;
DROP POLICY IF EXISTS "Allow update access for demo" ON reservation_installments;
DROP POLICY IF EXISTS "Allow insert access for demo" ON reservation_installments;
DROP POLICY IF EXISTS "Allow delete access for demo" ON reservation_installments;

-- Cleaning tasks table
DROP POLICY IF EXISTS "Allow read access for demo" ON cleaning_tasks;
DROP POLICY IF EXISTS "Allow update access for demo" ON cleaning_tasks;
DROP POLICY IF EXISTS "Allow insert access for demo" ON cleaning_tasks;
DROP POLICY IF EXISTS "Allow delete access for demo" ON cleaning_tasks;

-- Cleaners table
DROP POLICY IF EXISTS "Allow read access for demo" ON cleaners;
DROP POLICY IF EXISTS "Allow update access for demo" ON cleaners;
DROP POLICY IF EXISTS "Allow insert access for demo" ON cleaners;
DROP POLICY IF EXISTS "Allow delete access for demo" ON cleaners;

-- Maintenance requests table
DROP POLICY IF EXISTS "Allow read access for demo" ON maintenance_requests;
DROP POLICY IF EXISTS "Allow update access for demo" ON maintenance_requests;
DROP POLICY IF EXISTS "Allow insert access for demo" ON maintenance_requests;
DROP POLICY IF EXISTS "Allow delete access for demo" ON maintenance_requests;

-- Maintenance categories table
DROP POLICY IF EXISTS "Allow read access for demo" ON maintenance_categories;
DROP POLICY IF EXISTS "Allow update access for demo" ON maintenance_categories;
DROP POLICY IF EXISTS "Allow insert access for demo" ON maintenance_categories;
DROP POLICY IF EXISTS "Allow delete access for demo" ON maintenance_categories;

-- Notifications table
DROP POLICY IF EXISTS "Allow read access for demo" ON notifications;
DROP POLICY IF EXISTS "Allow update access for demo" ON notifications;
DROP POLICY IF EXISTS "Allow insert access for demo" ON notifications;
DROP POLICY IF EXISTS "Allow delete access for demo" ON notifications;

-- Audit log table
DROP POLICY IF EXISTS "Allow read access for demo" ON audit_log;
DROP POLICY IF EXISTS "Allow update access for demo" ON audit_log;
DROP POLICY IF EXISTS "Allow insert access for demo" ON audit_log;
DROP POLICY IF EXISTS "Allow delete access for demo" ON audit_log;

-- Student documents table
DROP POLICY IF EXISTS "Allow read access for demo" ON student_documents;
DROP POLICY IF EXISTS "Allow update access for demo" ON student_documents;
DROP POLICY IF EXISTS "Allow insert access for demo" ON student_documents;
DROP POLICY IF EXISTS "Allow delete access for demo" ON student_documents;
DROP POLICY IF EXISTS "Students can view their own documents" ON student_documents;
DROP POLICY IF EXISTS "Students can insert their own documents" ON student_documents;
DROP POLICY IF EXISTS "Admins can view all student documents" ON student_documents;
DROP POLICY IF EXISTS "Admins can insert student documents" ON student_documents;

-- Student agreements table
DROP POLICY IF EXISTS "Allow read access for demo" ON student_agreements;
DROP POLICY IF EXISTS "Allow update access for demo" ON student_agreements;
DROP POLICY IF EXISTS "Allow insert access for demo" ON student_agreements;
DROP POLICY IF EXISTS "Allow delete access for demo" ON student_agreements;
DROP POLICY IF EXISTS "Students can view their own agreements" ON student_agreements;
DROP POLICY IF EXISTS "Staff can view all agreements" ON student_agreements;

-- Module styles table
DROP POLICY IF EXISTS "Allow read access for demo" ON module_styles;
DROP POLICY IF EXISTS "Allow update access for demo" ON module_styles;
DROP POLICY IF EXISTS "Allow insert access for demo" ON module_styles;
DROP POLICY IF EXISTS "Allow delete access for demo" ON module_styles;

-- Student option fields table
DROP POLICY IF EXISTS "Allow read access for demo" ON student_option_fields;
DROP POLICY IF EXISTS "Allow update access for demo" ON student_option_fields;
DROP POLICY IF EXISTS "Allow insert access for demo" ON student_option_fields;
DROP POLICY IF EXISTS "Allow delete access for demo" ON student_option_fields;

-- Lead option fields table
DROP POLICY IF EXISTS "Allow read access for demo" ON lead_option_fields;
DROP POLICY IF EXISTS "Allow update access for demo" ON lead_option_fields;
DROP POLICY IF EXISTS "Allow insert access for demo" ON lead_option_fields;
DROP POLICY IF EXISTS "Allow delete access for demo" ON lead_option_fields;

-- System preferences table
DROP POLICY IF EXISTS "Allow read access for demo" ON system_preferences;
DROP POLICY IF EXISTS "Allow update access for demo" ON system_preferences;
DROP POLICY IF EXISTS "Allow insert access for demo" ON system_preferences;
DROP POLICY IF EXISTS "Allow delete access for demo" ON system_preferences;

-- Branding settings table (table may not exist)
-- DROP POLICY IF EXISTS "Allow read access for demo" ON branding_settings;
-- DROP POLICY IF EXISTS "Allow update access for demo" ON branding_settings;
-- DROP POLICY IF EXISTS "Allow insert access for demo" ON branding_settings;
-- DROP POLICY IF EXISTS "Allow delete access for demo" ON branding_settings;

-- Disable RLS on ALL tables
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE students DISABLE ROW LEVEL SECURITY;
ALTER TABLE tourist_profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE leads DISABLE ROW LEVEL SECURITY;
ALTER TABLE lead_sources DISABLE ROW LEVEL SECURITY;
ALTER TABLE lead_follow_ups DISABLE ROW LEVEL SECURITY;
ALTER TABLE reservations DISABLE ROW LEVEL SECURITY;
ALTER TABLE payments DISABLE ROW LEVEL SECURITY;
ALTER TABLE invoices DISABLE ROW LEVEL SECURITY;
ALTER TABLE studios DISABLE ROW LEVEL SECURITY;
ALTER TABLE durations DISABLE ROW LEVEL SECURITY;
ALTER TABLE room_grades DISABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_matrix DISABLE ROW LEVEL SECURITY;
ALTER TABLE installment_plans DISABLE ROW LEVEL SECURITY;
ALTER TABLE reservation_installments DISABLE ROW LEVEL SECURITY;
ALTER TABLE cleaning_tasks DISABLE ROW LEVEL SECURITY;
ALTER TABLE cleaners DISABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log DISABLE ROW LEVEL SECURITY;
ALTER TABLE student_documents DISABLE ROW LEVEL SECURITY;
ALTER TABLE student_agreements DISABLE ROW LEVEL SECURITY;
ALTER TABLE module_styles DISABLE ROW LEVEL SECURITY;
ALTER TABLE student_option_fields DISABLE ROW LEVEL SECURITY;
ALTER TABLE lead_option_fields DISABLE ROW LEVEL SECURITY;
ALTER TABLE system_preferences DISABLE ROW LEVEL SECURITY;
-- ALTER TABLE branding_settings DISABLE ROW LEVEL SECURITY;

-- Grant ALL permissions to authenticated and anonymous users
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;

-- Add comment to document this change
COMMENT ON SCHEMA public IS 'RLS completely disabled for performance. No authentication required for database access.'; 