
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import { 
  Users, 
  Calendar, 
  Sparkles, 
  DollarSign, 
  Database, 
  Settings,
  LogOut,
  GraduationCap,
  UserCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Dashboard = () => {
  const navigate = useNavigate();

  const modules = [
    {
      title: 'Leads',
      description: 'Manage customer leads and prospects',
      icon: Users,
      path: '/leads',
      gradient: 'leads-gradient',
      accessGranted: true
    },
    {
      title: 'OTA Bookings',
      description: 'Handle online travel agency bookings',
      icon: Calendar,
      path: '/ota-bookings',
      gradient: 'reservations-gradient',
      accessGranted: true
    },
    {
      title: 'Cleaning',
      description: 'Schedule and track cleaning tasks',
      icon: Sparkles,
      path: '/cleaning',
      gradient: 'cleaning-gradient',
      accessGranted: true
    },
    {
      title: 'Finance',
      description: 'Manage payments and financial records',
      icon: DollarSign,
      path: '/finance',
      gradient: 'finance-gradient',
      accessGranted: true
    },
    {
      title: 'Data Management',
      description: 'Configure system data and settings',
      icon: Database,
      path: '/data',
      gradient: 'data-gradient',
      accessGranted: true
    },
    {
      title: 'Settings',
      description: 'System preferences and user management',
      icon: Settings,
      path: '/settings',
      gradient: 'settings-gradient',
      accessGranted: true
    },
    {
      title: 'Students',
      description: 'Manage student records and accommodations',
      icon: UserCheck,
      path: '/students',
      gradient: 'students-gradient',
      accessGranted: true
    },
    {
      title: 'Student Portal',
      description: 'Student self-service and management',
      icon: GraduationCap,
      path: '/student-portal',
      gradient: 'student-portal-gradient',
      accessGranted: true
    }
  ];

  const handleLogout = () => {
    // Handle logout logic
    console.log('Logout clicked');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="max-w-[1140px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Property Management System
            </h1>
            <p className="text-xl text-gray-600">
              Welcome back! Choose a module to get started.
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        {/* Module Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modules.map((module) => (
            <ModuleCard
              key={module.path}
              title={module.title}
              description={module.description}
              icon={module.icon}
              onClick={() => navigate(module.path)}
              gradient={module.gradient}
              accessGranted={module.accessGranted}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
