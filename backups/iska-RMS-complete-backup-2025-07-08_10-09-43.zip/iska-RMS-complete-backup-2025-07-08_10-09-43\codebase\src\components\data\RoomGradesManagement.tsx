
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ApiService, RoomGrade } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { 
  Building, 
  Plus, 
  Edit, 
  Trash2, 
  ArrowLeft,
  Loader2
} from 'lucide-react';


const RoomGradesManagement = () => {
  const { toast } = useToast();
  const [roomGrades, setRoomGrades] = useState<RoomGrade[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newGrade, setNewGrade] = useState({ name: '', studio_count: '', weekly_rate: '' });

  useEffect(() => {
    fetchRoomGrades();
  }, []);

  const fetchRoomGrades = async () => {
    try {
      setIsLoading(true);
      const data = await ApiService.getRoomGrades();
      setRoomGrades(data);
    } catch (error) {
      console.error('Error fetching room grades:', error);
      toast({
        title: "Error",
        description: "Failed to fetch room grades. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddGrade = async () => {
    if (newGrade.name && newGrade.studio_count && newGrade.weekly_rate) {
      try {
        const gradeData = {
          name: newGrade.name,
          studio_count: parseInt(newGrade.studio_count),
          weekly_rate: parseFloat(newGrade.weekly_rate),
          is_active: true
        };
        
        await ApiService.createRoomGrade(gradeData);
        await fetchRoomGrades();
        setNewGrade({ name: '', studio_count: '', weekly_rate: '' });
        setIsAddDialogOpen(false);
        toast({
          title: "Success",
          description: "Room grade added successfully.",
        });
      } catch (error) {
        console.error('Error adding room grade:', error);
        toast({
          title: "Error",
          description: "Failed to add room grade. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleDeleteGrade = async (id: string) => {
    try {
      await ApiService.deleteRoomGrade(id);
      await fetchRoomGrades();
      toast({
        title: "Success",
        description: "Room grade deleted successfully.",
      });
    } catch (error) {
      console.error('Error deleting room grade:', error);
      toast({
        title: "Error",
        description: "Failed to delete room grade. Please try again.",
        variant: "destructive",
      });
    }
  };

  const totalStudios = roomGrades.reduce((sum, grade) => sum + (grade.studio_count || 0), 0);

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Room Grades Management</h1>
          <p className="text-muted-foreground">Configure room grades and studio counts</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Room Grade
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Room Grade</DialogTitle>
              <DialogDescription>
                Create a new room grade category
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Grade Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Premium"
                  value={newGrade.name}
                  onChange={(e) => setNewGrade({ ...newGrade, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="studioCount">Studio Count</Label>
                <Input
                  id="studioCount"
                  type="number"
                  placeholder="e.g., 45"
                  value={newGrade.studio_count}
                  onChange={(e) => setNewGrade({ ...newGrade, studio_count: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="weeklyRate">Weekly Rate (£)</Label>
                <Input
                  id="weeklyRate"
                  type="number"
                  step="0.01"
                  placeholder="e.g., 160.00"
                  value={newGrade.weekly_rate}
                  onChange={(e) => setNewGrade({ ...newGrade, weekly_rate: e.target.value })}
                />
              </div>
              <div className="flex space-x-2">
                <Button onClick={handleAddGrade} className="flex-1">Add Grade</Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Room Grades</p>
                <p className="text-2xl font-bold">{roomGrades.length}</p>
              </div>
              <Building className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Studios</p>
                <p className="text-2xl font-bold">{totalStudios}</p>
              </div>
              <Building className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Average per Grade</p>
                <p className="text-2xl font-bold">{roomGrades.length > 0 ? Math.round(totalStudios / roomGrades.length) : 0}</p>
              </div>
              <Building className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Room Grades List */}
      <Card>
        <CardHeader>
          <CardTitle>Room Grades</CardTitle>
          <CardDescription>Manage all room grade categories and studio counts</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
              <p className="mt-2 text-sm text-gray-500">Loading room grades...</p>
            </div>
          ) : (
            <div className="space-y-4">
              {roomGrades.map((grade) => (
                <div key={grade.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <Building className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <h4 className="font-medium">{grade.name}</h4>
                      <p className="text-sm text-muted-foreground">{grade.description}</p>
                    </div>
                    <Badge variant="outline">{grade.studio_count} studios • £{grade.weekly_rate}/week</Badge>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDeleteGrade(grade.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RoomGradesManagement;
