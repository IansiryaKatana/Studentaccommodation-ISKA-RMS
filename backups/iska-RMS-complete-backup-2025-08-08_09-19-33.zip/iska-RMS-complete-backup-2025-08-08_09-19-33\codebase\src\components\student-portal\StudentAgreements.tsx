
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ApiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { FileText, Download, Upload, Eye, CheckCircle, Clock, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface StudentAgreementsProps {
  studentId: string;
}

const StudentAgreements = ({ studentId }: StudentAgreementsProps) => {
  const { toast } = useToast();
  const [agreements, setAgreements] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingDocId, setUploadingDocId] = useState<string | null>(null);

  useEffect(() => {
    fetchAgreements();
  }, [studentId]);

  const fetchAgreements = async () => {
    try {
      setIsLoading(true);
      const data = await ApiService.getStudentAgreements(studentId);
      setAgreements(data);
    } catch (error) {
      console.error('Error fetching agreements:', error);
      toast({
        title: "Error",
        description: "Failed to fetch agreements. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'signed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'signed': return CheckCircle;
      case 'pending': return Clock;
      case 'overdue': return Clock;
      default: return Clock;
    }
  };

  const handleViewDocument = (documentUrl: string, title: string) => {
    // In a real app, this would open the document in a new tab or modal
    toast({
      title: "Opening Document",
      description: `Opening ${title} for viewing`,
    });
    console.log('Opening document:', documentUrl);
  };

  const handleDownloadDocument = (documentUrl: string, title: string) => {
    // In a real app, this would trigger a download
    toast({
      title: "Download Started",
      description: `Downloading ${title}`,
    });
    console.log('Downloading document:', documentUrl);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, agreementId: string) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingDocId(agreementId);
    
    // Simulate upload process
    setTimeout(() => {
      toast({
        title: "Upload Successful",
        description: `Signed document uploaded successfully`,
      });
      setUploadingDocId(null);
      // In a real app, you would update the agreement status here
    }, 2000);
  };

  const handleViewSignedDocument = (signedDocumentUrl: string, title: string) => {
    toast({
      title: "Opening Signed Document",
      description: `Opening signed ${title} for viewing`,
    });
    console.log('Opening signed document:', signedDocumentUrl);
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
        <p className="mt-2 text-sm text-gray-500">Loading agreements...</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Agreements</h1>
        <p className="text-gray-600">View, download, and upload signed copies of your accommodation agreements</p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Documents</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{agreements.length}</div>
            <p className="text-xs text-muted-foreground">Agreements to review</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Signed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {agreements.filter(a => a.status === 'signed').length}
            </div>
            <p className="text-xs text-muted-foreground">Completed agreements</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {agreements.filter(a => a.status === 'pending' || a.status === 'overdue').length}
            </div>
            <p className="text-xs text-muted-foreground">Awaiting signature</p>
          </CardContent>
        </Card>
      </div>

      {/* Agreements List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            All Agreements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {agreements.map((agreement) => {
              const StatusIcon = getStatusIcon(agreement.status);
              return (
                <div key={agreement.id} className="border rounded-lg p-6 hover:bg-gray-50">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <FileText className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{agreement.title}</h3>
                        <p className="text-gray-600 text-sm mb-2">{agreement.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Uploaded: {agreement.uploadedDate}</span>
                          <span>Due: {agreement.dueDate}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(agreement.status)}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {agreement.status}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-3">
                    {/* Document Actions */}
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-medium text-gray-700">Original Document:</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDocument(agreement.documentUrl, agreement.title)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDownloadDocument(agreement.documentUrl, agreement.title)}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>

                    {/* Upload Section */}
                    {agreement.status !== 'signed' && (
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-medium text-gray-700">Upload Signed Copy:</span>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="file"
                            accept=".pdf,.doc,.docx"
                            onChange={(e) => handleFileUpload(e, agreement.id)}
                            className="w-auto"
                            disabled={uploadingDocId === agreement.id}
                          />
                          {uploadingDocId === agreement.id && (
                            <span className="text-sm text-blue-600">Uploading...</span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Signed Document Actions */}
                    {agreement.signedDocumentUrl && (
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-medium text-green-700">Signed Document:</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewSignedDocument(agreement.signedDocumentUrl!, agreement.title)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Signed
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadDocument(agreement.signedDocumentUrl!, agreement.title)}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download Signed
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentAgreements;
