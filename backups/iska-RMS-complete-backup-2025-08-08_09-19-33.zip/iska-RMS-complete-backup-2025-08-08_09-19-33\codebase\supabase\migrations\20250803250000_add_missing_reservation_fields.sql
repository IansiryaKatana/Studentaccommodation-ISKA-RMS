-- Add missing fields to reservations table
ALTER TABLE reservations 
ADD COLUMN IF NOT EXISTS booking_source_id UUID REFERENCES tourist_booking_sources(id),
ADD COLUMN IF NOT EXISTS guest_status_id UUID REFERENCES tourist_guest_statuses(id),
ADD COLUMN IF NOT EXISTS price_per_night DECIMAL(10,2) DEFAULT 0;

-- Add indexes for the new foreign key fields
CREATE INDEX IF NOT EXISTS idx_reservations_booking_source_id ON reservations(booking_source_id);
CREATE INDEX IF NOT EXISTS idx_reservations_guest_status_id ON reservations(guest_status_id);
