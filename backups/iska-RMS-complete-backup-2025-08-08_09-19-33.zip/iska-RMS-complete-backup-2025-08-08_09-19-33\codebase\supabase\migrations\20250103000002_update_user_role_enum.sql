-- Migration to update user_role enum to change 'reservations' to 'ota-bookings'

-- First, update any existing users with 'reservations' role to 'ota-bookings'
UPDATE users 
SET role = 'ota-bookings'::user_role 
WHERE role = 'reservations'::user_role;

-- Note: PostgreSQL doesn't allow direct enum value changes, so we need to:
-- 1. Create a new enum type
-- 2. Update the column to use the new type
-- 3. Drop the old enum type

-- Create new enum type
CREATE TYPE user_role_new AS ENUM ('administrator', 'salesperson', 'ota-bookings', 'cleaner', 'accountant', 'student');

-- Update the column to use the new enum type
ALTER TABLE users 
ALTER COLUMN role TYPE user_role_new 
USING role::text::user_role_new;

-- Drop the old enum type
DROP TYPE user_role;

-- Rename the new enum type to the original name
ALTER TYPE user_role_new RENAME TO user_role;
