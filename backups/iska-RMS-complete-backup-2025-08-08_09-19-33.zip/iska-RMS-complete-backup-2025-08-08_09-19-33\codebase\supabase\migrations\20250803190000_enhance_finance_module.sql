-- =====================================================
-- ENHANCE FINANCE MODULE FOR TOURIST & STUDENT RESERVATIONS
-- =====================================================

-- Add new fields to existing tables
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS price_per_night DECIMAL(10,2);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS booking_source_id UUID REFERENCES tourist_booking_sources(id);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS guest_status_id UUID REFERENCES tourist_guest_statuses(id);

-- Add Xero integration fields to invoices
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS xero_invoice_id VARCHAR(255);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS xero_exported_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS xero_export_status VARCHAR(50) DEFAULT 'pending';

-- Add Xero integration fields to payments
ALTER TABLE payments ADD COLUMN IF NOT EXISTS xero_payment_id VARCHAR(255);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS xero_exported_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS xero_export_status VARCHAR(50) DEFAULT 'pending';

-- Add late fee configuration to installment plans
ALTER TABLE installment_plans ADD COLUMN IF NOT EXISTS late_fee_enabled BOOLEAN DEFAULT false;
ALTER TABLE installment_plans ADD COLUMN IF NOT EXISTS late_fee_days INTEGER DEFAULT 7;

-- Create refunds table
CREATE TABLE IF NOT EXISTS refunds (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_id UUID REFERENCES reservations(id) ON DELETE CASCADE,
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    refund_type VARCHAR(50) NOT NULL DEFAULT 'full', -- 'full', 'partial', 'deposit_only'
    processed_at TIMESTAMP WITH TIME ZONE,
    xero_refund_id VARCHAR(255),
    xero_exported_at TIMESTAMP WITH TIME ZONE,
    xero_export_status VARCHAR(50) DEFAULT 'pending',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create refund reasons lookup table
CREATE TABLE IF NOT EXISTS refund_reasons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default refund reasons
INSERT INTO refund_reasons (name, description) VALUES
    ('Guest Cancellation', 'Guest cancelled the reservation'),
    ('Property Issue', 'Property was not available or had issues'),
    ('Booking Error', 'Error in the booking process'),
    ('Guest No-Show', 'Guest did not arrive'),
    ('Early Checkout', 'Guest checked out early'),
    ('Service Issue', 'Service quality issues'),
    ('Other', 'Other reasons');

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_refunds_reservation_id ON refunds(reservation_id);
CREATE INDEX IF NOT EXISTS idx_refunds_invoice_id ON refunds(invoice_id);
CREATE INDEX IF NOT EXISTS idx_refunds_created_at ON refunds(created_at);
CREATE INDEX IF NOT EXISTS idx_invoices_xero_export_status ON invoices(xero_export_status);
CREATE INDEX IF NOT EXISTS idx_payments_xero_export_status ON payments(xero_export_status);

-- Add updated_at trigger for refunds
CREATE TRIGGER update_refunds_updated_at BEFORE UPDATE ON refunds FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Disable RLS for new tables (for now)
ALTER TABLE refunds DISABLE ROW LEVEL SECURITY;
ALTER TABLE refund_reasons DISABLE ROW LEVEL SECURITY; 