-- Migration to update reservations module name to ota-bookings
-- This ensures consistency with the new module naming

-- Update the module_styles table to change 'reservations' to 'ota-bookings'
UPDATE module_styles 
SET module_name = 'ota-bookings' 
WHERE module_name = 'reservations';

-- If no rows were updated (meaning 'reservations' didn't exist), insert the new record
INSERT INTO module_styles (module_name, gradient_start, gradient_end, is_active, created_at)
SELECT 'ota-bookings', '#f093fb', '#f5576c', true, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM module_styles WHERE module_name = 'ota-bookings'
);
