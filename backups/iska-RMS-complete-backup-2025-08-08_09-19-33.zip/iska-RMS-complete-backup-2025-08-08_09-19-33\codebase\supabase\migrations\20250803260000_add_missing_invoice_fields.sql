-- Add missing fields to invoices table
ALTER TABLE invoices 
ADD COLUMN IF NOT EXISTS xero_invoice_id VARCHAR(255),
ADD COLUMN IF NOT EXISTS xero_exported_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS xero_export_status VARCHAR(20) DEFAULT 'pending' CHECK (xero_export_status IN ('pending', 'exported', 'failed'));

-- Add missing fields to payments table
ALTER TABLE payments 
ADD COLUMN IF NOT EXISTS xero_payment_id VARCHAR(255),
ADD COLUMN IF NOT EXISTS xero_exported_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS xero_export_status VARCHAR(20) DEFAULT 'pending' CHECK (xero_export_status IN ('pending', 'exported', 'failed'));

-- Add missing fields to refunds table (if it doesn't exist, create it)
CREATE TABLE IF NOT EXISTS refunds (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_id UUID REFERENCES reservations(id),
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    reason TEXT NOT NULL,
    refund_type VARCHAR(20) NOT NULL CHECK (refund_type IN ('full', 'partial', 'deposit_only')),
    processed_at TIMESTAMP WITH TIME ZONE,
    xero_refund_id VARCHAR(255),
    xero_exported_at TIMESTAMP WITH TIME ZONE,
    xero_export_status VARCHAR(20) DEFAULT 'pending' CHECK (xero_export_status IN ('pending', 'exported', 'failed')),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes for refunds
CREATE INDEX IF NOT EXISTS idx_refunds_reservation_id ON refunds(reservation_id);
CREATE INDEX IF NOT EXISTS idx_refunds_invoice_id ON refunds(invoice_id);
CREATE INDEX IF NOT EXISTS idx_refunds_created_by ON refunds(created_by);

-- Add trigger for refunds updated_at
CREATE TRIGGER update_refunds_updated_at BEFORE UPDATE ON refunds FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
