-- Create refund_reasons table
CREATE TABLE IF NOT EXISTS refund_reasons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert some default refund reasons
INSERT INTO refund_reasons (name, description) VALUES
    ('Cancellation', 'Reservation was cancelled by guest'),
    ('Early departure', 'Guest left before scheduled check-out date'),
    ('Service issue', 'Problem with accommodation or service'),
    ('Double booking', 'Accommodation was double-booked'),
    ('Maintenance', 'Maintenance work required during stay'),
    ('Other', 'Other reason for refund')
ON CONFLICT (id) DO NOTHING;
