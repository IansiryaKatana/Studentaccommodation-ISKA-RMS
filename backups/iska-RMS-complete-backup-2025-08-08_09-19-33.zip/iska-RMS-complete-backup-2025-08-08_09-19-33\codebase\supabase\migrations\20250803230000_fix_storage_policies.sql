-- Fix storage policies to allow service role access for file uploads
-- Drop existing policies
DROP POLICY IF EXISTS "Students can view their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can upload their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can update their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can delete their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Administrators can manage all student documents" ON storage.objects;

-- Create more permissive policies for service role access
CREATE POLICY "Allow service role access to student documents" ON storage.objects
  FOR ALL USING (
    bucket_id = 'student-documents' AND 
    (auth.role() = 'service_role' OR 
     auth.uid()::text = (storage.foldername(name))[1] OR 
     EXISTS (
       SELECT 1 FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE u.id = auth.uid() AND s.id::text = (storage.foldername(name))[1]
     ) OR
     EXISTS (
       SELECT 1 FROM users 
       WHERE id = auth.uid() AND role = 'administrator'
     ))
  );

-- Create a specific policy for file uploads during student creation
CREATE POLICY "Allow file uploads during student creation" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'student-documents' AND 
    (auth.role() = 'service_role' OR 
     EXISTS (
       SELECT 1 FROM users 
       WHERE id = auth.uid() AND role = 'administrator'
     ))
  );
