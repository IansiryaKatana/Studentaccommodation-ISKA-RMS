-- Add dashboard branding fields to branding table
ALTER TABLE branding 
ADD COLUMN IF NOT EXISTS dashboard_title VARCHAR(255) DEFAULT 'ISKA - RMS',
ADD COLUMN IF NOT EXISTS dashboard_subtitle VARCHAR(500) DEFAULT 'Worldclass Student accommodation CRM';

-- Update existing branding record with default dashboard values
UPDATE branding 
SET 
  dashboard_title = 'ISKA - RMS',
  dashboard_subtitle = 'Worldclass Student accommodation CRM'
WHERE dashboard_title IS NULL OR dashboard_subtitle IS NULL;
