
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import './Dashboard.css';
import { useBranding } from '@/contexts/BrandingContext';
import { 
  Users, 
  Calendar, 
  Sparkles, 
  DollarSign, 
  Database, 
  Settings,
  GraduationCap
} from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const { branding, isLoading } = useBranding();

  const modules = [
    // Row 1: Leads, Students, OTA Bookings, Cleaning
    {
      title: 'Leads',
      description: 'Manage customer leads and prospects',
      icon: Users,
      path: '/leads',
      moduleName: 'leads',
      accessGranted: true
    },
    {
      title: 'Students',
      description: 'Manage student records and accommodations',
      icon: Users,
      path: '/students',
      moduleName: 'students',
      accessGranted: true
    },
    {
      title: 'OTA Bookings',
      description: 'Handle online travel agency bookings',
      icon: Calendar,
      path: '/ota-bookings',
      moduleName: 'ota-bookings',
      accessGranted: true
    },
    {
      title: 'Cleaning',
      description: 'Schedule and track cleaning tasks',
      icon: Sparkles,
      path: '/cleaning',
      moduleName: 'cleaning',
      accessGranted: true
    },
    // Row 2: Data Management, Finance, Settings, Student Portal
    {
      title: 'Data Management',
      description: 'Configure system data and settings',
      icon: Database,
      path: '/data',
      moduleName: 'data',
      accessGranted: true
    },
    {
      title: 'Finance',
      description: 'Manage payments and financial records',
      icon: DollarSign,
      path: '/finance',
      moduleName: 'finance',
      accessGranted: true
    },
    {
      title: 'Settings',
      description: 'System preferences and user management',
      icon: Settings,
      path: '/settings',
      moduleName: 'settings',
      accessGranted: true
    },
    {
      title: 'Student Portal',
      description: 'Student self-service and management',
      icon: GraduationCap,
      path: '/student-portal',
      moduleName: 'student-portal',
      accessGranted: true
    }
  ];

  return (
    <div className="h-screen dashboard-radial-bg flex flex-col justify-center items-center overflow-hidden">
      <div className="w-full max-w-7xl px-6 py-8">
        {/* Title Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            {isLoading ? 'Loading...' : branding?.dashboard_title || 'ISKA - RMS'}
          </h1>
          <p className="text-xl text-gray-600">
            {isLoading ? 'Loading...' : branding?.dashboard_subtitle || 'Worldclass Student accommodation CRM'}
          </p>
        </div>

        {/* Module Grid - 2 rows, 4 columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((module) => (
            <ModuleCard
              key={module.path}
              title={module.title}
              description={module.description}
              icon={module.icon}
              onClick={() => navigate(module.path)}
              moduleName={module.moduleName}
              accessGranted={module.accessGranted}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
