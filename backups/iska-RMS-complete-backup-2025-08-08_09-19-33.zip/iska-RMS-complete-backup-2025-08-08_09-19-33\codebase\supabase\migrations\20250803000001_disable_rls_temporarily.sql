-- Temporarily disable RLS to add data
ALTER TABLE student_agreements DISABLE ROW LEVEL SECURITY;

-- Insert dummy data for existing students
INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'Accommodation Agreement',
  'Standard accommodation agreement for the academic year',
  'https://example.com/agreements/accommodation.pdf',
  'signed',
  NOW() + INTERVAL '30 days'
FROM students s;

INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'House Rules Agreement',
  'Rules and regulations for living in the accommodation',
  'https://example.com/agreements/house-rules.pdf',
  'pending',
  NOW() + INTERVAL '7 days'
FROM students s;

INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'Payment Plan Agreement',
  'Agreement for installment payment plan',
  'https://example.com/agreements/payment-plan.pdf',
  'signed',
  NOW() + INTERVAL '14 days'
FROM students s;

-- Re-enable RLS
ALTER TABLE student_agreements ENABLE ROW LEVEL SECURITY; 