
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Users, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  GraduationCap,
  CreditCard,
  Building,
  Loader2,
  UserPlus,
  Key,
  User
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ApiService, StudentWithUser } from '@/services/api';

interface StudentWithDetails extends StudentWithUser {
  reservation?: {
    studio?: {
      studio_number: string;
      room_grade?: {
        name: string;
        weekly_rate: number;
      };
    };
    total_amount: number;
  };
  studio?: {
    studio_number: string;
    room_grade?: {
      name: string;
      weekly_rate: number;
    };
  };
  invoices?: Array<{
    amount: number;
    status: string;
  }>;
}

const StudentsList = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [students, setStudents] = useState<StudentWithDetails[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      setIsLoading(true);
      const data = await ApiService.getStudents();
      
      // Fetch additional details for each student
      const studentsWithDetails = await Promise.all(
        data.map(async (student) => {
          try {
            // For student bookings, we don't have reservations, so we'll get invoices directly
            const invoices = await ApiService.getInvoicesByStudentId(student.id);
            
            // Get studio details if student has a studio assigned
            let studio = undefined;
            if (student.studio_id) {
              try {
                const studioData = await ApiService.getStudioById(student.studio_id);
                if (studioData) {
                  const roomGrade = await ApiService.getRoomGradeById(studioData.room_grade_id);
                  studio = {
                    ...studioData,
                    room_grade: roomGrade
                  };
                }
              } catch (error) {
                console.error(`Error fetching studio for student ${student.id}:`, error);
              }
            }
            
            return {
              ...student,
              reservation: undefined, // Student bookings don't use reservations
              studio: studio,
              invoices: invoices || []
            };
          } catch (error) {
            console.error(`Error fetching details for student ${student.id}:`, error);
            return {
              ...student,
              reservation: undefined,
              studio: undefined,
              invoices: []
            };
          }
        })
      );
      
      setStudents(studentsWithDetails);
    } catch (error) {
      console.error('Error fetching students:', error);
      toast({
        title: "Error",
        description: "Failed to fetch students. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredStudents = students.filter(student =>
    `${student.user.first_name} ${student.user.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.university?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.reservation?.studio?.studio_number?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteStudent = async (studentId: string) => {
    try {
      await ApiService.deleteStudent(studentId);
      setStudents(students.filter(s => s.id !== studentId));
      toast({
        title: "Student Deleted",
        description: "Student record has been successfully deleted.",
      });
    } catch (error) {
      console.error('Error deleting student:', error);
      toast({
        title: "Error",
        description: "Failed to delete student. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCreateUserAccount = async (student: StudentWithDetails) => {
    try {
      // Check if student already has a user account
      if (student.user) {
        toast({
          title: "User Account Exists",
          description: "This student already has a user account.",
          variant: "destructive",
        });
        return;
      }

      // Create user account with default password
      const userData = {
        email: student.user?.email || `${student.student_id?.toLowerCase()}@student.ac.uk`,
        first_name: student.user?.first_name || 'Student',
        last_name: student.user?.last_name || student.student_id || 'Unknown',
        role: 'student' as const,
        phone: student.user?.phone || '',
        is_active: true
      };

      const newUser = await ApiService.createUser(userData);
      
      // Update student record with user_id
      await ApiService.updateStudent(student.id, { user_id: newUser.id });
      
      // Refresh the students list
      await fetchStudents();
      
      toast({
        title: "User Account Created",
        description: `User account created for ${student.student_id} with default password: urbanportal123`,
      });
    } catch (error) {
      console.error('Error creating user account:', error);
      toast({
        title: "Error",
        description: "Failed to create user account. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default">Active</Badge>;
      case 'inactive':
        return <Badge variant="secondary">Inactive</Badge>;
      case 'graduated':
        return <Badge variant="outline">Graduated</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getDepositBadge = (depositPaid: boolean) => {
    return depositPaid ? 
      <Badge className="bg-green-100 text-green-800">Paid</Badge> : 
      <Badge className="bg-red-100 text-red-800">Unpaid</Badge>;
  };

  const calculateRevenue = (student: StudentWithDetails) => {
    if (!student.invoices) return 0;
    return student.invoices
      .filter(invoice => invoice.status === 'completed')
      .reduce((sum, invoice) => sum + invoice.amount, 0);
  };

  const calculateProgress = (student: StudentWithDetails) => {
    // Calculate progress based on completed fields
    const fields = [
      student.user.first_name,
      student.user.last_name,
      student.user.email,
      student.university,
      student.course,
      student.studio?.studio_number || student.reservation?.studio?.studio_number,
      student.deposit_paid !== undefined,
      student.guarantor_name,
      student.guarantor_email,
      student.guarantor_phone
    ];
    
    const completedFields = fields.filter(field => field && field !== '').length;
    return Math.round((completedFields / fields.length) * 100);
  };

  const stats = [
    {
      title: 'Total Students',
      value: students.length.toString(),
      icon: Users,
      description: 'Currently enrolled'
    },
    {
      title: 'Active Students',
      value: students.filter(s => s.user.is_active).length.toString(),
      icon: GraduationCap,
      description: 'In residence'
    },
    {
      title: 'Assigned Studios',
      value: students.filter(s => s.studio || s.reservation?.studio).length.toString(),
      icon: Building,
      description: 'With accommodation'
    },
    {
      title: 'Total Revenue',
      value: `£${students.reduce((sum, s) => sum + calculateRevenue(s), 0).toLocaleString()}`,
      icon: CreditCard,
      description: 'From all students'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Students</h1>
          <p className="text-gray-600 mt-1">Manage student records and accommodations</p>
        </div>
        <Link to="/students/add-booking">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Student Booking
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{stat.description}</p>
                </div>
                <stat.icon className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle>Student Records</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search students by name, email, university, or studio..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Students Table */}
          <div className="border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Assigned Studio</TableHead>
                  <TableHead>Room Grade</TableHead>
                  <TableHead>Deposit Paid</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading students...</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStudents.map((student) => {
                    const progress = calculateProgress(student);
                    const revenue = calculateRevenue(student);
                    
                    return (
                      <TableRow 
                        key={student.id} 
                        className="cursor-pointer hover:bg-gray-50"
                        onClick={() => navigate(`/student-portal/${student.id}`)}
                      >
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="flex-shrink-0">
                              <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                <User className="h-5 w-5 text-gray-600" />
                              </div>
                            </div>
                            <div>
                              <div className="font-medium">{`${student.user.first_name} ${student.user.last_name}`}</div>
                              <div className="text-sm text-gray-500">{student.user.email}</div>
                              <div className="text-sm text-gray-500">{student.university || 'No university'}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{student.studio?.studio_number || student.reservation?.studio?.studio_number || 'Not assigned'}</div>
                            <div className="text-sm text-gray-500">
                              {student.studio?.room_grade?.weekly_rate || student.reservation?.studio?.room_grade?.weekly_rate ? 
                                `£${(student.studio?.room_grade?.weekly_rate || student.reservation?.studio?.room_grade?.weekly_rate)}/week` : 
                                'No rate set'
                              }
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {student.studio?.room_grade?.name || student.reservation?.studio?.room_grade?.name || 'N/A'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {getDepositBadge(student.deposit_paid || false)}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">£{revenue.toLocaleString()}</div>
                            <div className="text-sm text-gray-500">
                              {student.invoices?.length || 0} invoices
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="w-full">
                            <div className="flex items-center space-x-2">
                              <Progress value={progress} className="flex-1" />
                              <span className="text-sm font-medium w-12">{progress}%</span>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {progress === 100 ? 'Complete' : 'Incomplete'}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => navigate(`/students/${student.id}`)}>
                                <Eye className="mr-2 h-4 w-4" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => navigate(`/students/${student.id}`)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit Student
                              </DropdownMenuItem>
                              {!student.user && (
                                <DropdownMenuItem onClick={() => handleCreateUserAccount(student)}>
                                  <UserPlus className="mr-2 h-4 w-4" />
                                  Create User Account
                                </DropdownMenuItem>
                              )}
                              {student.user && (
                                <DropdownMenuItem onClick={() => navigate(`/student-portal/${student.id}`)}>
                                  <Key className="mr-2 h-4 w-4" />
                                  Access Portal
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleDeleteStudent(student.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>

          {filteredStudents.length === 0 && (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No students found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchTerm ? 'Try adjusting your search criteria.' : 'Get started by adding a new student.'}
              </p>
              <div className="mt-6">
                <Link to="/students/add-booking">
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Student Booking
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentsList;
