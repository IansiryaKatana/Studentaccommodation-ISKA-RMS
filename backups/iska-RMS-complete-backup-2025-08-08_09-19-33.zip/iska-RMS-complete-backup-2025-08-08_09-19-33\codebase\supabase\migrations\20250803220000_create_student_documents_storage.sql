-- Create storage bucket for student documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'student-documents',
  'student-documents',
  true,
  52428800, -- 50MB limit
  ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
) ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Students can view their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can upload their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can update their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Students can delete their own documents" ON storage.objects;
DROP POLICY IF EXISTS "Administrators can manage all student documents" ON storage.objects;

-- Create RLS policies for student documents bucket
CREATE POLICY "Students can view their own documents" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'student-documents' AND 
    (auth.uid()::text = (storage.foldername(name))[1] OR 
     EXISTS (
       SELECT 1 FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE u.id = auth.uid() AND s.id::text = (storage.foldername(name))[1]
     ))
  );

CREATE POLICY "Students can upload their own documents" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'student-documents' AND 
    (auth.uid()::text = (storage.foldername(name))[1] OR 
     EXISTS (
       SELECT 1 FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE u.id = auth.uid() AND s.id::text = (storage.foldername(name))[1]
     ))
  );

CREATE POLICY "Students can update their own documents" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'student-documents' AND 
    (auth.uid()::text = (storage.foldername(name))[1] OR 
     EXISTS (
       SELECT 1 FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE u.id = auth.uid() AND s.id::text = (storage.foldername(name))[1]
     ))
  );

CREATE POLICY "Students can delete their own documents" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'student-documents' AND 
    (auth.uid()::text = (storage.foldername(name))[1] OR 
     EXISTS (
       SELECT 1 FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE u.id = auth.uid() AND s.id::text = (storage.foldername(name))[1]
     ))
  );

-- Allow administrators to manage all student documents
CREATE POLICY "Administrators can manage all student documents" ON storage.objects
  FOR ALL USING (
    bucket_id = 'student-documents' AND 
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'administrator'
    )
  );
