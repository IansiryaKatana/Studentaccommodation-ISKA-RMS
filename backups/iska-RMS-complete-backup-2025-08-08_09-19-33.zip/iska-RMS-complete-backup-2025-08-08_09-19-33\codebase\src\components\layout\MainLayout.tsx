
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import {
  Users,
  Calendar,
  UserCheck,
  Sparkles,
  DollarSign,
  Database,
  Settings,
  Home,
  Plus,
  Search,
  FileText,
  CreditCard,
  Building,
  User,
  Shield,
  Bell,
  Zap,
  BarChart,
  Download,
  HardDrive,
  UserPlus,
  MapPin,
  Clock,
  Palette,
  Wrench,
  ChevronDown,
  ChevronRight,
  Upload
} from 'lucide-react';
import { useModuleStyles } from '@/contexts/ModuleStylesContext';

// Define TypeScript interfaces
interface PageItem {
  title: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  hasSubmenu?: boolean;
  submenu?: SubmenuItem[];
}

interface SubmenuItem {
  title: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface ModuleRoute {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  basePath: string;
  gradient: string;
  pages: PageItem[];
}

interface MainLayoutProps {
  children: React.ReactNode;
  userRole?: string;
  userName?: string;
  onLogout?: () => void;
}

interface SubmenuItemProps {
  page: PageItem;
  module: ModuleRoute;
  isActive: (path: string) => boolean;
  navigate: (path: string) => void;
  fullPath: string;
}

interface AppSidebarProps {
  userRole?: string;
  userName?: string;
  onLogout?: () => void;
}

const moduleRoutes: Record<string, ModuleRoute> = {
  leads: {
    icon: Users,
    title: 'Leads',
    basePath: '/leads',
    gradient: 'leads',
    pages: [
      { title: 'All Leads', path: '/leads', icon: Users },
      { title: 'Add Lead', path: '/leads/new', icon: Plus },
      { title: 'Lead Sources', path: '/leads/sources', icon: Search },
      { title: 'Lead Statuses', path: '/leads/statuses', icon: BarChart },
      { title: 'Follow-ups', path: '/leads/follow-ups', icon: FileText }
    ]
  },
  'ota-bookings': {
    icon: Calendar,
    title: 'OTA Bookings',
    basePath: '/ota-bookings',
    gradient: 'ota-bookings',
    pages: [
      { title: 'Overview', path: '/ota-bookings', icon: Calendar },
      { 
        title: 'Studios', 
        path: '/ota-bookings/studios', 
        icon: Building,
        hasSubmenu: true,
        submenu: [
          { title: 'All Studios', path: '/ota-bookings/studios', icon: Building },
          { title: 'Add Studio', path: '/ota-bookings/studios/add', icon: Plus }
        ]
      },
      { title: 'Tourists', path: '/ota-bookings/tourists', icon: MapPin },
      { title: 'Add Tourist Booking', path: '/ota-bookings/tourists/new', icon: Plus },
      { title: 'Calendar View', path: '/ota-bookings/calendar', icon: Calendar },
      { title: 'Check-in/out', path: '/ota-bookings/checkin', icon: UserCheck }
    ]
  },
  students: {
    icon: Users,
    title: 'Students',
    basePath: '/students',
    gradient: 'students',
    pages: [
      { title: 'Overview', path: '/students', icon: Users },
      { title: 'Students List', path: '/students/list', icon: Users },
      { title: 'Add Student Booking', path: '/students/add-booking', icon: Plus },
      { 
        title: 'Studios', 
        path: '/students/studios', 
        icon: Building,
        hasSubmenu: true,
        submenu: [
          { title: 'All Studios', path: '/students/studios', icon: Building },
          { title: 'Add Studio', path: '/students/studios/add', icon: Plus }
        ]
      },
      { title: 'Calendar View', path: '/students/calendar', icon: Calendar },
      { title: 'Check-in/Check-out', path: '/students/checkin-checkout', icon: UserCheck }
    ]
  },
  cleaning: {
    icon: Sparkles,
    title: 'Cleaning',
    basePath: '/cleaning',
    gradient: 'cleaning',
    pages: [
      { title: 'Overview', path: '/cleaning', icon: Sparkles },
      { title: 'Daily Schedule', path: '/cleaning/daily-schedule', icon: Calendar },
      { title: 'Cleaner Management', path: '/cleaning/cleaners', icon: Users },
      { title: 'Calendar View', path: '/cleaning/calendar-view', icon: Calendar }
    ]
  },
  finance: {
    icon: DollarSign,
    title: 'Finance',
    basePath: '/finance',
    gradient: 'finance',
    pages: [
      { title: 'Overview', path: '/finance', icon: DollarSign },
      { title: 'Invoices', path: '/finance/invoices', icon: FileText },
      { title: 'Payments', path: '/finance/payments', icon: CreditCard },
      { title: 'Payment Plans', path: '/finance/payment-plans', icon: Calendar },
      { title: 'Create Invoice', path: '/finance/create-invoice', icon: Plus }
    ]
  },
  data: {
    icon: Database,
    title: 'Data',
    basePath: '/data',
    gradient: 'data',
    pages: [
      { title: 'Overview', path: '/data', icon: Database },
      { title: 'Room Grades', path: '/data/room-grades', icon: Building },
      { title: 'Pricing Matrix', path: '/data/pricing-matrix', icon: DollarSign },
      { title: 'Durations', path: '/data/durations', icon: Clock },
      { title: 'Installment Plans', path: '/data/installment-plans', icon: Calendar },
      { title: 'Maintenance Categories', path: '/data/maintenance-categories', icon: Wrench },
      { title: 'Lead Fields', path: '/data/lead-fields', icon: Search },
      { title: 'Student Fields', path: '/data/student-fields', icon: User },
      { title: 'Module Styles', path: '/data/module-styles', icon: Palette },
      { title: 'Bulk Import Studios', path: '/data/bulk-import-studios', icon: Upload },
      { title: 'Bulk Import Leads', path: '/data/bulk-import-leads', icon: Upload },
      { title: 'Bulk Import Students', path: '/data/bulk-import-students', icon: Upload }
    ]
  },
  settings: {
    icon: Settings,
    title: 'Settings',
    basePath: '/settings',
    gradient: 'settings',
    pages: [
      { title: 'Overview', path: '/settings', icon: Settings },
      { title: 'Users', path: '/settings/users', icon: Users },
      { title: 'System Preferences', path: '/settings/system', icon: Wrench },
      { title: 'Security', path: '/settings/security', icon: Shield },
      { title: 'Integrations', path: '/settings/integrations', icon: Zap },
      { title: 'Notifications', path: '/settings/notifications', icon: Bell },
      { title: 'Configuration', path: '/settings/config', icon: Database },
      { title: 'Branding', path: '/settings/branding', icon: Palette }
    ]
  },
  'student-portal': {
    icon: User,
    title: 'Student Portal',
    basePath: '/student-portal',
    gradient: 'student-portal',
    pages: [
      { title: 'Dashboard', path: '/student-portal', icon: Home },
      { title: 'My Bookings', path: '/student-portal/bookings', icon: Calendar },
      { title: 'My Payments', path: '/student-portal/payments', icon: CreditCard },
      { title: 'My Profile', path: '/student-portal/profile', icon: User },
      { title: 'Support', path: '/student-portal/support', icon: Bell }
    ]
  }
};

function SubmenuItem({ 
  page, 
  module, 
  isActive, 
  navigate, 
  fullPath 
}: SubmenuItemProps) {
  const [isExpanded, setIsExpanded] = React.useState(false);
  const { state } = useSidebar();
  
  const isAnySubmenuActive = page.submenu?.some((subItem) => isActive(subItem.path)) ?? false;
  
  // Auto-expand if any submenu item is active
  React.useEffect(() => {
    if (isAnySubmenuActive) {
      setIsExpanded(true);
    }
  }, [isAnySubmenuActive]);

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        onClick={() => setIsExpanded(!isExpanded)}
        isActive={isAnySubmenuActive}
        className={isAnySubmenuActive 
          ? `${module.gradient} text-white font-semibold !text-white data-[active=true]:!text-white` 
          : 'hover:bg-accent hover:text-accent-foreground'
        }
      >
        <page.icon className="size-4" />
        <span>{page.title}</span>
        {state === "expanded" && (
          <div className="ml-auto">
            {isExpanded ? (
              <ChevronDown className="size-4" />
            ) : (
              <ChevronRight className="size-4" />
            )}
          </div>
        )}
      </SidebarMenuButton>
      
      {isExpanded && state === "expanded" && page.submenu && (
        <div className="ml-4 mt-1 space-y-1">
          {page.submenu.map((subItem) => (
            <SidebarMenuButton
              key={subItem.path}
              onClick={() => navigate(subItem.path)}
              isActive={isActive(subItem.path)}
              className={`pl-8 ${isActive(subItem.path) 
                ? `${module.gradient} text-white font-semibold !text-white data-[active=true]:!text-white` 
                : 'hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              <subItem.icon className="size-4" />
              <span>{subItem.title}</span>
            </SidebarMenuButton>
          ))}
        </div>
      )}
    </SidebarMenuItem>
  );
}

function AppSidebar({ userRole, userName, onLogout }: AppSidebarProps) {
  const { state } = useSidebar();
  const navigate = useNavigate();
  const location = useLocation();
  const { getModuleGradient } = useModuleStyles();

  const isActive = (path: string) => {
    if (currentModule?.key === 'student-portal') {
      // For student portal, check relative paths
      const currentPath = location.pathname.replace(/^\/student-portal\/[^/]+/, '');
      return currentPath === path;
    }
    return location.pathname === path;
  };

  const getCurrentModule = () => {
    const path = location.pathname;
    
    for (const [key, module] of Object.entries(moduleRoutes)) {
      if (path.startsWith(module.basePath)) {
        return { key, module };
      }
    }
    return null;
  };

  const currentModule = getCurrentModule();

  // If we're not in a module, don't show the sidebar
  if (!currentModule) return null;

  const module = currentModule.module;
  const moduleGradient = getModuleGradient(module.gradient);

  return (
    <Sidebar collapsible="icon" className="border-r">
      <SidebarHeader className="border-b">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div 
              className="flex aspect-square size-8 items-center justify-center rounded-lg"
              style={{ background: moduleGradient }}
            >
              <module.icon className="size-4 text-white" />
            </div>
            {state === "expanded" && (
              <div className="flex flex-col gap-0.5 leading-none">
                <span className="font-semibold text-foreground">{module.title}</span>
                <span className="text-xs text-muted-foreground">Management</span>
              </div>
            )}
          </div>
          {state === "expanded" && (
            <SidebarMenuButton 
              onClick={() => navigate('/')}
              className="hover:bg-accent hover:text-accent-foreground h-8 w-8 p-0"
            >
              <Home className="size-4" />
            </SidebarMenuButton>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent style={{ background: `linear-gradient(180deg, ${moduleGradient.replace('linear-gradient(135deg, ', '').replace(')', '')}10 0%, transparent 100%)` }}>
        {state === "collapsed" && (
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton 
                    onClick={() => navigate('/')}
                    className="hover:bg-accent hover:text-accent-foreground"
                  >
                    <Home className="size-4" />
                    <span>Dashboard</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        <SidebarGroup>
          <SidebarGroupLabel className="text-muted-foreground">{module.title} Pages</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {module.pages.map((page) => {
                const fullPath = currentModule?.key === 'student-portal' 
                  ? `${module.basePath}/${location.pathname.split('/')[2]}${page.path}`
                  : page.path;
                
                // Check if this page has a submenu
                if (page.hasSubmenu && page.submenu) {
                  return (
                    <SubmenuItem 
                      key={page.path}
                      page={page}
                      module={module}
                      isActive={isActive}
                      navigate={navigate}
                      fullPath={fullPath}
                    />
                  );
                }
                
                return (
                  <SidebarMenuItem key={page.path}>
                    <SidebarMenuButton
                      onClick={() => navigate(fullPath)}
                      isActive={isActive(page.path)}
                      className={isActive(page.path) 
                        ? 'text-white font-semibold !text-white data-[active=true]:!text-white' 
                        : 'hover:bg-accent hover:text-accent-foreground'
                      }
                      style={isActive(page.path) ? { background: moduleGradient } : {}}
                    >
                      <page.icon className="size-4" />
                      <span>{page.title}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t">
        {state === "expanded" && userName && (
          <div className="px-2 py-2">
            <div className="text-xs text-muted-foreground">Welcome</div>
            <div className="text-sm font-medium text-foreground">{userName}</div>
            {userRole && (
              <div 
                className="text-xs text-white px-1 py-0.5 rounded mt-1 inline-block"
                style={{ background: moduleGradient }}
              >
                {userRole}
              </div>
            )}
          </div>
        )}
        {onLogout && (
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={onLogout} className="hover:bg-destructive hover:text-destructive-foreground">
                <span>Refresh App</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}

export function MainLayout({ children, userRole, userName, onLogout }: MainLayoutProps) {
  const location = useLocation();
  
  // Don't show sidebar on dashboard
  if (location.pathname === '/' || location.pathname === '/dashboard') {
    return <>{children}</>;
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar userRole={userRole} userName={userName} onLogout={onLogout} />
        <SidebarInset className="flex-1">
          <header className="flex h-14 shrink-0 items-center gap-2 border-b px-4">
            <SidebarTrigger />
          </header>
          <div className="flex-1 overflow-auto p-6 lg:zoom-85 xl:zoom-90 2xl:zoom-100">
            {children}
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
