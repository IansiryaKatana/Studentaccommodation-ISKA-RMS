-- =====================================================
-- ISKA RMS - COMPLETE DATABASE SCHEMA
-- =====================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- AUTHENTICATION & USERS
-- =====================================================

-- User roles enum
CREATE TYPE user_role AS ENUM ('administrator', 'salesperson', 'ota-bookings', 'cleaner', 'accountant', 'student');

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role user_role NOT NULL DEFAULT 'student',
    phone VARCHAR(20),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- LEADS MANAGEMENT
-- =====================================================

-- Lead status enum
CREATE TYPE lead_status AS ENUM ('new', 'contacted', 'qualified', 'proposal_sent', 'negotiating', 'won', 'lost', 'converted');

-- Lead sources table
CREATE TABLE lead_sources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Leads table
CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    source_id UUID REFERENCES lead_sources(id),
    status lead_status DEFAULT 'new',
    budget DECIMAL(10,2),
    move_in_date DATE,
    duration_months INTEGER,
    notes TEXT,
    assigned_to UUID REFERENCES users(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lead follow-ups table
CREATE TABLE lead_follow_ups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL, -- 'call', 'email', 'meeting', 'proposal'
    notes TEXT,
    scheduled_date TIMESTAMP WITH TIME ZONE,
    completed_date TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- PROPERTY & ROOMS
-- =====================================================

-- Room grades table (updated for your structure)
CREATE TABLE room_grades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL, -- 'Silver', 'Gold', 'Platinum', 'Rhodium', 'Thodium Plus'
    weekly_rate DECIMAL(10,2) NOT NULL,
    studio_count INTEGER NOT NULL DEFAULT 0,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Studio status enum
CREATE TYPE studio_status AS ENUM ('vacant', 'occupied', 'dirty', 'cleaning', 'maintenance');

-- Studios table (individual studio tracking)
CREATE TABLE studios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_number VARCHAR(20) UNIQUE NOT NULL, -- e.g., 'S101', 'S102'
    room_grade_id UUID REFERENCES room_grades(id),
    floor INTEGER,
    status studio_status DEFAULT 'vacant', -- 'vacant', 'occupied', 'dirty', 'cleaning', 'maintenance'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- RESERVATIONS & BOOKINGS
-- =====================================================

-- Booking status enum
CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled');

-- Booking types enum
CREATE TYPE booking_type AS ENUM ('student', 'tourist');

-- Students table
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    student_id VARCHAR(50) UNIQUE,
    university VARCHAR(200),
    course VARCHAR(200),
    year_of_study INTEGER,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    guarantor_name VARCHAR(100),
    guarantor_phone VARCHAR(20),
    guarantor_email VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tourist profiles table
CREATE TABLE tourist_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    passport_number VARCHAR(50),
    nationality VARCHAR(100),
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reservations table (renamed from bookings)
CREATE TABLE reservations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_number VARCHAR(50) UNIQUE NOT NULL,
    type booking_type NOT NULL, -- 'student', 'tourist'
    student_id UUID REFERENCES students(id),
    tourist_id UUID REFERENCES tourist_profiles(id),
    studio_id UUID REFERENCES studios(id),
    duration_id UUID REFERENCES durations(id),
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    status booking_status DEFAULT 'pending',
    total_amount DECIMAL(10,2) NOT NULL,
    deposit_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    balance_due DECIMAL(10,2) NOT NULL,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- FINANCE & PAYMENTS
-- =====================================================

-- Payment status enum
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');

-- Payment methods enum
CREATE TYPE payment_method AS ENUM ('stripe', 'bank_transfer', 'cash', 'check');

-- Installment plans table
CREATE TABLE installment_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    number_of_installments INTEGER NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    late_fee_percentage DECIMAL(5,2) DEFAULT 0,
    late_fee_flat DECIMAL(10,2) DEFAULT 0,
    due_dates JSONB DEFAULT '[]', -- JSONB array of due dates for installments
    deposit_amount DECIMAL(10,2) DEFAULT 500.00, -- Standard deposit amount for this installment plan
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reservation installments table
CREATE TABLE reservation_installments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_id UUID REFERENCES reservations(id) ON DELETE CASCADE,
    installment_plan_id UUID REFERENCES installment_plans(id),
    installment_number INTEGER NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status payment_status DEFAULT 'pending',
    paid_date TIMESTAMP WITH TIME ZONE,
    late_fee_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Invoices table
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    reservation_id UUID REFERENCES reservations(id),
    reservation_installment_id UUID REFERENCES reservation_installments(id),
    amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    due_date DATE NOT NULL,
    status payment_status DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Payments table
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    method payment_method NOT NULL,
    status payment_status DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    transaction_id VARCHAR(255),
    processed_at TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- CLEANING MANAGEMENT
-- =====================================================

-- Cleaning status enum
CREATE TYPE cleaning_status AS ENUM ('scheduled', 'in_progress', 'completed', 'verified', 'cancelled');

-- Cleaners table
CREATE TABLE cleaners (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    hourly_rate DECIMAL(8,2) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Cleaning tasks table
CREATE TABLE cleaning_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_id UUID REFERENCES studios(id),
    cleaner_id UUID REFERENCES cleaners(id),
    scheduled_date DATE NOT NULL,
    scheduled_time TIME,
    estimated_duration INTEGER, -- in minutes
    status cleaning_status DEFAULT 'scheduled',
    notes TEXT,
    completed_at TIMESTAMP WITH TIME ZONE,
    verified_by UUID REFERENCES users(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- MAINTENANCE
-- =====================================================

-- Maintenance categories table
CREATE TABLE maintenance_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    priority INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Maintenance requests table
CREATE TABLE maintenance_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_id UUID REFERENCES studios(id),
    category_id UUID REFERENCES maintenance_categories(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    priority INTEGER DEFAULT 1, -- 1=low, 2=medium, 3=high, 4=urgent
    status VARCHAR(50) DEFAULT 'open', -- 'open', 'in_progress', 'completed', 'closed'
    reported_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    estimated_cost DECIMAL(10,2),
    actual_cost DECIMAL(10,2),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- SYSTEM CONFIGURATION
-- =====================================================

-- Durations table (for booking periods)
CREATE TABLE durations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL, -- '45-weeks', '51-weeks', 'Daily', 'Weekly'
    duration_type VARCHAR(20) NOT NULL, -- 'student', 'tourist'
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    weeks_count INTEGER NOT NULL,
    academic_year VARCHAR(20), -- '2025/2026', '2026/2027'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Pricing matrix table
CREATE TABLE pricing_matrix (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    duration_id UUID REFERENCES durations(id),
    room_grade_id UUID REFERENCES room_grades(id),
    weekly_rate_override DECIMAL(10,2), -- Optional override of room_grades.weekly_rate
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(duration_id, room_grade_id)
);

-- Module styles table (for UI customization)
CREATE TABLE module_styles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    module_name VARCHAR(50) NOT NULL,
    gradient_start VARCHAR(7) NOT NULL,
    gradient_end VARCHAR(7) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Student option fields table
CREATE TABLE student_option_fields (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    field_name VARCHAR(100) NOT NULL,
    field_type VARCHAR(50) NOT NULL, -- 'text', 'select', 'checkbox', 'date'
    field_label VARCHAR(200) NOT NULL,
    is_required BOOLEAN DEFAULT false,
    options TEXT[], -- for select fields
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lead option fields table
CREATE TABLE lead_option_fields (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    field_name VARCHAR(100) NOT NULL,
    field_type VARCHAR(50) NOT NULL,
    field_label VARCHAR(200) NOT NULL,
    is_required BOOLEAN DEFAULT false,
    options TEXT[],
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- NOTIFICATIONS
-- =====================================================

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'info', 'warning', 'success', 'error'
    is_read BOOLEAN DEFAULT false,
    related_entity_type VARCHAR(50), -- 'booking', 'payment', 'maintenance'
    related_entity_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- AUDIT LOG
-- =====================================================

-- Audit log table
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Users indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Leads indexes
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned_to ON leads(assigned_to);
CREATE INDEX idx_leads_source_id ON leads(source_id);

-- Reservations indexes
CREATE INDEX idx_reservations_status ON reservations(status);
CREATE INDEX idx_reservations_studio_id ON reservations(studio_id);
CREATE INDEX idx_reservations_duration_id ON reservations(duration_id);
CREATE INDEX idx_reservations_check_in_date ON reservations(check_in_date);
CREATE INDEX idx_reservations_check_out_date ON reservations(check_out_date);

-- Payments indexes
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_invoice_id ON payments(invoice_id);

-- Studios indexes
CREATE INDEX idx_studios_status ON studios(status);
CREATE INDEX idx_studios_room_grade_id ON studios(room_grade_id);

-- Cleaning indexes
CREATE INDEX idx_cleaning_tasks_studio_id ON cleaning_tasks(studio_id);
CREATE INDEX idx_cleaning_tasks_status ON cleaning_tasks(status);
CREATE INDEX idx_cleaning_tasks_scheduled_date ON cleaning_tasks(scheduled_date);

-- Maintenance indexes
CREATE INDEX idx_maintenance_requests_studio_id ON maintenance_requests(studio_id);
CREATE INDEX idx_maintenance_requests_status ON maintenance_requests(status);

-- Notifications indexes
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- Installment plans indexes
CREATE INDEX idx_installment_plans_due_dates ON installment_plans USING GIN (due_dates);

-- =====================================================
-- ROW LEVEL SECURITY (RLS) - DISABLED FOR DEMO
-- =====================================================

-- RLS is disabled for demo purposes to prevent loading spinner issues
-- In production, you would enable RLS and implement proper policies

-- Grant all permissions to authenticated and anonymous users for demo purposes
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon;

-- =====================================================
-- TRIGGERS FOR UPDATED_AT
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_reservations_updated_at BEFORE UPDATE ON reservations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tourist_profiles_updated_at BEFORE UPDATE ON tourist_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_maintenance_requests_updated_at BEFORE UPDATE ON maintenance_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- SAMPLE DATA INSERTION
-- =====================================================

-- Insert default lead sources
INSERT INTO lead_sources (name, description) VALUES
('Website', 'Direct website inquiries'),
('Social Media', 'Social media platforms'),
('Referral', 'Word of mouth referrals'),
('University Partnership', 'University partnerships'),
('Online Listing', 'Online property listings');

-- Insert default room grades (your structure)
INSERT INTO room_grades (name, weekly_rate, studio_count, description) VALUES
('Silver', 160.00, 12, 'Standard studio with essential amenities'),
('Gold', 175.00, 18, 'Enhanced studio with additional features'),
('Platinum', 195.00, 8, 'Premium studio with luxury amenities'),
('Rhodium', 200.00, 6, 'High-end studio with premium features'),
('Thodium Plus', 225.00, 4, 'Ultra-luxury studio with all amenities');

-- Insert default durations (your structure)
INSERT INTO durations (name, duration_type, check_in_date, check_out_date, weeks_count, academic_year) VALUES
('45-weeks', 'student', '2025-09-01', '2026-07-13', 45, '2025/2026'),
('51-weeks', 'student', '2025-09-01', '2026-08-24', 51, '2025/2026'),
('45-weeks', 'student', '2026-09-01', '2027-07-13', 45, '2026/2027'),
('51-weeks', 'student', '2026-09-01', '2027-08-24', 51, '2026/2027'),
('Daily', 'tourist', '2025-01-01', '2025-12-31', 1, NULL),
('Weekly', 'tourist', '2025-01-01', '2025-12-31', 1, NULL);

-- Insert default maintenance categories
INSERT INTO maintenance_categories (name, description, priority) VALUES
('Plumbing', 'Water and drainage issues', 2),
('Electrical', 'Electrical system problems', 2),
('HVAC', 'Heating, ventilation, and air conditioning', 2),
('Furniture', 'Furniture repairs and replacements', 1),
('Cleaning', 'Deep cleaning and maintenance', 1),
('Security', 'Security system issues', 3);

-- Insert default module styles
INSERT INTO module_styles (module_name, gradient_start, gradient_end) VALUES
('leads', '#667eea', '#764ba2'),
('ota-bookings', '#f093fb', '#f5576c'),
('students', '#4facfe', '#00f2fe'),
('cleaning', '#43e97b', '#38f9d7'),
('finance', '#fa709a', '#fee140'),
('data', '#a8edea', '#fed6e3'),
('settings', '#ffecd2', '#fcb69f'),
('student-portal', '#667eea', '#764ba2');

-- Insert default installment plans (with due dates)
INSERT INTO installment_plans (name, description, number_of_installments, discount_percentage, late_fee_percentage, late_fee_flat, due_dates, deposit_amount) VALUES
('45-weeks - 3 installments', 'Pay in 3 installments for 45-week duration', 3, 0.00, 5.00, 0.00, '["2025-10-01", "2026-01-01", "2026-04-01"]'::jsonb, 500.00),
('45-weeks - 4 installments', 'Pay in 4 installments for 45-week duration', 4, 0.00, 5.00, 0.00, '["2025-10-01", "2025-12-01", "2026-02-01", "2026-04-01"]'::jsonb, 500.00),
('45-weeks - 6 installments', 'Pay in 6 installments for 45-week duration', 6, 0.00, 5.00, 0.00, '["2025-10-01", "2025-11-01", "2025-12-01", "2026-01-01", "2026-02-01", "2026-03-01"]'::jsonb, 500.00),
('51-weeks - 3 installments', 'Pay in 3 installments for 51-week duration', 3, 0.00, 5.00, 0.00, '["2025-10-01", "2026-01-01", "2026-04-01"]'::jsonb, 500.00),
('51-weeks - 4 installments', 'Pay in 4 installments for 51-week duration', 4, 0.00, 5.00, 0.00, '["2025-10-01", "2026-01-01", "2026-04-01", "2026-07-01"]'::jsonb, 500.00),
('45-weeks - Full Payment (5% discount)', 'Pay full amount upfront for 45-week duration with 5% discount', 1, 5.00, 5.00, 0.00, '["2025-10-01"]'::jsonb, 500.00),
('51-weeks - Full Payment (5% discount)', 'Pay full amount upfront for 51-week duration with 5% discount', 1, 5.00, 5.00, 0.00, '["2025-10-01"]'::jsonb, 500.00); 