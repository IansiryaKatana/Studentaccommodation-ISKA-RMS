-- Migration: Update installment plans with correct due dates
-- This script creates/updates the installment plans with the specified due dates

-- Clear existing installment plans to avoid duplicates
DELETE FROM installment_plans;

-- Insert 3 Installments Plan
INSERT INTO installment_plans (
    name,
    description,
    number_of_installments,
    discount_percentage,
    late_fee_percentage,
    late_fee_flat,
    due_dates,
    deposit_amount,
    is_active
) VALUES (
    '3 Installments',
    'Pay in 3 installments for student accommodation',
    3,
    0.00,
    5.00,
    25.00,
    '["2025-08-16", "2026-01-01", "2026-04-01"]'::jsonb,
    500.00,
    true
);

-- Insert 4 Installments Plan
INSERT INTO installment_plans (
    name,
    description,
    number_of_installments,
    discount_percentage,
    late_fee_percentage,
    late_fee_flat,
    due_dates,
    deposit_amount,
    is_active
) VALUES (
    '4 Installments',
    'Pay in 4 installments for student accommodation',
    4,
    0.00,
    5.00,
    25.00,
    '["2025-08-16", "2025-11-01", "2026-02-01", "2026-05-01"]'::jsonb,
    500.00,
    true
);

-- Insert 10 Installments Plan
INSERT INTO installment_plans (
    name,
    description,
    number_of_installments,
    discount_percentage,
    late_fee_percentage,
    late_fee_flat,
    due_dates,
    deposit_amount,
    is_active
) VALUES (
    '10 Installments',
    'Pay in 10 installments for student accommodation',
    10,
    0.00,
    5.00,
    25.00,
    '["2025-08-16", "2025-10-01", "2025-11-01", "2025-12-01", "2026-01-01", "2026-02-01", "2026-03-01", "2026-04-01", "2026-05-01", "2026-06-01"]'::jsonb,
    500.00,
    true
);

-- Add comments to document the installment plans
COMMENT ON TABLE installment_plans IS 'Payment installment plans for student accommodation with specific due dates';
COMMENT ON COLUMN installment_plans.due_dates IS 'JSONB array of due dates for installments in YYYY-MM-DD format'; 