-- Fix storage policies to allow client-side file uploads during student creation
-- Drop existing policies
DROP POLICY IF EXISTS "Allow service role access to student documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow file uploads during student creation" ON storage.objects;

-- Create a simple policy that allows all operations on student-documents bucket
-- This is needed because the client-side upload happens before the student record exists
CREATE POLICY "Allow all operations on student documents" ON storage.objects
  FOR ALL USING (
    bucket_id = 'student-documents'
  );

-- Create a specific policy for file uploads that allows any authenticated user
CREATE POLICY "Allow authenticated file uploads" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'student-documents' AND 
    auth.role() = 'authenticated'
  );
