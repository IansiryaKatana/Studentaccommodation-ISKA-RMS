-- =====================================================
-- FIX STUDIO STATUS ENUM ORDER
-- =====================================================

-- Drop the studios table first (if it exists)
DROP TABLE IF EXISTS studios CASCADE;

-- Drop the studio_status enum (if it exists)
DROP TYPE IF EXISTS studio_status CASCADE;

-- Recreate the studio_status enum first
CREATE TYPE studio_status AS ENUM ('vacant', 'occupied', 'dirty', 'cleaning', 'maintenance');

-- Recreate the studios table with proper enum reference
CREATE TABLE studios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_number VARCHAR(20) UNIQUE NOT NULL, -- e.g., 'S101', 'S102'
    room_grade_id UUID REFERENCES room_grades(id),
    floor INTEGER,
    status studio_status DEFAULT 'vacant', -- 'vacant', 'occupied', 'dirty', 'cleaning', 'maintenance'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Recreate indexes
CREATE INDEX idx_studios_status ON studios(status);
CREATE INDEX idx_studios_room_grade_id ON studios(room_grade_id);

-- Add some sample studio data
INSERT INTO studios (studio_number, room_grade_id, floor, status, is_active) VALUES
('S101', (SELECT id FROM room_grades WHERE name = 'Silver' LIMIT 1), 1, 'vacant', true),
('S102', (SELECT id FROM room_grades WHERE name = 'Silver' LIMIT 1), 1, 'occupied', true),
('S103', (SELECT id FROM room_grades WHERE name = 'Gold' LIMIT 1), 1, 'vacant', true),
('S201', (SELECT id FROM room_grades WHERE name = 'Gold' LIMIT 1), 2, 'dirty', true),
('S202', (SELECT id FROM room_grades WHERE name = 'Platinum' LIMIT 1), 2, 'vacant', true),
('S203', (SELECT id FROM room_grades WHERE name = 'Platinum' LIMIT 1), 2, 'occupied', true),
('S301', (SELECT id FROM room_grades WHERE name = 'Rhodium' LIMIT 1), 3, 'vacant', true),
('S302', (SELECT id FROM room_grades WHERE name = 'Rhodium' LIMIT 1), 3, 'maintenance', true),
('S303', (SELECT id FROM room_grades WHERE name = 'Thodium Plus' LIMIT 1), 3, 'vacant', true),
('S401', (SELECT id FROM room_grades WHERE name = 'Thodium Plus' LIMIT 1), 4, 'cleaning', true)
ON CONFLICT (studio_number) DO NOTHING; 