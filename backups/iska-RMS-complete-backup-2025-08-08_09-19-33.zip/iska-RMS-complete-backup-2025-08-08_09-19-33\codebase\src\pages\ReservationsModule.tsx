
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ReservationsOverview from '@/components/reservations/ReservationsOverview';

import TouristsBookings from '@/components/reservations/TouristsBookings';
import AddTouristBooking from '@/components/reservations/AddTouristBooking';
import CalendarView from '@/components/reservations/CalendarView';
import CheckInOut from '@/components/reservations/CheckInOut';
import StudiosList from '@/components/reservations/StudiosList';
import StudioDetail from '@/components/reservations/StudioDetail';
import AddStudio from '@/components/reservations/AddStudio';
import EditStudio from '@/components/reservations/EditStudio';
import TouristDetail from '@/components/reservations/TouristDetail';
import TouristCheckInOut from '@/components/reservations/TouristCheckInOut';

const ReservationsModule = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route index element={<ReservationsOverview />} />

        <Route path="tourists" element={<TouristsBookings />} />
        <Route path="tourists/new" element={<AddTouristBooking />} />
        <Route path="studios" element={<StudiosList />} />
        <Route path="studios/add" element={<AddStudio />} />
        <Route path="studios/:id" element={<StudioDetail />} />
        <Route path="studios/:id/edit" element={<EditStudio />} />
        <Route path="tourists/:id" element={<TouristDetail />} />
        <Route path="tourists/:id/checkinout" element={<TouristCheckInOut />} />
        <Route path="calendar" element={<CalendarView />} />
        <Route path="checkin" element={<CheckInOut />} />
      </Routes>
    </div>
  );
};

export default ReservationsModule;
