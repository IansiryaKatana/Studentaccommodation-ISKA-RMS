-- =====================================================
-- ADD STUDIO_ID TO STUDENTS TABLE
-- =====================================================

-- Add studio_id field to students table
ALTER TABLE students ADD COLUMN IF NOT EXISTS studio_id UUID REFERENCES studios(id);

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_students_studio_id ON students(studio_id); 