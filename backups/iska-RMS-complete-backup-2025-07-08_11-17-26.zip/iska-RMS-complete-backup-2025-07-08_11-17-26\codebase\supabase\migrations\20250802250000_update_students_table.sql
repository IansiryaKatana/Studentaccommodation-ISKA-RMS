-- Update students table with comprehensive fields
-- Add missing fields that are used in the frontend

-- Add new columns to students table
ALTER TABLE students ADD COLUMN IF NOT EXISTS birthday DATE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS ethnicity VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS gender VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS ucas_id VARCHAR(50);
ALTER TABLE students ADD COLUMN IF NOT EXISTS country VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS mobile VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS address_line1 TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS post_code VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS town VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS academic_year VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS field_of_study VARCHAR(200);
ALTER TABLE students ADD COLUMN IF NOT EXISTS guarantor_address TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS guarantor_relationship VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS passport_number VARCHAR(50);
ALTER TABLE students ADD COLUMN IF NOT EXISTS visa_number VARCHAR(50);
ALTER TABLE students ADD COLUMN IF NOT EXISTS visa_expiry_date DATE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS brp_number VARCHAR(50);
ALTER TABLE students ADD COLUMN IF NOT EXISTS brp_expiry_date DATE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS uk_address TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS uk_post_code VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS uk_town VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS home_country VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS home_address TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS home_post_code VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS home_town VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS home_phone VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_name VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_email VARCHAR(255);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_phone VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_address TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_post_code VARCHAR(20);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_town VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS parent_country VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS special_requirements TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS dietary_restrictions TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS medical_conditions TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS allergies TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS room_preference VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS payment_plan VARCHAR(100);
ALTER TABLE students ADD COLUMN IF NOT EXISTS deposit_paid BOOLEAN DEFAULT false;
ALTER TABLE students ADD COLUMN IF NOT EXISTS wants_installments BOOLEAN DEFAULT false;
ALTER TABLE students ADD COLUMN IF NOT EXISTS installment_plan_id UUID REFERENCES installment_plans(id);
ALTER TABLE students ADD COLUMN IF NOT EXISTS assigned_to UUID REFERENCES users(id);
ALTER TABLE students ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'active';
ALTER TABLE students ADD COLUMN IF NOT EXISTS notes TEXT;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_students_email ON students(user_id);
CREATE INDEX IF NOT EXISTS idx_students_university ON students(university);
CREATE INDEX IF NOT EXISTS idx_students_academic_year ON students(academic_year);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
CREATE INDEX IF NOT EXISTS idx_students_assigned_to ON students(assigned_to);

-- Create student_agreements table for student agreements
CREATE TABLE IF NOT EXISTS student_agreements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    agreement_type VARCHAR(100) NOT NULL, -- 'tenancy', 'code_of_conduct', 'payment_plan'
    agreement_content TEXT NOT NULL,
    signed_at TIMESTAMP WITH TIME ZONE,
    signed_by UUID REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'signed', 'expired'
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for student_agreements
CREATE INDEX IF NOT EXISTS idx_student_agreements_student_id ON student_agreements(student_id);
CREATE INDEX IF NOT EXISTS idx_student_agreements_status ON student_agreements(status);

-- Add trigger for updated_at
CREATE TRIGGER update_student_agreements_updated_at 
    BEFORE UPDATE ON student_agreements 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column(); 