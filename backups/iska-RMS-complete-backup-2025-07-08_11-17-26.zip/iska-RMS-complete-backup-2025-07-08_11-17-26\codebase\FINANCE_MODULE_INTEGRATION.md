# Finance Module Integration - Complete Implementation

## Overview

This document outlines the complete finance module integration for the ISKA RMS system, covering both tourist and student reservations with automatic financial record creation, refund management, and Xero integration capabilities.

## 🎯 Key Features Implemented

### 1. **Tourist Reservation Finance**
- **Automatic Invoice Creation**: When a tourist booking is created, an invoice record is automatically generated for tracking purposes
- **External Platform Integration**: Payments are handled on external platforms (Airbnb, etc.), but invoices are tracked internally
- **Revenue Recognition**: Revenue is recognized when the booking is made
- **No Tax Tracking**: Tax is handled by external platforms

### 2. **Student Reservation Finance**
- **Deposit Management**: £99 deposit invoice created immediately
- **Installment Plans**: Support for 3, 4, and 10 installment plans
- **Automatic Installment Creation**: Separate invoices created for each installment with due dates
- **Balance Calculation**: Remaining balance after deposit is distributed across installments
- **Revenue Tracking**: Deposit and installments tracked against total revenue

### 3. **Refund Management**
- **Separate Refunds Table**: Dedicated table for tracking all refunds
- **Refund Reasons**: Predefined reasons for refunds (Guest Cancellation, Property Issue, etc.)
- **Refund Types**: Full, Partial, and Deposit-only refunds
- **Financial Impact**: Refunds automatically reduce revenue calculations

### 4. **Xero Integration**
- **Batch Export**: Export capability for invoices and payments
- **Export Status Tracking**: Track which records have been exported to Xero
- **Xero IDs**: Store Xero invoice and payment IDs for reference

## 📊 Database Schema

### New Tables Created

#### 1. **refunds**
```sql
CREATE TABLE refunds (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_id UUID REFERENCES reservations(id) ON DELETE CASCADE,
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    reason VARCHAR(255) NOT NULL,
    refund_type VARCHAR(50) NOT NULL DEFAULT 'full',
    processed_at TIMESTAMP WITH TIME ZONE,
    xero_refund_id VARCHAR(255),
    xero_exported_at TIMESTAMP WITH TIME ZONE,
    xero_export_status VARCHAR(50) DEFAULT 'pending',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### 2. **refund_reasons**
```sql
CREATE TABLE refund_reasons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### Enhanced Tables

#### 1. **reservations** (Added Fields)
- `price_per_night` DECIMAL(10,2)
- `booking_source_id` UUID REFERENCES tourist_booking_sources(id)
- `guest_status_id` UUID REFERENCES tourist_guest_statuses(id)

#### 2. **invoices** (Added Xero Fields)
- `xero_invoice_id` VARCHAR(255)
- `xero_exported_at` TIMESTAMP WITH TIME ZONE
- `xero_export_status` VARCHAR(50) DEFAULT 'pending'

#### 3. **payments** (Added Xero Fields)
- `xero_payment_id` VARCHAR(255)
- `xero_exported_at` TIMESTAMP WITH TIME ZONE
- `xero_export_status` VARCHAR(50) DEFAULT 'pending'

#### 4. **installment_plans** (Added Late Fee Fields)
- `late_fee_enabled` BOOLEAN DEFAULT false
- `late_fee_days` INTEGER DEFAULT 7

## 🔄 Automatic Financial Record Creation

### Tourist Reservations
When a tourist booking is created:

1. **Reservation Created**: Basic reservation record with pricing information
2. **Invoice Created**: Automatic invoice for total amount (status: 'completed')
3. **No Payment Records**: Payments handled externally

```typescript
// Example: Tourist booking for £500
{
  reservation: {
    type: 'tourist',
    total_amount: 500,
    price_per_night: 100,
    // ... other fields
  },
  invoice: {
    invoice_number: 'INV-2025-0001',
    amount: 500,
    status: 'completed', // External payment handled
    // ... other fields
  }
}
```

### Student Reservations
When a student booking is created:

1. **Reservation Created**: With total amount and deposit calculation
2. **Deposit Invoice**: £99 deposit invoice (status: 'pending')
3. **Installment Invoices**: If installment plan selected, creates separate invoices for each installment

```typescript
// Example: Student booking for £2000 with 3 installments
{
  reservation: {
    type: 'student',
    total_amount: 2000,
    deposit_amount: 99,
    balance_due: 1901,
    // ... other fields
  },
  depositInvoice: {
    invoice_number: 'INV-2025-0002',
    amount: 99,
    status: 'pending',
    // ... other fields
  },
  installments: [
    {
      installment_number: 1,
      amount: 634,
      due_date: '2025-02-01',
      status: 'pending'
    },
    {
      installment_number: 2,
      amount: 634,
      due_date: '2025-03-01',
      status: 'pending'
    },
    {
      installment_number: 3,
      amount: 633, // Remaining amount
      due_date: '2025-04-01',
      status: 'pending'
    }
  ]
}
```

## 💰 Financial Calculations

### Revenue Recognition
- **Tourists**: Recognized when booking is created
- **Students**: Recognized per installment as payments are received

### Outstanding Balances
- **Tourists**: Usually 0 (external platforms handle payments)
- **Students**: Total amount minus deposits and paid installments

### Collection Rates
- **Tourists**: 100% (external platforms)
- **Students**: (Total Collected / Total Amount) × 100

## 📈 Financial Reports

### 1. **Daily Revenue**
- Revenue by date
- Number of reservations per day
- Average revenue per reservation

### 2. **Revenue by Type**
- Tourist revenue vs Student revenue
- Outstanding amounts by type
- Collection rates by type

### 3. **Recent Activity**
- Recent invoices
- Recent payments
- Recent refunds

### 4. **Xero Integration Status**
- Export status for invoices
- Export status for payments
- Failed exports tracking

## 🔧 API Methods Added

### Finance Methods
```typescript
// Refund Management
static async getRefundReasons(): Promise<RefundReason[]>
static async createRefund(refundData: CreateRefundData): Promise<Refund>
static async getRefundsByReservation(reservationId: string): Promise<Refund[]>

// Student Financial Records
static async createStudentFinancialRecords(
  reservationId: string, 
  studentData: {
    depositAmount: number;
    totalAmount: number;
    installmentPlanId?: string;
    createdBy: string;
  }
): Promise<{ depositInvoice: Invoice; installments: ReservationInstallment[] }>

// Invoice and Installment Management
static async getInvoicesByReservation(reservationId: string): Promise<Invoice[]>
static async getInstallmentsByReservation(reservationId: string): Promise<ReservationInstallment[]>

// Invoice Number Generation
static async generateInvoiceNumber(): Promise<string>
```

## 🎨 UI Components

### 1. **FinanceOverview.tsx**
- Comprehensive financial dashboard
- Revenue tracking by type
- Outstanding balances
- Daily revenue charts
- Xero export functionality

### 2. **RefundManagement.tsx**
- Create refunds for cancelled reservations
- Track refund history
- Refund reason selection
- Financial impact visualization

## 📊 Business Logic

### Tourist Financial Flow
1. **Booking Created** → Invoice Created (External Payment)
2. **External Payment** → No internal payment record
3. **Cancellation** → Refund record created

### Student Financial Flow
1. **Booking Created** → Deposit Invoice + Installment Invoices
2. **Deposit Paid** → Payment record linked to deposit invoice
3. **Installment Paid** → Payment record linked to installment invoice
4. **Cancellation** → Refund records for unpaid amounts

## 🔗 Xero Integration

### Export Process
1. **Batch Export**: Export pending invoices and payments
2. **Status Tracking**: Update export status after successful export
3. **Error Handling**: Track failed exports for retry
4. **ID Mapping**: Store Xero IDs for future reference

### Exportable Data
- **Invoices**: All invoice records with amounts and due dates
- **Payments**: All payment records with amounts and methods
- **Refunds**: All refund records with amounts and reasons

## 🚀 Implementation Status

### ✅ Completed
- [x] Database schema updates
- [x] API methods for finance operations
- [x] Tourist reservation finance integration
- [x] Student reservation finance integration
- [x] Refund management system
- [x] Finance overview dashboard
- [x] Xero integration framework
- [x] Automatic invoice generation
- [x] Installment plan support

### 🔄 Next Steps
- [ ] Implement actual Xero API integration
- [ ] Add payment processing for student installments
- [ ] Create automated late fee calculations
- [ ] Add financial reporting exports
- [ ] Implement real-time payment notifications

## 💡 Key Benefits

1. **Automated Financial Tracking**: No manual invoice creation needed
2. **Complete Audit Trail**: All financial transactions tracked
3. **Flexible Payment Plans**: Support for various installment options
4. **Refund Management**: Proper handling of cancellations
5. **Xero Integration**: Seamless accounting software integration
6. **Real-time Reporting**: Live financial dashboards
7. **Revenue Optimization**: Clear visibility into revenue streams

## 📋 Usage Examples

### Creating a Tourist Booking
```typescript
const result = await ApiService.createTouristReservation({
  touristProfile: { /* tourist data */ },
  reservation: { /* reservation data */ }
});
// Automatically creates invoice for tracking
```

### Creating a Student Booking
```typescript
const reservation = await ApiService.createCompleteReservation(reservationData);
await ApiService.createStudentFinancialRecords(reservation.id, {
  depositAmount: 99,
  totalAmount: 2000,
  installmentPlanId: 'plan-3-months',
  createdBy: 'admin-id'
});
// Creates deposit invoice + 3 installment invoices
```

### Creating a Refund
```typescript
await ApiService.createRefund({
  reservation_id: 'reservation-id',
  amount: 500,
  reason: 'Guest Cancellation',
  refund_type: 'full',
  created_by: 'admin-id'
});
```

This finance module integration provides a complete, automated financial management system that handles both tourist and student reservations with proper accounting practices and external software integration. 