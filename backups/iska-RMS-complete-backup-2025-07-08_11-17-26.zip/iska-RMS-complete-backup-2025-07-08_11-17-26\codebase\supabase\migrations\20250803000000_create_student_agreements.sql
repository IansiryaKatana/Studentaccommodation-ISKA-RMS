-- Create student_agreements table
CREATE TABLE IF NOT EXISTS student_agreements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  document_url TEXT,
  signed_document_url TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'signed', 'overdue')),
  uploaded_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  due_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE student_agreements ENABLE ROW LEVEL SECURITY;

-- Policy for students to view their own agreements
CREATE POLICY "Students can view their own agreements" ON student_agreements
  FOR SELECT USING (
    student_id IN (
      SELECT id FROM students WHERE user_id = auth.uid()
    )
  );

-- Policy for staff to view all agreements
CREATE POLICY "Staff can view all agreements" ON student_agreements
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.role IN ('administrator', 'salesperson', 'reservations', 'accountant')
    )
  );

-- Insert dummy data for existing students
INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'Accommodation Agreement',
  'Standard accommodation agreement for the academic year',
  'https://example.com/agreements/accommodation.pdf',
  'signed',
  NOW() + INTERVAL '30 days'
FROM students s
WHERE NOT EXISTS (
  SELECT 1 FROM student_agreements sa WHERE sa.student_id = s.id
);

INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'House Rules Agreement',
  'Rules and regulations for living in the accommodation',
  'https://example.com/agreements/house-rules.pdf',
  'pending',
  NOW() + INTERVAL '7 days'
FROM students s
WHERE NOT EXISTS (
  SELECT 1 FROM student_agreements sa WHERE sa.student_id = s.id AND sa.title = 'House Rules Agreement'
);

INSERT INTO student_agreements (student_id, title, description, document_url, status, due_date)
SELECT 
  s.id,
  'Payment Plan Agreement',
  'Agreement for installment payment plan',
  'https://example.com/agreements/payment-plan.pdf',
  'signed',
  NOW() + INTERVAL '14 days'
FROM students s
WHERE NOT EXISTS (
  SELECT 1 FROM student_agreements sa WHERE sa.student_id = s.id AND sa.title = 'Payment Plan Agreement'
); 