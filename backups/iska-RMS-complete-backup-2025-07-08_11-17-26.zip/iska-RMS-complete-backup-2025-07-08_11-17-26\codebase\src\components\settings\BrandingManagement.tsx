import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { ApiService, Branding } from '@/services/api';
import {
  Palette,
  Building,
  Phone,
  Mail,
  Globe,
  Image,
  Save,
  Upload,
  Eye,
  Loader2,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

const BrandingManagement = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [branding, setBranding] = useState<Branding | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    fetchBranding();
  }, []);

  const fetchBranding = async () => {
    try {
      setIsLoading(true);
      const data = await ApiService.getBranding();
      setBranding(data);
    } catch (error) {
      console.error('Error fetching branding:', error);
      toast({
        title: "Error",
        description: "Failed to load branding information.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!branding) return;
    
    try {
      setIsSaving(true);
      await ApiService.updateBranding(branding);
      toast({
        title: "Success",
        description: "Branding information updated successfully.",
      });
    } catch (error) {
      console.error('Error updating branding:', error);
      toast({
        title: "Error",
        description: "Failed to update branding information.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleInputChange = (field: keyof Branding, value: string) => {
    if (!branding) return;
    setBranding({
      ...branding,
      [field]: value
    });
  };

  const handleFileUpload = (field: 'logo_url' | 'favicon_url', file: File) => {
    // In a real implementation, you would upload the file to Supabase Storage
    // For now, we'll just simulate the upload
    const reader = new FileReader();
    reader.onload = (e) => {
      if (branding && e.target?.result) {
        setBranding({
          ...branding,
          [field]: e.target.result as string
        });
      }
    };
    reader.readAsDataURL(file);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
          <span className="ml-2 text-gray-500">Loading branding information...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Branding Management</h1>
          <p className="text-gray-600">Customize your company's visual identity and contact information</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={() => setPreviewMode(!previewMode)}
          >
            <Eye className="h-4 w-4 mr-2" />
            {previewMode ? 'Edit Mode' : 'Preview Mode'}
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isSaving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Company Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Company Information
            </CardTitle>
            <CardDescription>
              Basic company details that will appear on invoices and documents
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="company_name">Company Name *</Label>
              <Input
                id="company_name"
                value={branding?.company_name || ''}
                onChange={(e) => handleInputChange('company_name', e.target.value)}
                disabled={previewMode}
                placeholder="Enter company name"
              />
            </div>
            <div>
              <Label htmlFor="company_address">Company Address</Label>
              <Textarea
                id="company_address"
                value={branding?.company_address || ''}
                onChange={(e) => handleInputChange('company_address', e.target.value)}
                disabled={previewMode}
                placeholder="Enter company address"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="company_phone">Phone Number</Label>
                <Input
                  id="company_phone"
                  value={branding?.company_phone || ''}
                  onChange={(e) => handleInputChange('company_phone', e.target.value)}
                  disabled={previewMode}
                  placeholder="+44 20 1234 5678"
                />
              </div>
              <div>
                <Label htmlFor="company_email">Email Address</Label>
                <Input
                  id="company_email"
                  type="email"
                  value={branding?.company_email || ''}
                  onChange={(e) => handleInputChange('company_email', e.target.value)}
                  disabled={previewMode}
                  placeholder="info@company.com"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="company_website">Website</Label>
              <Input
                id="company_website"
                value={branding?.company_website || ''}
                onChange={(e) => handleInputChange('company_website', e.target.value)}
                disabled={previewMode}
                placeholder="https://company.com"
              />
            </div>
          </CardContent>
        </Card>

        {/* Visual Identity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5" />
              Visual Identity
            </CardTitle>
            <CardDescription>
              Colors, fonts, and visual elements for your brand
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="primary_color">Primary Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="primary_color"
                  type="color"
                  value={branding?.primary_color || '#3B82F6'}
                  onChange={(e) => handleInputChange('primary_color', e.target.value)}
                  disabled={previewMode}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={branding?.primary_color || '#3B82F6'}
                  onChange={(e) => handleInputChange('primary_color', e.target.value)}
                  disabled={previewMode}
                  placeholder="#3B82F6"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="secondary_color">Secondary Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="secondary_color"
                  type="color"
                  value={branding?.secondary_color || '#1F2937'}
                  onChange={(e) => handleInputChange('secondary_color', e.target.value)}
                  disabled={previewMode}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={branding?.secondary_color || '#1F2937'}
                  onChange={(e) => handleInputChange('secondary_color', e.target.value)}
                  disabled={previewMode}
                  placeholder="#1F2937"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="accent_color">Accent Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="accent_color"
                  type="color"
                  value={branding?.accent_color || '#10B981'}
                  onChange={(e) => handleInputChange('accent_color', e.target.value)}
                  disabled={previewMode}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={branding?.accent_color || '#10B981'}
                  onChange={(e) => handleInputChange('accent_color', e.target.value)}
                  disabled={previewMode}
                  placeholder="#10B981"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="font_family">Font Family</Label>
              <Input
                id="font_family"
                value={branding?.font_family || 'Inter'}
                onChange={(e) => handleInputChange('font_family', e.target.value)}
                disabled={previewMode}
                placeholder="Inter"
              />
            </div>
          </CardContent>
        </Card>

        {/* Logo & Favicon */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="h-5 w-5" />
              Logo & Favicon
            </CardTitle>
            <CardDescription>
              Upload your company logo and favicon for professional branding
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="logo">Company Logo</Label>
              <div className="mt-2 space-y-2">
                {branding?.logo_url && (
                  <div className="flex items-center gap-2">
                    <img
                      src={branding.logo_url}
                      alt="Company Logo"
                      className="h-12 w-auto object-contain border rounded"
                    />
                    <Badge variant="secondary">Logo uploaded</Badge>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Input
                    id="logo"
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload('logo_url', file);
                    }}
                    disabled={previewMode}
                    className="flex-1"
                  />
                  <Button variant="outline" size="sm" disabled={previewMode}>
                    <Upload className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
            <Separator />
            <div>
              <Label htmlFor="favicon">Favicon</Label>
              <div className="mt-2 space-y-2">
                {branding?.favicon_url && (
                  <div className="flex items-center gap-2">
                    <img
                      src={branding.favicon_url}
                      alt="Favicon"
                      className="h-8 w-8 object-contain border rounded"
                    />
                    <Badge variant="secondary">Favicon uploaded</Badge>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Input
                    id="favicon"
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload('favicon_url', file);
                    }}
                    disabled={previewMode}
                    className="flex-1"
                  />
                  <Button variant="outline" size="sm" disabled={previewMode}>
                    <Upload className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Brand Preview
            </CardTitle>
            <CardDescription>
              See how your branding will appear on documents
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div 
              className="p-6 border rounded-lg space-y-4"
              style={{
                backgroundColor: branding?.primary_color || '#3B82F6',
                color: 'white',
                fontFamily: branding?.font_family || 'Inter'
              }}
            >
              <div className="flex items-center gap-3">
                {branding?.logo_url && (
                  <img
                    src={branding.logo_url}
                    alt="Logo"
                    className="h-8 w-auto object-contain"
                  />
                )}
                <h3 className="text-lg font-semibold">{branding?.company_name || 'Company Name'}</h3>
              </div>
              <div className="space-y-1 text-sm">
                <p>{branding?.company_address || 'Company Address'}</p>
                <p>{branding?.company_phone || 'Phone Number'}</p>
                <p>{branding?.company_email || 'Email Address'}</p>
                <p>{branding?.company_website || 'Website'}</p>
              </div>
            </div>
            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium mb-2">Color Palette</h4>
              <div className="flex gap-2">
                <div
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: branding?.primary_color || '#3B82F6' }}
                  title="Primary Color"
                />
                <div
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: branding?.secondary_color || '#1F2937' }}
                  title="Secondary Color"
                />
                <div
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: branding?.accent_color || '#10B981' }}
                  title="Accent Color"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status */}
      <Card>
        <CardHeader>
          <CardTitle>Branding Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              {branding?.company_name ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-yellow-600" />
              )}
              <span className="text-sm">Company Name</span>
            </div>
            <div className="flex items-center gap-2">
              {branding?.company_address ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-yellow-600" />
              )}
              <span className="text-sm">Address</span>
            </div>
            <div className="flex items-center gap-2">
              {branding?.logo_url ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-yellow-600" />
              )}
              <span className="text-sm">Logo</span>
            </div>
            <div className="flex items-center gap-2">
              {branding?.favicon_url ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-yellow-600" />
              )}
              <span className="text-sm">Favicon</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BrandingManagement; 