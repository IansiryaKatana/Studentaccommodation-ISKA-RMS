import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { AppInitializer } from './services/initializeApp'

// Initialize the application before rendering
AppInitializer.initialize().then(() => {
  createRoot(document.getElementById("root")!).render(<App />);
}).catch((error) => {
  console.error('Failed to initialize app:', error);
  // Still render the app even if initialization fails
  createRoot(document.getElementById("root")!).render(<App />);
});
