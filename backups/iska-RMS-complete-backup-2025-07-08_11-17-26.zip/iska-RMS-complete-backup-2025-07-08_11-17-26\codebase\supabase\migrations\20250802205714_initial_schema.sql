-- =====================================================
-- ISKA RMS - COMPLETE DATABASE SCHEMA
-- =====================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- AUTHENTICATION & USERS
-- =====================================================

-- User roles enum
CREATE TYPE user_role AS ENUM ('administrator', 'salesperson', 'reservations', 'cleaner', 'accountant', 'student');

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role user_role NOT NULL DEFAULT 'student',
    phone VARCHAR(20),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- LEADS MANAGEMENT
-- =====================================================

-- Lead status enum
CREATE TYPE lead_status AS ENUM ('new', 'contacted', 'qualified', 'proposal_sent', 'negotiating', 'won', 'lost', 'converted');

-- Lead sources table
CREATE TABLE lead_sources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Leads table
CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    source_id UUID REFERENCES lead_sources(id),
    status lead_status DEFAULT 'new',
    budget DECIMAL(10,2),
    move_in_date DATE,
    duration_months INTEGER,
    notes TEXT,
    assigned_to UUID REFERENCES users(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lead follow-ups table
CREATE TABLE lead_follow_ups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL, -- 'call', 'email', 'meeting', 'proposal'
    notes TEXT,
    scheduled_date TIMESTAMP WITH TIME ZONE,
    completed_date TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- PROPERTY & ROOMS
-- =====================================================

-- Room grades table (updated for your structure)
CREATE TABLE room_grades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL, -- 'Silver', 'Gold', 'Platinum', 'Rhodium', 'Thodium Plus'
    weekly_rate DECIMAL(10,2) NOT NULL,
    studio_count INTEGER NOT NULL DEFAULT 0,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Studio status enum
CREATE TYPE studio_status AS ENUM ('vacant', 'occupied', 'dirty', 'cleaning', 'maintenance');

-- Studios table (individual studio tracking)
CREATE TABLE studios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_number VARCHAR(20) UNIQUE NOT NULL, -- e.g., 'S101', 'S102'
    room_grade_id UUID REFERENCES room_grades(id),
    floor INTEGER,
    status studio_status DEFAULT 'vacant', -- 'vacant', 'occupied', 'dirty', 'cleaning', 'maintenance'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- RESERVATIONS & BOOKINGS
-- =====================================================

-- Booking status enum
CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled');

-- Booking types enum
CREATE TYPE booking_type AS ENUM ('student', 'tourist');

-- Students table
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    student_id VARCHAR(50) UNIQUE,
    university VARCHAR(200),
    course VARCHAR(200),
    year_of_study INTEGER,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    guarantor_name VARCHAR(100),
    guarantor_phone VARCHAR(20),
    guarantor_email VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tourist profiles table
CREATE TABLE tourist_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    passport_number VARCHAR(50),
    nationality VARCHAR(100),
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- SYSTEM CONFIGURATION
-- =====================================================

-- Durations table (for booking periods)
CREATE TABLE durations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL, -- '45-weeks', '51-weeks', 'Daily', 'Weekly'
    duration_type VARCHAR(20) NOT NULL, -- 'student', 'tourist'
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    weeks_count INTEGER NOT NULL,
    academic_year VARCHAR(20), -- '2025/2026', '2026/2027'
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reservations table (renamed from bookings)
CREATE TABLE reservations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_number VARCHAR(50) UNIQUE NOT NULL,
    type booking_type NOT NULL, -- 'student', 'tourist'
    student_id UUID REFERENCES students(id),
    tourist_id UUID REFERENCES tourist_profiles(id),
    studio_id UUID REFERENCES studios(id),
    duration_id UUID REFERENCES durations(id),
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    status booking_status DEFAULT 'pending',
    total_amount DECIMAL(10,2) NOT NULL,
    deposit_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    balance_due DECIMAL(10,2) NOT NULL,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- FINANCE & PAYMENTS
-- =====================================================

-- Payment status enum
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');

-- Payment methods enum
CREATE TYPE payment_method AS ENUM ('stripe', 'bank_transfer', 'cash', 'check');

-- Installment plans table
CREATE TABLE installment_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    number_of_installments INTEGER NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    late_fee_percentage DECIMAL(5,2) DEFAULT 0,
    late_fee_flat DECIMAL(10,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reservation installments table
CREATE TABLE reservation_installments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reservation_id UUID REFERENCES reservations(id) ON DELETE CASCADE,
    installment_plan_id UUID REFERENCES installment_plans(id),
    installment_number INTEGER NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status payment_status DEFAULT 'pending',
    paid_date TIMESTAMP WITH TIME ZONE,
    late_fee_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Invoices table
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    reservation_id UUID REFERENCES reservations(id),
    reservation_installment_id UUID REFERENCES reservation_installments(id),
    amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    due_date DATE NOT NULL,
    status payment_status DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Payments table
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID REFERENCES invoices(id),
    amount DECIMAL(10,2) NOT NULL,
    method payment_method NOT NULL,
    status payment_status DEFAULT 'pending',
    stripe_payment_intent_id VARCHAR(255),
    transaction_id VARCHAR(255),
    processed_at TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- CLEANING MANAGEMENT
-- =====================================================

-- Cleaning status enum
CREATE TYPE cleaning_status AS ENUM ('scheduled', 'in_progress', 'completed', 'verified', 'cancelled');

-- Cleaners table
CREATE TABLE cleaners (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    hourly_rate DECIMAL(8,2) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Cleaning tasks table
CREATE TABLE cleaning_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_id UUID REFERENCES studios(id),
    cleaner_id UUID REFERENCES cleaners(id),
    scheduled_date DATE NOT NULL,
    scheduled_time TIME,
    estimated_duration INTEGER, -- in minutes
    status cleaning_status DEFAULT 'scheduled',
    notes TEXT,
    completed_at TIMESTAMP WITH TIME ZONE,
    verified_by UUID REFERENCES users(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- MAINTENANCE
-- =====================================================

-- Maintenance categories table
CREATE TABLE maintenance_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    priority INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Maintenance requests table
CREATE TABLE maintenance_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    studio_id UUID REFERENCES studios(id),
    category_id UUID REFERENCES maintenance_categories(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    priority INTEGER DEFAULT 1, -- 1=low, 2=medium, 3=high, 4=urgent
    status VARCHAR(50) DEFAULT 'open', -- 'open', 'in_progress', 'completed', 'closed'
    reported_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    estimated_cost DECIMAL(10,2),
    actual_cost DECIMAL(10,2),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- SYSTEM CONFIGURATION
-- =====================================================

-- Pricing matrix table
CREATE TABLE pricing_matrix (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    duration_id UUID REFERENCES durations(id),
    room_grade_id UUID REFERENCES room_grades(id),
    weekly_rate_override DECIMAL(10,2), -- Optional override of room_grades.weekly_rate
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(duration_id, room_grade_id)
);

-- Module styles table (for UI customization)
CREATE TABLE module_styles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    module_name VARCHAR(50) NOT NULL,
    gradient_start VARCHAR(7) NOT NULL,
    gradient_end VARCHAR(7) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Student option fields table
CREATE TABLE student_option_fields (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    field_name VARCHAR(100) NOT NULL,
    field_type VARCHAR(50) NOT NULL, -- 'text', 'select', 'checkbox', 'date'
    field_label VARCHAR(200) NOT NULL,
    is_required BOOLEAN DEFAULT false,
    options TEXT[], -- for select fields
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lead option fields table
CREATE TABLE lead_option_fields (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    field_name VARCHAR(100) NOT NULL,
    field_type VARCHAR(50) NOT NULL,
    field_label VARCHAR(200) NOT NULL,
    is_required BOOLEAN DEFAULT false,
    options TEXT[],
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- NOTIFICATIONS
-- =====================================================

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'info', 'warning', 'success', 'error'
    is_read BOOLEAN DEFAULT false,
    related_entity_type VARCHAR(50), -- 'booking', 'payment', 'maintenance'
    related_entity_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- AUDIT LOG
-- =====================================================

-- Audit log table
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Users indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Leads indexes
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned_to ON leads(assigned_to);
CREATE INDEX idx_leads_source_id ON leads(source_id);

-- Reservations indexes
CREATE INDEX idx_reservations_status ON reservations(status);
CREATE INDEX idx_reservations_studio_id ON reservations(studio_id);
CREATE INDEX idx_reservations_duration_id ON reservations(duration_id);
CREATE INDEX idx_reservations_check_in_date ON reservations(check_in_date);
CREATE INDEX idx_reservations_check_out_date ON reservations(check_out_date);

-- Payments indexes
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_invoice_id ON payments(invoice_id);

-- Studios indexes
CREATE INDEX idx_studios_status ON studios(status);
CREATE INDEX idx_studios_room_grade_id ON studios(room_grade_id);

-- Cleaning indexes
CREATE INDEX idx_cleaning_tasks_studio_id ON cleaning_tasks(studio_id);
CREATE INDEX idx_cleaning_tasks_status ON cleaning_tasks(status);
CREATE INDEX idx_cleaning_tasks_scheduled_date ON cleaning_tasks(scheduled_date);

-- Maintenance indexes
CREATE INDEX idx_maintenance_requests_studio_id ON maintenance_requests(studio_id);
CREATE INDEX idx_maintenance_requests_status ON maintenance_requests(status);

-- Notifications indexes
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- =====================================================
-- ROW LEVEL SECURITY (RLS) - DISABLED FOR DEMO
-- =====================================================

-- RLS is disabled for demo purposes to prevent loading spinner issues
-- In production, you would enable RLS and implement proper policies

-- Grant all permissions to authenticated and anonymous users for demo purposes
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon;

-- =====================================================
-- TRIGGERS FOR UPDATED_AT
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_reservations_updated_at BEFORE UPDATE ON reservations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tourist_profiles_updated_at BEFORE UPDATE ON tourist_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_maintenance_requests_updated_at BEFORE UPDATE ON maintenance_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- SAMPLE DATA INSERTION
-- =====================================================

-- Insert default lead sources
INSERT INTO lead_sources (name, description) VALUES
('Website', 'Direct website inquiries'),
('Social Media', 'Social media platforms'),
('Referral', 'Word of mouth referrals'),
('University Partnership', 'University partnerships'),
('Online Listing', 'Online property listings');

-- Insert default room grades (your structure)
INSERT INTO room_grades (name, weekly_rate, studio_count, description) VALUES
('Silver', 160.00, 12, 'Standard studio with essential amenities'),
('Gold', 175.00, 18, 'Enhanced studio with additional features'),
('Platinum', 195.00, 8, 'Premium studio with luxury amenities'),
('Rhodium', 200.00, 6, 'High-end studio with premium features'),
('Thodium Plus', 225.00, 4, 'Ultra-luxury studio with all amenities');

-- Insert default durations (your structure)
INSERT INTO durations (name, duration_type, check_in_date, check_out_date, weeks_count, academic_year) VALUES
('45-weeks', 'student', '2025-09-01', '2026-07-13', 45, '2025/2026'),
('51-weeks', 'student', '2025-09-01', '2026-08-24', 51, '2025/2026'),
('45-weeks', 'student', '2026-09-01', '2027-07-13', 45, '2026/2027'),
('51-weeks', 'student', '2026-09-01', '2027-08-24', 51, '2026/2027'),
('Daily', 'tourist', '2025-01-01', '2025-12-31', 1, NULL),
('Weekly', 'tourist', '2025-01-01', '2025-12-31', 1, NULL);

-- Insert default maintenance categories
INSERT INTO maintenance_categories (name, description, priority) VALUES
('Plumbing', 'Water and drainage issues', 2),
('Electrical', 'Electrical system problems', 2),
('HVAC', 'Heating, ventilation, and air conditioning', 2),
('Furniture', 'Furniture repairs and replacements', 1),
('Cleaning', 'Deep cleaning and maintenance', 1),
('Security', 'Security system issues', 3);

-- Insert default module styles
INSERT INTO module_styles (module_name, gradient_start, gradient_end) VALUES
('leads', '#667eea', '#764ba2'),
('reservations', '#f093fb', '#f5576c'),
('students', '#4facfe', '#00f2fe'),
('cleaning', '#43e97b', '#38f9d7'),
('finance', '#fa709a', '#fee140'),
('data', '#a8edea', '#fed6e3'),
('settings', '#ffecd2', '#fcb69f');

-- Insert default installment plans
INSERT INTO installment_plans (name, description, number_of_installments, discount_percentage, late_fee_percentage, late_fee_flat) VALUES
('Monthly', 'Pay monthly with no discount', 1, 0.00, 5.00, 0.00),
('Quarterly', 'Pay quarterly with 2% discount', 3, 2.00, 5.00, 0.00),
('Semester', 'Pay per semester with 5% discount', 2, 5.00, 5.00, 0.00),
('Annual', 'Pay annually with 10% discount', 1, 10.00, 5.00, 0.00);

-- Insert dummy users
INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_active) VALUES
('admin@iska.com', '$2a$10$dummy.hash.for.demo', 'Admin', 'User', 'administrator', '+44 20 1234 5678', true),
('sales@iska.com', '$2a$10$dummy.hash.for.demo', 'John', 'Sales', 'salesperson', '+44 20 1234 5679', true),
('reservations@iska.com', '$2a$10$dummy.hash.for.demo', 'Sarah', 'Reservations', 'reservations', '+44 20 1234 5680', true),
('cleaner@iska.com', '$2a$10$dummy.hash.for.demo', 'Mike', 'Cleaner', 'cleaner', '+44 20 1234 5681', true),
('accountant@iska.com', '$2a$10$dummy.hash.for.demo', 'Emma', 'Accountant', 'accountant', '+44 20 1234 5682', true),
('student1@university.ac.uk', '$2a$10$dummy.hash.for.demo', 'Alex', 'Student', 'student', '+44 20 1234 5683', true),
('student2@university.ac.uk', '$2a$10$dummy.hash.for.demo', 'Maria', 'Garcia', 'student', '+44 20 1234 5684', true),
('tourist1@email.com', '$2a$10$dummy.hash.for.demo', 'Hans', 'Mueller', 'student', '+49 30 1234 5678', true);

-- Insert dummy studios for each room grade
-- Silver studios (12 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('S101', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S102', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'occupied'),
('S103', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S104', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'dirty'),
('S105', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S106', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'occupied'),
('S201', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S202', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'occupied'),
('S203', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S204', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'maintenance'),
('S205', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S206', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'occupied');

-- Gold studios (18 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('G101', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G102', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'occupied'),
('G103', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G104', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'dirty'),
('G105', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G106', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'occupied'),
('G201', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G202', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'occupied'),
('G203', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G204', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'cleaning'),
('G205', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G206', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'occupied'),
('G301', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G302', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'occupied'),
('G303', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G304', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'dirty'),
('G305', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G306', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'occupied');

-- Platinum studios (8 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('P101', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'vacant'),
('P102', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'occupied'),
('P103', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'vacant'),
('P104', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'dirty'),
('P201', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'vacant'),
('P202', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'occupied'),
('P203', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'vacant'),
('P204', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'maintenance');

-- Rhodium studios (6 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('R101', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'vacant'),
('R102', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'occupied'),
('R103', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'vacant'),
('R201', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'occupied'),
('R202', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'vacant'),
('R203', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'dirty');

-- Thodium Plus studios (4 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('T101', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 1, 'occupied'),
('T102', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 1, 'vacant'),
('T201', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 2, 'occupied'),
('T202', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 2, 'vacant');

-- Insert dummy students
INSERT INTO students (user_id, student_id, university, course, year_of_study, emergency_contact_name, emergency_contact_phone, guarantor_name, guarantor_phone, guarantor_email) VALUES
((SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 'STU001', 'University of London', 'Computer Science', 2, 'Jane Student', '+44 20 1234 5685', 'John Student', '+44 20 1234 5686', 'john.student@email.com'),
((SELECT id FROM users WHERE email = 'student2@university.ac.uk'), 'STU002', 'Imperial College London', 'Engineering', 1, 'Carlos Garcia', '+44 20 1234 5687', 'Maria Garcia', '+44 20 1234 5688', 'maria.garcia@email.com');

-- Insert dummy tourist profiles
INSERT INTO tourist_profiles (user_id, passport_number, nationality, emergency_contact_name, emergency_contact_phone) VALUES
((SELECT id FROM users WHERE email = 'tourist1@email.com'), 'DE123456789', 'German', 'Anna Mueller', '+49 30 1234 5679');

-- Insert dummy leads
INSERT INTO leads (first_name, last_name, email, phone, source_id, status, budget, move_in_date, duration_months, notes, assigned_to, created_by) VALUES
('David', 'Wilson', 'david.wilson@email.com', '+44 20 1234 5690', (SELECT id FROM lead_sources WHERE name = 'Website'), 'new', 8000.00, '2025-09-01', 45, 'Interested in Gold studio', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('Emma', 'Brown', 'emma.brown@email.com', '+44 20 1234 5691', (SELECT id FROM lead_sources WHERE name = 'Social Media'), 'contacted', 12000.00, '2025-09-01', 51, 'Looking for Platinum or higher', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('James', 'Taylor', 'james.taylor@email.com', '+44 20 1234 5692', (SELECT id FROM lead_sources WHERE name = 'Referral'), 'qualified', 6000.00, '2025-09-01', 45, 'Budget conscious, Silver preferred', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('Sophie', 'Anderson', 'sophie.anderson@email.com', '+44 20 1234 5693', (SELECT id FROM lead_sources WHERE name = 'University Partnership'), 'proposal_sent', 15000.00, '2025-09-01', 51, 'International student, needs guarantor info', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com'));

-- Insert dummy reservations
INSERT INTO reservations (reservation_number, type, student_id, studio_id, duration_id, check_in_date, check_out_date, status, total_amount, deposit_amount, discount_amount, balance_due, notes, created_by) VALUES
('RES001', 'student', (SELECT id FROM students WHERE student_id = 'STU001'), (SELECT id FROM studios WHERE studio_number = 'G102'), (SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), '2025-09-01', '2026-07-13', 'confirmed', 7875.00, 1575.00, 0.00, 6300.00, 'Student reservation for Alex', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
('RES002', 'student', (SELECT id FROM students WHERE student_id = 'STU002'), (SELECT id FROM studios WHERE studio_number = 'P202'), (SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), '2025-09-01', '2026-08-24', 'confirmed', 9945.00, 1989.00, 0.00, 7956.00, 'Student reservation for Maria', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

INSERT INTO reservations (reservation_number, type, tourist_id, studio_id, duration_id, check_in_date, check_out_date, status, total_amount, deposit_amount, discount_amount, balance_due, notes, created_by) VALUES
('RES003', 'tourist', (SELECT id FROM tourist_profiles WHERE passport_number = 'DE123456789'), (SELECT id FROM studios WHERE studio_number = 'T101'), (SELECT id FROM durations WHERE name = 'Weekly' AND duration_type = 'tourist'), '2025-01-15', '2025-01-22', 'checked_in', 225.00, 225.00, 0.00, 0.00, 'Tourist reservation for Hans', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

-- Insert dummy reservation installments
INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status) VALUES
((SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 1, '2025-09-01', 3150.00, 'completed'),
((SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 2, '2026-01-15', 3150.00, 'pending'),
((SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 1, '2025-09-01', 3978.00, 'completed'),
((SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 2, '2026-01-15', 3978.00, 'pending');

-- Insert dummy invoices
INSERT INTO invoices (invoice_number, reservation_id, reservation_installment_id, amount, tax_amount, total_amount, due_date, status, created_by) VALUES
('INV001', (SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES001') AND installment_number = 1), 3150.00, 0.00, 3150.00, '2025-09-01', 'completed', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV002', (SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES001') AND installment_number = 2), 3150.00, 0.00, 3150.00, '2026-01-15', 'pending', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV003', (SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES002') AND installment_number = 1), 3978.00, 0.00, 3978.00, '2025-09-01', 'completed', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV004', (SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES002') AND installment_number = 2), 3978.00, 0.00, 3978.00, '2026-01-15', 'pending', (SELECT id FROM users WHERE email = 'accountant@iska.com'));

-- Insert dummy payments
INSERT INTO payments (invoice_id, amount, method, status, processed_at, created_by) VALUES
((SELECT id FROM invoices WHERE invoice_number = 'INV001'), 3150.00, 'stripe', 'completed', '2025-09-01 10:00:00+00', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
((SELECT id FROM invoices WHERE invoice_number = 'INV003'), 3978.00, 'bank_transfer', 'completed', '2025-09-01 14:30:00+00', (SELECT id FROM users WHERE email = 'accountant@iska.com'));

-- Insert dummy cleaners
INSERT INTO cleaners (user_id, hourly_rate, is_active) VALUES
((SELECT id FROM users WHERE email = 'cleaner@iska.com'), 15.00, true);

-- Insert dummy cleaning tasks
INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by) VALUES
((SELECT id FROM studios WHERE studio_number = 'S104'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-15', '09:00:00', 120, 'scheduled', 'Standard cleaning after checkout', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
((SELECT id FROM studios WHERE studio_number = 'G204'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-15', '11:00:00', 90, 'in_progress', 'Deep cleaning required', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
((SELECT id FROM studios WHERE studio_number = 'R203'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-16', '10:00:00', 150, 'scheduled', 'Premium cleaning service', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

-- Insert dummy maintenance requests
INSERT INTO maintenance_requests (studio_id, category_id, title, description, priority, status, reported_by, estimated_cost) VALUES
((SELECT id FROM studios WHERE studio_number = 'S204'), (SELECT id FROM maintenance_categories WHERE name = 'Plumbing'), 'Leaking tap in bathroom', 'Tap in bathroom is dripping constantly', 2, 'open', (SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 50.00),
((SELECT id FROM studios WHERE studio_number = 'P204'), (SELECT id FROM maintenance_categories WHERE name = 'Electrical'), 'Light switch not working', 'Light switch in bedroom stopped working', 3, 'in_progress', (SELECT id FROM users WHERE email = 'student2@university.ac.uk'), 75.00),
((SELECT id FROM studios WHERE studio_number = 'G104'), (SELECT id FROM maintenance_categories WHERE name = 'Furniture'), 'Broken desk chair', 'Office chair is broken and needs replacement', 1, 'completed', (SELECT id FROM users WHERE email = 'cleaner@iska.com'), 120.00);

-- Insert dummy notifications
INSERT INTO notifications (user_id, title, message, type, related_entity_type, related_entity_id) VALUES
((SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 'Maintenance Request Submitted', 'Your maintenance request for studio S204 has been submitted successfully.', 'info', 'maintenance', (SELECT id FROM maintenance_requests WHERE title = 'Leaking tap in bathroom')),
((SELECT id FROM users WHERE email = 'reservations@iska.com'), 'New Lead Assigned', 'A new lead has been assigned to you: David Wilson', 'info', 'lead', (SELECT id FROM leads WHERE email = 'david.wilson@email.com')),
((SELECT id FROM users WHERE email = 'accountant@iska.com'), 'Payment Received', 'Payment of £3,150.00 received for invoice INV001', 'success', 'payment', (SELECT id FROM payments WHERE invoice_id = (SELECT id FROM invoices WHERE invoice_number = 'INV001')));

-- Insert pricing matrix entries
INSERT INTO pricing_matrix (duration_id, room_grade_id, is_active) VALUES
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Silver'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Gold'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Platinum'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Rhodium'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Silver'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Gold'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Platinum'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Rhodium'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), true);
