-- Insert dummy users
INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_active) VALUES
('admin@iska.com', '$2a$10$dummy.hash.for.demo', 'Admin', 'User', 'administrator', '+44 20 1234 5678', true),
('sales@iska.com', '$2a$10$dummy.hash.for.demo', 'John', 'Sales', 'salesperson', '+44 20 1234 5679', true),
('reservations@iska.com', '$2a$10$dummy.hash.for.demo', 'Sarah', 'Reservations', 'reservations', '+44 20 1234 5680', true),
('cleaner@iska.com', '$2a$10$dummy.hash.for.demo', 'Mike', 'Cleaner', 'cleaner', '+44 20 1234 5681', true),
('accountant@iska.com', '$2a$10$dummy.hash.for.demo', 'Emma', 'Accountant', 'accountant', '+44 20 1234 5682', true),
('student1@university.ac.uk', '$2a$10$dummy.hash.for.demo', 'Alex', 'Student', 'student', '+44 20 1234 5683', true),
('student2@university.ac.uk', '$2a$10$dummy.hash.for.demo', 'Maria', 'Garcia', 'student', '+44 20 1234 5684', true),
('tourist1@email.com', '$2a$10$dummy.hash.for.demo', 'Hans', 'Mueller', 'student', '+49 30 1234 5678', true);

-- Insert dummy studios for each room grade
-- Silver studios (12 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('S101', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S102', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'occupied'),
('S103', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S104', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'dirty'),
('S105', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'vacant'),
('S106', (SELECT id FROM room_grades WHERE name = 'Silver'), 1, 'occupied'),
('S201', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S202', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'occupied'),
('S203', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S204', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'maintenance'),
('S205', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'vacant'),
('S206', (SELECT id FROM room_grades WHERE name = 'Silver'), 2, 'occupied');

-- Gold studios (18 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('G101', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G102', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'occupied'),
('G103', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G104', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'dirty'),
('G105', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'vacant'),
('G106', (SELECT id FROM room_grades WHERE name = 'Gold'), 1, 'occupied'),
('G201', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G202', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'occupied'),
('G203', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G204', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'cleaning'),
('G205', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'vacant'),
('G206', (SELECT id FROM room_grades WHERE name = 'Gold'), 2, 'occupied'),
('G301', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G302', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'occupied'),
('G303', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G304', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'dirty'),
('G305', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'vacant'),
('G306', (SELECT id FROM room_grades WHERE name = 'Gold'), 3, 'occupied');

-- Platinum studios (8 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('P101', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'vacant'),
('P102', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'occupied'),
('P103', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'vacant'),
('P104', (SELECT id FROM room_grades WHERE name = 'Platinum'), 1, 'dirty'),
('P201', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'vacant'),
('P202', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'occupied'),
('P203', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'vacant'),
('P204', (SELECT id FROM room_grades WHERE name = 'Platinum'), 2, 'maintenance');

-- Rhodium studios (6 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('R101', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'vacant'),
('R102', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'occupied'),
('R103', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 1, 'vacant'),
('R201', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'occupied'),
('R202', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'vacant'),
('R203', (SELECT id FROM room_grades WHERE name = 'Rhodium'), 2, 'dirty');

-- Thodium Plus studios (4 total)
INSERT INTO studios (studio_number, room_grade_id, floor, status) VALUES
('T101', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 1, 'occupied'),
('T102', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 1, 'vacant'),
('T201', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 2, 'occupied'),
('T202', (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), 2, 'vacant');

-- Insert dummy students
INSERT INTO students (user_id, student_id, university, course, year_of_study, emergency_contact_name, emergency_contact_phone, guarantor_name, guarantor_phone, guarantor_email) VALUES
((SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 'STU001', 'University of London', 'Computer Science', 2, 'Jane Student', '+44 20 1234 5685', 'John Student', '+44 20 1234 5686', 'john.student@email.com'),
((SELECT id FROM users WHERE email = 'student2@university.ac.uk'), 'STU002', 'Imperial College London', 'Engineering', 1, 'Carlos Garcia', '+44 20 1234 5687', 'Maria Garcia', '+44 20 1234 5688', 'maria.garcia@email.com');

-- Insert dummy tourist profiles
INSERT INTO tourist_profiles (user_id, passport_number, nationality, emergency_contact_name, emergency_contact_phone) VALUES
((SELECT id FROM users WHERE email = 'tourist1@email.com'), 'DE123456789', 'German', 'Anna Mueller', '+49 30 1234 5679');

-- Insert dummy leads
INSERT INTO leads (first_name, last_name, email, phone, source_id, status, budget, move_in_date, duration_months, notes, assigned_to, created_by) VALUES
('David', 'Wilson', 'david.wilson@email.com', '+44 20 1234 5690', (SELECT id FROM lead_sources WHERE name = 'Website'), 'new', 8000.00, '2025-09-01', 45, 'Interested in Gold studio', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('Emma', 'Brown', 'emma.brown@email.com', '+44 20 1234 5691', (SELECT id FROM lead_sources WHERE name = 'Social Media'), 'contacted', 12000.00, '2025-09-01', 51, 'Looking for Platinum or higher', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('James', 'Taylor', 'james.taylor@email.com', '+44 20 1234 5692', (SELECT id FROM lead_sources WHERE name = 'Referral'), 'qualified', 6000.00, '2025-09-01', 45, 'Budget conscious, Silver preferred', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com')),
('Sophie', 'Anderson', 'sophie.anderson@email.com', '+44 20 1234 5693', (SELECT id FROM lead_sources WHERE name = 'University Partnership'), 'proposal_sent', 15000.00, '2025-09-01', 51, 'International student, needs guarantor info', (SELECT id FROM users WHERE email = 'sales@iska.com'), (SELECT id FROM users WHERE email = 'sales@iska.com'));

-- Insert dummy reservations
INSERT INTO reservations (reservation_number, type, student_id, studio_id, duration_id, check_in_date, check_out_date, status, total_amount, deposit_amount, discount_amount, balance_due, notes, created_by) VALUES
('RES001', 'student', (SELECT id FROM students WHERE student_id = 'STU001'), (SELECT id FROM studios WHERE studio_number = 'G102'), (SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), '2025-09-01', '2026-07-13', 'confirmed', 7875.00, 1575.00, 0.00, 6300.00, 'Student reservation for Alex', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
('RES002', 'student', (SELECT id FROM students WHERE student_id = 'STU002'), (SELECT id FROM studios WHERE studio_number = 'P202'), (SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), '2025-09-01', '2026-08-24', 'confirmed', 9945.00, 1989.00, 0.00, 7956.00, 'Student reservation for Maria', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

INSERT INTO reservations (reservation_number, type, tourist_id, studio_id, duration_id, check_in_date, check_out_date, status, total_amount, deposit_amount, discount_amount, balance_due, notes, created_by) VALUES
('RES003', 'tourist', (SELECT id FROM tourist_profiles WHERE passport_number = 'DE123456789'), (SELECT id FROM studios WHERE studio_number = 'T101'), (SELECT id FROM durations WHERE name = 'Weekly' AND duration_type = 'tourist'), '2025-01-15', '2025-01-22', 'checked_in', 225.00, 225.00, 0.00, 0.00, 'Tourist reservation for Hans', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

-- Insert dummy reservation installments
INSERT INTO reservation_installments (reservation_id, installment_plan_id, installment_number, due_date, amount, status) VALUES
((SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 1, '2025-09-01', 3150.00, 'completed'),
((SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 2, '2026-01-15', 3150.00, 'pending'),
((SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 1, '2025-09-01', 3978.00, 'completed'),
((SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM installment_plans WHERE name = 'Semester'), 2, '2026-01-15', 3978.00, 'pending');

-- Insert dummy invoices
INSERT INTO invoices (invoice_number, reservation_id, reservation_installment_id, amount, tax_amount, total_amount, due_date, status, created_by) VALUES
('INV001', (SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES001') AND installment_number = 1), 3150.00, 0.00, 3150.00, '2025-09-01', 'completed', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV002', (SELECT id FROM reservations WHERE reservation_number = 'RES001'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES001') AND installment_number = 2), 3150.00, 0.00, 3150.00, '2026-01-15', 'pending', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV003', (SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES002') AND installment_number = 1), 3978.00, 0.00, 3978.00, '2025-09-01', 'completed', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
('INV004', (SELECT id FROM reservations WHERE reservation_number = 'RES002'), (SELECT id FROM reservation_installments WHERE reservation_id = (SELECT id FROM reservations WHERE reservation_number = 'RES002') AND installment_number = 2), 3978.00, 0.00, 3978.00, '2026-01-15', 'pending', (SELECT id FROM users WHERE email = 'accountant@iska.com'));

-- Insert dummy payments
INSERT INTO payments (invoice_id, amount, method, status, processed_at, created_by) VALUES
((SELECT id FROM invoices WHERE invoice_number = 'INV001'), 3150.00, 'stripe', 'completed', '2025-09-01 10:00:00+00', (SELECT id FROM users WHERE email = 'accountant@iska.com')),
((SELECT id FROM invoices WHERE invoice_number = 'INV003'), 3978.00, 'bank_transfer', 'completed', '2025-09-01 14:30:00+00', (SELECT id FROM users WHERE email = 'accountant@iska.com'));

-- Insert dummy cleaners
INSERT INTO cleaners (user_id, hourly_rate, is_active) VALUES
((SELECT id FROM users WHERE email = 'cleaner@iska.com'), 15.00, true);

-- Insert dummy cleaning tasks
INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by) VALUES
((SELECT id FROM studios WHERE studio_number = 'S104'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-15', '09:00:00', 120, 'scheduled', 'Standard cleaning after checkout', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
((SELECT id FROM studios WHERE studio_number = 'G204'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-15', '11:00:00', 90, 'in_progress', 'Deep cleaning required', (SELECT id FROM users WHERE email = 'reservations@iska.com')),
((SELECT id FROM studios WHERE studio_number = 'R203'), (SELECT id FROM cleaners WHERE user_id = (SELECT id FROM users WHERE email = 'cleaner@iska.com')), '2025-01-16', '10:00:00', 150, 'scheduled', 'Premium cleaning service', (SELECT id FROM users WHERE email = 'reservations@iska.com'));

-- Insert dummy maintenance requests
INSERT INTO maintenance_requests (studio_id, category_id, title, description, priority, status, reported_by, estimated_cost) VALUES
((SELECT id FROM studios WHERE studio_number = 'S204'), (SELECT id FROM maintenance_categories WHERE name = 'Plumbing'), 'Leaking tap in bathroom', 'Tap in bathroom is dripping constantly', 2, 'open', (SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 50.00),
((SELECT id FROM studios WHERE studio_number = 'P204'), (SELECT id FROM maintenance_categories WHERE name = 'Electrical'), 'Light switch not working', 'Light switch in bedroom stopped working', 3, 'in_progress', (SELECT id FROM users WHERE email = 'student2@university.ac.uk'), 75.00),
((SELECT id FROM studios WHERE studio_number = 'G104'), (SELECT id FROM maintenance_categories WHERE name = 'Furniture'), 'Broken desk chair', 'Office chair is broken and needs replacement', 1, 'completed', (SELECT id FROM users WHERE email = 'cleaner@iska.com'), 120.00);

-- Insert dummy notifications
INSERT INTO notifications (user_id, title, message, type, related_entity_type, related_entity_id) VALUES
((SELECT id FROM users WHERE email = 'student1@university.ac.uk'), 'Maintenance Request Submitted', 'Your maintenance request for studio S204 has been submitted successfully.', 'info', 'maintenance', (SELECT id FROM maintenance_requests WHERE title = 'Leaking tap in bathroom')),
((SELECT id FROM users WHERE email = 'reservations@iska.com'), 'New Lead Assigned', 'A new lead has been assigned to you: David Wilson', 'info', 'lead', (SELECT id FROM leads WHERE email = 'david.wilson@email.com')),
((SELECT id FROM users WHERE email = 'accountant@iska.com'), 'Payment Received', 'Payment of £3,150.00 received for invoice INV001', 'success', 'payment', (SELECT id FROM payments WHERE invoice_id = (SELECT id FROM invoices WHERE invoice_number = 'INV001')));

-- Insert pricing matrix entries
INSERT INTO pricing_matrix (duration_id, room_grade_id, is_active) VALUES
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Silver'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Gold'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Platinum'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Rhodium'), true),
((SELECT id FROM durations WHERE name = '45-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Silver'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Gold'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Platinum'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Rhodium'), true),
((SELECT id FROM durations WHERE name = '51-weeks' AND academic_year = '2025/2026'), (SELECT id FROM room_grades WHERE name = 'Thodium Plus'), true);
