-- =====================================================
-- FIX CLEANING TASKS FOREIGN KEY RELATIONSHIPS
-- =====================================================

-- Drop existing foreign key constraints if they exist
ALTER TABLE cleaning_tasks DROP CONSTRAINT IF EXISTS cleaning_tasks_studio_id_fkey;
ALTER TABLE cleaning_tasks DROP CONSTRAINT IF EXISTS cleaning_tasks_cleaner_id_fkey;
ALTER TABLE cleaning_tasks DROP CONSTRAINT IF EXISTS cleaning_tasks_verified_by_fkey;
ALTER TABLE cleaning_tasks DROP CONSTRAINT IF EXISTS cleaning_tasks_created_by_fkey;

-- Clean up orphaned cleaning_tasks (those referencing non-existent studios/cleaners/users)
UPDATE cleaning_tasks SET studio_id = NULL WHERE studio_id NOT IN (SELECT id FROM studios);
UPDATE cleaning_tasks SET cleaner_id = NULL WHERE cleaner_id NOT IN (SELECT id FROM cleaners);
UPDATE cleaning_tasks SET verified_by = NULL WHERE verified_by NOT IN (SELECT id FROM users);
UPDATE cleaning_tasks SET created_by = NULL WHERE created_by NOT IN (SELECT id FROM users);

-- Re-add foreign key constraints
ALTER TABLE cleaning_tasks 
ADD CONSTRAINT cleaning_tasks_studio_id_fkey 
FOREIGN KEY (studio_id) REFERENCES studios(id) ON DELETE SET NULL;

ALTER TABLE cleaning_tasks 
ADD CONSTRAINT cleaning_tasks_cleaner_id_fkey 
FOREIGN KEY (cleaner_id) REFERENCES cleaners(id) ON DELETE SET NULL;

ALTER TABLE cleaning_tasks 
ADD CONSTRAINT cleaning_tasks_verified_by_fkey 
FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE cleaning_tasks 
ADD CONSTRAINT cleaning_tasks_created_by_fkey 
FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;

-- Ensure the cleaning_tasks table has the correct structure
-- Only set NOT NULL if there are no null values
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE studio_id IS NULL) THEN
        ALTER TABLE cleaning_tasks ALTER COLUMN studio_id SET NOT NULL;
    END IF;
END $$;

-- Add some sample cleaning_tasks data if it doesn't exist
INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT 
    s.id as studio_id,
    c.id as cleaner_id,
    '2025-01-15'::DATE as scheduled_date,
    '09:00:00'::TIME as scheduled_time,
    120 as estimated_duration,
    'scheduled'::cleaning_status as status,
    'Regular cleaning service' as notes,
    u.id as created_by
FROM studios s
CROSS JOIN cleaners c
CROSS JOIN users u
WHERE u.role = 'administrator'
AND s.status = 'dirty'
AND c.is_active = true
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-15'::DATE)
LIMIT 5;

-- Add more sample data for different dates
INSERT INTO cleaning_tasks (studio_id, cleaner_id, scheduled_date, scheduled_time, estimated_duration, status, notes, created_by)
SELECT 
    s.id as studio_id,
    c.id as cleaner_id,
    '2025-01-16'::DATE as scheduled_date,
    '14:00:00'::TIME as scheduled_time,
    90 as estimated_duration,
    'scheduled'::cleaning_status as status,
    'Deep cleaning required' as notes,
    u.id as created_by
FROM studios s
CROSS JOIN cleaners c
CROSS JOIN users u
WHERE u.role = 'administrator'
AND s.status = 'dirty'
AND c.is_active = true
AND NOT EXISTS (SELECT 1 FROM cleaning_tasks WHERE cleaning_tasks.studio_id = s.id AND cleaning_tasks.scheduled_date = '2025-01-16'::DATE)
LIMIT 3; 