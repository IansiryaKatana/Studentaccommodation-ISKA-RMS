
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import SettingsOverview from '@/components/settings/SettingsOverview';
import UserManagement from '@/components/settings/UserManagement';
import UserDetail from '@/components/settings/UserDetail';
import AddUser from '@/components/settings/AddUser';
import SystemPreferences from '@/components/settings/SystemPreferences';
import SecuritySettings from '@/components/settings/SecuritySettings';
import IntegrationSettings from '@/components/settings/IntegrationSettings';
import NotificationSettings from '@/components/settings/NotificationSettings';
import ConfigManagement from '@/components/settings/ConfigManagement';
import BrandingManagement from '@/components/settings/BrandingManagement';

const SettingsModule = () => {
  return (
    <Routes>
      <Route path="/" element={<SettingsOverview />} />
      <Route path="/users" element={<UserManagement />} />
      <Route path="/users/new" element={<AddUser />} />
      <Route path="/users/:id" element={<UserDetail />} />
      <Route path="/system" element={<SystemPreferences />} />
      <Route path="/security" element={<SecuritySettings />} />
      <Route path="/integrations" element={<IntegrationSettings />} />
      <Route path="/notifications" element={<NotificationSettings />} />
      <Route path="/config" element={<ConfigManagement />} />
      <Route path="/branding" element={<BrandingManagement />} />
    </Routes>
  );
};

export default SettingsModule;
