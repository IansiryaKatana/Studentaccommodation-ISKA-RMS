-- =====================================================
-- UPDATE TOURIST SCHEMA - EXACT FORM FIELDS
-- =====================================================

-- Drop existing tourist_profiles table and recreate with exact form fields
DROP TABLE IF EXISTS tourist_profiles CASCADE;

-- Create tourist_profiles table with exact form fields
CREATE TABLE tourist_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create tourist_booking_sources table
CREATE TABLE tourist_booking_sources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create tourist_guest_statuses table
CREATE TABLE tourist_guest_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    color VARCHAR(20) DEFAULT 'gray',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Update reservations table to include new fields
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS booking_source_id UUID REFERENCES tourist_booking_sources(id);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS guest_status_id UUID REFERENCES tourist_guest_statuses(id);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS price_per_night DECIMAL(10,2) NOT NULL DEFAULT 0;

-- Insert default booking sources
INSERT INTO tourist_booking_sources (name, description) VALUES
('Direct Booking', 'Direct booking through website or phone'),
('Booking.com', 'Booking through Booking.com platform'),
('Airbnb', 'Booking through Airbnb platform'),
('Expedia', 'Booking through Expedia platform'),
('Travel Agent', 'Booking through travel agent'),
('Walk-in', 'Walk-in booking'),
('Referral', 'Referral from existing guest'),
('Corporate', 'Corporate booking'),
('Other', 'Other booking source');

-- Insert default guest statuses
INSERT INTO tourist_guest_statuses (name, description, color) VALUES
('Checking In', 'Guest is currently checking in', 'blue'),
('Checked In', 'Guest has successfully checked in', 'green'),
('Checking Out', 'Guest is currently checking out', 'orange'),
('Checked Out', 'Guest has successfully checked out', 'gray'),
('Upcoming', 'Guest has confirmed booking but not yet arrived', 'purple'),
('Confirmed', 'Booking is confirmed but guest not yet arrived', 'green'),
('Pending', 'Booking is pending confirmation', 'yellow'),
('Cancelled', 'Booking has been cancelled', 'red');

-- Create indexes for better performance
CREATE INDEX idx_tourist_profiles_email ON tourist_profiles(email);
CREATE INDEX idx_tourist_profiles_name ON tourist_profiles(first_name, last_name);
CREATE INDEX idx_reservations_booking_source_id ON reservations(booking_source_id);
CREATE INDEX idx_reservations_guest_status_id ON reservations(guest_status_id);

-- Add triggers for updated_at
CREATE TRIGGER update_tourist_profiles_updated_at BEFORE UPDATE ON tourist_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tourist_booking_sources_updated_at BEFORE UPDATE ON tourist_booking_sources FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tourist_guest_statuses_updated_at BEFORE UPDATE ON tourist_guest_statuses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Disable RLS for new tables
ALTER TABLE tourist_profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE tourist_booking_sources DISABLE ROW LEVEL SECURITY;
ALTER TABLE tourist_guest_statuses DISABLE ROW LEVEL SECURITY; 